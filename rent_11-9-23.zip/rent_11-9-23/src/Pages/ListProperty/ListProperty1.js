import React from 'react'
import Navbar from '../../Components/Navbar/Navbar';
import './ListProperty.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { APIRequest, PROFILE_UPDATE } from '../../api';
import { logout, setUser } from '../../redux/action';
import toast from 'react-simple-toasts';
import * as Yup from "yup"
import { useFormik } from 'formik';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';

export default function ListProperty1() {
    const property1 = useSelector(state => state.property1);
    const property3 = useSelector(state => state.property3)
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const property2 = useSelector(state => state.property2);
    const user = useSelector(state => state.user)
    const profile = useFormik({
        enableReinitialize: true,
        initialValues: {
            emailid: user?.emailid ?? "",
            firstname: user?.firstname ?? "",
            lastname: user?.lastname ?? "",
            mobileno: user?.mobileno ?? "",
            mode: "update"
        },
        validationSchema: Yup.object().shape({
            emailid: Yup.string().email('Please enter valid email').required(" Enter Email"),
            firstname: Yup.string().required(" Enter First Name").min(3, "Enter Minimum 3 Character"),
            lastname: Yup.string().required(" Enter Last Name").min(3, "Enter Minimum 3 Character"),
            mobileno: Yup.string().length(10, " Enter 10 Digit Number").matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
                "Phone number is not valid"
            ).required(" Enter Number")

        }), onSubmit: values => {
            
            new APIRequest.Builder()
                .post()
                .setReqId(PROFILE_UPDATE)
                .jsonParams(values)
                .reqURL("user/signup")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    })
    const onResponse = (response, reqId) => {

        switch (reqId) {
            case PROFILE_UPDATE:
                if (response.data.issuccess) {
                    navigate("/list-property2");
                    dispatch(setUser(response.data.data))
                } else {
                    toast(`${response.data.massage}`)
                }
                break;
            default:
                break;
        }
    }
    
    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        if(response.data.status==STATE_ERROR){
            localStorage.clear()
            dispatch(logout())
            navigate("/login");
          }
        switch (reqId) {
            case PROFILE_UPDATE:
                toast("Profile is not successfully updated");
                break;
            default:
                break;
        }
    }

    return (
        <>
            <div className="main">
                <div className='listPropertyContainer marginMain'>
                    <div className="container-fluid">
                        <h2 className='page-heading'>{property2?.propertyid ? "Update" : "List"} <span className='font-semibold'>Property</span></h2>

                        {/* progress bar */}
                        {property2?.propertyid ?
                            <div className="row my-5 progressBar">
                                <div className="d-flex">
                                    <div className='me-4'>
                                        <p className='font-semibold black00 mb-1 cursorPointer' onClick={() => { navigate("/list-property") }}>1. Personal Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold black50 mb-1 cursorPointer' onClick={() => { navigate("/list-property2") }}>2. Property Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold black50 mb-1 cursorPointer' onClick={() => { navigate("/list-property3") }}>3. Property Description</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold black50 mb-1 cursorPointer' onClick={() => { navigate("/list-property4") }}>4. Amenities and Pictures</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                </div>
                            </div> :
                            <div className="row my-5 progressBar">
                                <div className="d-flex">
                                    <div className='me-4'>
                                        <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property") }}>1. Personal Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    {property2 === null ?
                                        <div className='me-4'>
                                            <p className='font-semibold  black50 mb-1' >2. Property Information</p>
                                            <div className='progresBar fill-white25'></div>
                                        </div> :
                                        <div className='me-4'>
                                            <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property2") }} >2. Property Information</p>
                                            <div className='progresBar fill-green00'></div>
                                        </div>}

                                    {property3 === null ?
                                        <div className='me-4'>
                                            <p className='font-semibold  black50 mb-1'>3. Property Description</p>
                                            <div className='progresBar fill-white25'></div>
                                        </div> :
                                        <div className='me-4'>
                                            <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property3") }}>3. Property Description</p>
                                            <div className='progresBar fill-green00'></div>
                                        </div>
                                    }
                                    {property1 === null ?
                                        <div className='me-4'>
                                            <p className='font-semibold  black50 mb-1'>4. Amenities and Pictures</p>
                                            <div className='progresBar fill-white25'></div>
                                        </div> :
                                        <div className='me-4'>
                                            <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property4") }}>4. Amenities and Pictures</p>
                                            <div className='progresBar fill-green00'></div>
                                        </div>
                                    }
                                </div>
                            </div>}
                        {property2?.propertyid ? <div className="row mt-2 progressBarTab">
                            <div className="round activate" onClick={() => { navigate("/list-property") }}>1</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property2") }} >2</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property3") }}>3</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property4") }}>4</div>
                        </div> :
                            <div className="row mt-2 progressBarTab">
                                <div className="round activate">1</div>
                                <div className="Line"></div>
                                {property2 === null ?<div className="round  ">2</div>:<div className="round activate" onClick={() => { navigate("/list-property2") }}>2</div>}
                                <div className="Line"></div>
                                {property3 === null ? <div className="round  ">3</div>:<div className="round activate" onClick={() => { navigate("/list-property3") }}>3</div>}
                                <div className="Line"></div>
                               {property1 === null ? <div className="round  ">4</div>:<div className="round" onClick={() => { navigate("/list-property4") }}>4</div>}
                            </div>}

                        <div className="listFormContainer w-100 fill-white25 mt-3">
                            <form onSubmit={profile.handleSubmit}>
                                <div className="container-fluid pb-5">
                                    {/* form */}

                                    <div className="row">
                                        <div className="col-md-6 col-sm-12  mt-3 ">
                                            <label className='green00 font-semibold mb-1' htmlFor="">First Name*  </label><br />
                                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25' value={profile.values.firstname}
                                                name="firstname" id='firstname' onChange={profile.handleChange} disabled />
                                            {profile.touched.firstname && profile.errors.firstname ? (
                                                <span className="error">{profile.errors.firstname}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Last Name*  </label><br />
                                            <input type="text" className='shadow-none fill-white25 removeRadious    form-control border-black25' value={profile.values.lastname}
                                                name="lastname" id='lastname' onChange={profile.handleChange} disabled/>
                                            {profile.touched.lastname && profile.errors.lastname ? (
                                                <span className="error">{profile.errors.lastname}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12  mt-3 ">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Email*  </label><br />
                                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25' value={profile.values.emailid}
                                                name="emailid" id='emailid' onChange={profile.handleChange} disabled/>
                                            {profile.touched.emailid && profile.errors.emailid ? (
                                                <span className="error">{profile.errors.emailid}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Contact No*  </label><br />
                                            <div className='d-flex  parenttwoinputdiv'>
                                              <input value="+1" className='shadow-none fill-white25 removeRadious border-black25 countecs ' disabled />
                                            <input type="text" className='shadow-none fill-white25 removeRadious form-control border-black25' value={profile.values.mobileno}
                                                name="mobileno" id='mobileno' onChange={profile.handleChange} />
                                                </div>
                                            {profile.touched.mobileno && profile.errors.mobileno ? (
                                                <span className="error">{profile.errors.mobileno}</span>
                                            ) : null}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <button type='submit' className='submitbutton border-none fill-green00 white00 px-3 py-2 text-center removeLinkDefaults'> Next </button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
