import React, { useEffect, useRef, useState } from "react";
import "./PropertyDetails.css";
import "../../Common/common.css";
import { Link, useNavigate, useParams } from "react-router-dom";
import Slider from "react-slick";
import {
  APIRequest,
  GET_PROPERTYPEDETAILS,
  SAVE_PROPERTYFAVOURITE,
  CONTACTUS,
  UNFAVOURITE_PROPERTY,
} from "../../api";
import toast from "react-simple-toasts";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";
import moment from "moment";
import DatePicker from "react-date-picker";
import axios from "axios";
import { ADDRESS_TOKEN, STATE_CODE404, STATE_ERROR500 } from "../../Common/AddressToken";
import mapboxgl from '!mapbox-gl';  // eslint-disable-line import/no-webpack-loader-syntax
import 'mapbox-gl/dist/mapbox-gl.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
mapboxgl.accessToken = 'pk.eyJ1Ijoibml0aW5jaGlrYW5pIiwiYSI6ImNsaHJibHhpNTBkNnQzbG13dThzeWxuNTUifQ.n805py9K8WZqAdIbyBZu9g';
 

export default function PropertyDetails() {
  const [properylist, Setpropertylist] = useState([]);
  const [favaourite, Setfavourite] = useState(false);
  const [slidenumber, Setslidenumber] = useState(2);
  const { id } = useParams();                                                                                                 
  const user = useSelector((state) => state.user);
  const sliderRef = useRef(null);
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [lng, setLng] = useState(null);
  const [lat, setLat] = useState(null);
  const [zoom, setZoom] = useState(9);
  const [show, setShow] = useState(false);
  const [shows, setShows] = useState(false);
  const [minDate, setMinDate] = useState(new Date());
  const [maxDate, setMaxDate] = useState("");
  const [selectDate,setSelectDate]= useState()
  const navigate = useNavigate()
  const handlesClose = () => setShows(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(GET_PROPERTYPEDETAILS)
      .jsonParams({
        login_userid: user?.userid,
        propertyid: id,
        isactive: "Y",
      })
      .reqURL("property/get_propertydetail")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [favaourite]);

  const exportImage = async (data) => {
    try {
      let url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${data}.json?proximity=ip&access_token=${ADDRESS_TOKEN}`;
      const response = await axios.get(url);      
      setLng(response.data.features[0].center[0]);
      setLat(response.data.features[0].center[1]);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    if (!lng || !lat) return; 
  
    if (map.current) return; // initialize map only once
    map.current = new mapboxgl.Map({
    container: mapContainer.current,
    style: 'mapbox://styles/mapbox/streets-v12',
    center:[lng, lat],
    zoom: zoom
    },);

    const marker = new mapboxgl.Marker()
    .setLngLat([lng, lat])
    .addTo(map.current);

    const zoomControl = new mapboxgl.NavigationControl();
    map.current.addControl(zoomControl, 'top-right');
    });
   
    useEffect(() => {
      if (!map.current) return;  // wait for map to initialize
      map.current.on('move', () => {
      setLng(map.current.getCenter().lng.toFixed(4));
      setLat(map.current.getCenter().lat.toFixed(4));
      setZoom(map.current.getZoom().toFixed(2));
      });
      });
 
    
  const Contectform = useFormik({
    enableReinitialize: true,
    initialValues: {
      propertyid: id,
      property_userid: properylist[0]?.userid,
      contact_email: "",
      contact_date: "",
      description: "",
      istours: "",
    },
    validationSchema: Yup.object().shape({
      contact_email: Yup.string()
      .email("Please enter valid email")
      .required(" Enter Email"),
      contact_date: Yup.string().required("Select Date"),
      description: Yup.string().required("Enter Description"),
    }),
    onSubmit: (values) => {
  
      if(user){
        setSelectDate("")
        new APIRequest.Builder()
        .post()
        .setReqId(CONTACTUS)
        .jsonParams(values)
        .reqURL("property/save_property_contactus")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      }else {
        setShows(true);
      }
    },
  });

  const unfavouriteProperty = (userid, propertyid) => {
    Setfavourite(true);
    new APIRequest.Builder()
    .post()
    .setReqId(UNFAVOURITE_PROPERTY)
      .jsonParams({
        userid: user?.userid,
        isactive: "N",
        propertyid: propertyid,
      })
      .reqURL("property/save_propertyfavourite")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  };

  const addFavourite = (userid, propertyid) => {
    if (user !== null) {
      Setfavourite(true);
      new APIRequest.Builder()
        .post()
        .setReqId(SAVE_PROPERTYFAVOURITE)
        .jsonParams({
          userid: user?.userid,
          propertyid: propertyid,
        })
        .reqURL("property/save_propertyfavourite")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    } else {
      toast("ForAdd In Favourite List Login Required");
    }
  };

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case GET_PROPERTYPEDETAILS:
        Setpropertylist(response?.data?.data);
        exportImage(response?.data?.data[0].street_address.toString());
        break;
      case SAVE_PROPERTYFAVOURITE:
        Setfavourite(false);
        break;
      case UNFAVOURITE_PROPERTY:
        Setfavourite(false);
        break;
      case CONTACTUS:
        toast(`${response.data.massage}`);
        Contectform.resetForm();
        break;
      default:
        break;
    }
  };

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case GET_PROPERTYPEDETAILS:
        console.log(response);
        break;
      case SAVE_PROPERTYFAVOURITE:
        toast(`${response?.data?.massage}`);
        break;
      case UNFAVOURITE_PROPERTY:
        toast(`${response?.data?.massage}`);
        break;
      case CONTACTUS:
        toast(`${response.data.massage}`);
        break;
      default:
        break;
    }
  };
  // MOB
  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 2500,
    cssEase: "linear",
  };
  // WEB
  const settings2 = {
    className: "center",
    centerMode: false,
    infinite: true,
    slidesToShow: 2,
    speed: 500,
    rows: 2,
    slidesPerRow: 1,
    dots: true,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 2500,
    cssEase: "linear",
    focusOnSelect: true,
  };

  useEffect(() => {
    if (sliderRef.current === null) return; // because on initial render it will not be set yet, since the DOM isnt rendered
    sliderRef.current.slickGoTo(slidenumber);
  }, [slidenumber]);

  const slideNext = () => {
    sliderRef.current.slickNext();
  };
  const slidePrev = () => {
    sliderRef.current.slickPrev();
  };
  const settings3 = {
    arrows: false,
    dots: true,
    dotsClass: "slick-dots slick-thumb",
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    customPaging: function (i) {
      return (
        <div>
          <img
            src={`${properylist[0]?.propertyImageList[i]?.image_url}`}
            alt=""
          />
        </div>
      );
    },
  };
  return (
    <>
      <div className="main">
        <div className="propertyDetailsContainer">
          <div className="container-fluid pt-3 pt-sm-0">
            <div className="propertyDetailHeader gradient-bg">
              <div className="container-box">
                <div className="d-md-flex ">
                  <div className=" textInfo white00  ">
                    <div className="d-flex ">
                      <h2 className="font-regular me-1 text-break">
                        {properylist[0]?.propertyname}
                      </h2>
                      {properylist[0]?.isfavourite === "Y" ? (
                        <button
                          className="wishlistbutton red00"
                          onClick={() => {
                            unfavouriteProperty(
                              properylist[0]?.userid,
                              properylist[0]?.propertyid
                            );
                          }}
                        >
                          <i className="bi bi-heart-fill"></i>
                        </button>
                      ) : (
                        <button
                          className="wishlistbutton black00"
                          onClick={() => {
                            user == null ? handleShow() :
                            addFavourite(
                              properylist[0]?.userid,
                              properylist[0]?.propertyid
                            );
                          }}
                        >
                          <i className="bi bi-heart-fill"></i>
                        </button>
                      )}
                      {/* <button className='wishlistbutton black00' onClick={() => { addFavourite(properylist[0]?.userid, properylist[0]?.propertyid) }}>&#10084;</button> */}
                    </div>

                    <p className="headerAdress font-regular mt-2 mb-3">
                      {properylist[0]?.street_address} &nbsp;{" "}
                      {properylist[0]?.city} &nbsp;{properylist[0]?.state}
                    </p>
                    <h4 className="font-semibold">
                      ${properylist[0]?.expected_monthly_rent}{" "}
                      <span className="deatailHeaderMonthlySize">monthly</span>
                    </h4>
                  </div>
                  <div className="headerImage  ms-md-auto me-md-0 ms-auto me-auto  ">
                    <img
                      src={`${properylist[0]?.cover_image_url}`}
                      className="img-fluid"
                    />{" "}
                  </div>
                </div>
              </div>
            </div>
            <div className="container-box">
              <div className="container-fluid padding5">
                <div className="row">
                  <div className="col-md-4 col-12  mt-4">
                    <h5 className="black00 mb-4">Property Info</h5>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">
                          Property type
                        </p>
                        <p className="mb-1 black00">
                          {properylist[0]?.property_type_name}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Bedrooms </p>
                        <p className="mb-0 black00">
                          {properylist[0]?.bedrooms_range}{" "}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Bathrooms</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.bathrooms_range}{" "}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Pet Policy</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.pet_policy_condition}{" "}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Overlooking</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.overlooking_type}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Square Ft</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.total_area_in_sqft}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Parking</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.parking_type}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Lease Terms</p>
                        <p className="mb-0 black00">
                          {properylist[0]?.lease_terms}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">
                          Security Deposit
                        </p>
                        <p className="mb-0 black00">
                          {properylist[0]?.security_deposit}
                        </p>
                      </div>
                      <hr />
                    </div>
                    <div className="mt-3">
                      <div className="d-flex  justify-content-between">
                        <p className="font-regular black50 mb-0">Created At</p>
                        <p className="mb-0 black00">
                          {moment(properylist[0]?.createdon)
                            .utc()
                            .format("MMMM DD YYYY")}
                        </p>
                      </div>
                      <hr />
                    </div>
                    {properylist[0]?.virtual_tour_link !== "" ? (
                      <button className="fill-green00 white00 virtualTourBtn">
                        {" "}
                        <img
                          src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/360logo.png`}
                          className="me-1"
                          alt=""
                        />
                        <a
                          className="removeLinkDefaults white00"
                          href={`https://www.google.com/search?q=${properylist[0]?.virtual_tour_link}`}
                          target="blank"
                        >
                          Take a virtual tour of property
                        </a>
                      </button>
                    ) : (
                      <div></div>
                    )}
                  </div>
                  <div className="col-md-8 ps-md-5 col-12 mt-4">
                    <h5 className="black00 mb-4">Images</h5>
                    <div className="row text-center propertyImagesWeb">
                      <Slider {...settings2}>
                        {properylist[0]?.propertyImageList.map((item, id) => (
                          <div className="singlePorpertyImage" key={id}>
                            <img
                              data-bs-toggle="modal"
                              data-bs-target="#exampleModal"
                              onClick={() => Setslidenumber(id)}
                              src={`${item?.image_url}`}
                              alt=""
                            />
                          </div>
                        ))}
                      </Slider>
                    </div>
                    <div className="propertyImageTab">
                      <Slider {...settings} className="homepageSlider">
                        {properylist[0]?.propertyImageList.map((item, id) => (
                          <div className="w-100 pe-sm-3">
                            <div className="col-md-6 mb-2 singlePorpertyImage">
                              <img
                                onClick={() => Setslidenumber(id)}
                                src={`${item?.image_url}`}
                                className="w-100"
                                alt=""
                              />
                            </div>
                          </div>
                        ))}
                      </Slider>
                    </div>
                  </div>
                </div>

                <div className="row p-0">
                  <div className="col-md-4 col-12  mt-4">
                    <h5 className="black00 mb-4">Amenities</h5>
                    <div className="mt-3">
                      <b className="green00 amenitiesTitle">
                        Smart Home Ameneties
                      </b>
                      <p className="font-regular amenitiesList text-break">
                        {properylist[0]?.propertyAmenitiesSmartList?.map(
                          function (item, index) {
                            return (
                              <span key={`demo_snap_${index}`}>
                                {(index ? ", ":"") + item.amenities_smart}
                              </span>
                            );
                          }
                        )}
                      </p>
                    </div>
                    <div className="mt-3">
                      <b className="green00 amenitiesTitle">
                        Energy-Efficient Amenities
                      </b>
                      <p className="font-regular amenitiesList  text-break ">
                        {properylist[0]?.propertyAmenitiesEnergyEfficientList?.map(
                          function (item, index) {
                            return (
                              <span key={`demo_snap_${index}`}>
                                {(index ? ", " : "") +
                                  item.amenities_energy_efficient}
                              </span>
                            );
                          }
                        )}
                      </p>
                    </div>
                    <div className="mt-3">
                      <b className="green00 amenitiesTitle">
                        In-unit or Community Amenities{" "}
                      </b>
                      <p className="font-regular amenitiesList  text-break ">
                        {properylist[0]?.propertyAmenitiesCommunityList?.map(
                          function (item, index) {
                            return (
                              <span key={`demo_snap_${index}`}>
                                {(index ? ", " : "") + item.amenities_community}
                              </span>
                            );
                          }
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="col-md-8 col-12 ps-md-5 col-12 mt-4 p-0">
                    <h5 className="black00 mb-4">Contact Owner</h5>
                    <form
                      onSubmit={Contectform.handleSubmit}
                      className="mt-3 row"
                    >
                      <div className="col-12 p-0">
                        <input
                          placeholder="Enter your email"
                          type="email"
                          className="shadow-none  removeRadious form-control border-black25"
                          name="contact_email"
                          id="contact_email"
                          value={Contectform.values.contact_email}
                          onChange={Contectform.handleChange}
                        />
                        {Contectform.touched.contact_email &&
                        Contectform.errors.contact_email ? (
                          <span className="error">
                            {Contectform.errors.contact_email}
                          </span>
                        ) : null}
                      </div>
                      <div className="col-lg-4 col-sm-5 col-12 border tourDate">
                        <p className="black00 font-thin m-0"> Request to date</p>
                        <div className="d-flex border p-2">
                          <DatePicker
                            onChange={(date) => {
                              let responseDate = moment(date).format('MM/DD/YYYY');
                              setSelectDate(date)
                              Contectform.setFieldValue("contact_date",responseDate.toString());
                            }}
                            value={selectDate}  
                            format="MM-dd-yyy"
                            className="m-aut"
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          {Contectform.touched.contact_date &&
                          Contectform.errors.contact_date ? (
                            <span className="error">
                              {Contectform.errors.contact_date}
                            </span>
                          ) : null}
                        </div>
                        <label>
                        <input
                          type="checkbox"
                          name="istours"
                          id="istours"
                          checked={
                            Contectform.values.istours === "" ? false : true
                          }
                          className="mt-3 me-2"
                          onClick={(e) => {
                            if (e.target.checked) {
                              Contectform.setFieldValue("istours", "Y");
                            } else {
                              Contectform.setFieldValue("istours", "");
                            }
                          }}
                        />
                        Request a tour</label>
                      </div>
                      <div className="col-lg-8 col-sm-7 col-12 border messageContainer">
                        <textarea
                          type="text"
                          className="messageInput border-none"
                          placeholder="Write your message here"
                          name="description"
                          id="description"
                          value={Contectform.values.description}
                          onChange={Contectform.handleChange}
                        />
                        {Contectform.touched.description &&
                        Contectform.errors.description ? (
                          <span className="error">
                            {Contectform.errors.description}
                          </span>
                        ) : null}
                      </div>
                      <button
                        className="fill-green00 white00 border-none py-1 px-2 ms-auto w-auto  font-14 mt-2"
                        type="submit"
                      >
                        Send
                      </button>
                    </form>

                    <h5 className="black00 mb-1 mt-0">Description</h5>
                    <div className="mt-3 row">
                      <p className="font-14 font-regular black00 text-break text-justify w-100">
                        {properylist[0]?.description}{" "}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="row">
                  <h5 className="black00 my-4">Map View</h5>
                  <div className="map-container w-100">
                    <div ref={mapContainer} className="map-container" />
                    {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17090.424170128532!2d-73.95640777191161!3d40.77986536399378!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2589a018531e3%3A0xb9df1f7387a94119!2sCentral%20Park!5e0!3m2!1sen!2sin!4v1664606322665!5m2!1sen!2sin" width="100%" height="450" allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <Footer/> */}

      {/* modal of signle image */}
      <div
        className="modal fade"
        id="exampleModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered modal-xl">
          <div className="modal-content image-modal-content ">
            <div className="modal-body image-modal-body  ">
              <button
                type="button"
                className="btn-close btnClose float-end"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <br />
              <div className="container-fluid">
                <div className="imageBox">
                  <button
                    className="fill-white00   singleImageBtn"
                    onClick={slidePrev}
                  >
                    &lt;
                  </button>
                  <button
                    className="fill-white00   singleImageBtn2"
                    onClick={slideNext}
                  >
                    &gt;
                  </button>
                  <Slider
                    className="w-100 allImageSlick"
                    {...settings3}
                    ref={sliderRef}
                  >
                    {properylist[0]?.propertyImageList.map((item) => (
                      <div className="imgContainer">
                        <img
                          className="img-fluid"
                          src={`${item?.image_url}`}
                          alt=""
                        />
                      </div>
                    ))}
                  </Slider>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Oops !!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <p className='textJustify'>
               Looks like you're not signed in. Please log in to save properties to your Favorites and enjoy a personalized experience. Don't have an account? Sign up now to start exploring your urban nest!
            </p>
        </Modal.Body>
        <Modal.Footer className="rowButton">
        <Link to="/login" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Login</Link>
           <Link to="/signup" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Create account</Link>    
        </Modal.Footer>
      </Modal>



      <Modal show={shows} onHide={handlesClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Oops !!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <p className='textJustify'>
             Member Exclusive: Please Log In or Sign up to message the Landlord.
            </p>
        </Modal.Body>
        <Modal.Footer className="rowButton">
        <Link to="/login" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Login</Link>
        <Link to="/signup" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Create Account</Link>  
        </Modal.Footer>
      </Modal>
    </>
  );
}
