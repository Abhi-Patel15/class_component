import React, { useEffect } from 'react'
import Navbar from '../../Components/Navbar/Navbar';
import './Homepage.css'
import '../../Common/common.css'  
import { Link, Outlet, useLocation } from 'react-router-dom';
import Footer from '../../Components/Footer/Footer';
import ProductCard from '../../Components/ProductCard/ProductCard'
import {BiSearch} from 'react-icons/bi';
import Slider from "react-slick";
import { useSelector } from 'react-redux';



export default function Homepage() {

  const user=useSelector(state=> state.user)

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
        }
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  const settings2 = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll:1, 
    autoplay: true,
    speed: 1000,
    autoplaySpeed:2500,
    cssEase: "linear"
  };

const location =useLocation();
 
  return (
    <>           
      <Navbar search={location.pathname==='/'?"hidden":"visible" } account ={user? "inline-block":"none"} login ={!user? "inline-block":"none"}/>
         <Outlet/>
      <Footer/>
    </>
  )
}
