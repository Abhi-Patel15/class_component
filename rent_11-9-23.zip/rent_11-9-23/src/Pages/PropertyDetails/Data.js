import  Image1  from './PropertyImg/propertyImage.png'
import  Image2  from './PropertyImg/propertyImage2.png'
import  Image3 from './PropertyImg/propertyImage3.jpg'
import  Image4  from './PropertyImg/propertyImage2.png'
import  Image5  from './PropertyImg/propertyImage3.jpg'
import  Image6 from './PropertyImg/propertyImage.png'
import  Image7  from './PropertyImg/propertyImage2.png'
import  Image8  from './PropertyImg/propertyImage3.jpg'
import  Image9 from './PropertyImg/propertyImage.png'
// export const Data = [Image1,Image2,Image3,Image4,Image5,Image6];
export const Data = [Image1,Image2,Image3,Image4,Image5,Image6,Image7,Image8,Image9];