import React, { useEffect, useState } from 'react'
import '../../Common/common.css'
import './ProductCard.css'
import { APIRequest, DELETE_PROPERTTLIST, UNFAVOURITE_PROPERTY, SAVE_PROPERTYFAVOURITE, GET_PROPERTYSEARCH} from '../../api'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import toast from 'react-simple-toasts';
import styled, { keyframes } from 'styled-components';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { setsearchproperty } from '../../redux/action'
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken'


export default function ProductCard(props) {  
  const user = useSelector(state => state.user);
  const searchproperty = useSelector(state => state.searchproperty);
  const [favourite ,Setfavourite]=useState(props?.listdata.isfavourite === "Y" ? true: false)
  const [show, setShow] = useState(false);
  const [propertiValue, setPropertiValue] = useState(searchproperty)
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();

 
  const deleteProperty = (data) => {
    new APIRequest.Builder()
      .post()
      .setReqId(DELETE_PROPERTTLIST)
      .jsonParams({
        "userid": user?.userid,
        "isactive": "N",
        "propertyid": data.propertyid
      })
      .reqURL("property/get_propertymaster")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }
  
  
  useEffect(() => {
    if(searchproperty){
    setPropertiValue([ ...searchproperty ]);
    }
  }, [searchproperty]);

  const unfavouriteProperty = (data) => {
    new APIRequest.Builder()
      .post()
      .setReqId(UNFAVOURITE_PROPERTY)
      .jsonParams({
        "userid": user?.userid,
        "isactive": "N",
        "propertyid": data.propertyid
      })
      .reqURL("property/save_propertyfavourite")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    }

    
const addFavourite = (data) => {
    if (user !== null) {
      new APIRequest.Builder()
      .post()
      .setReqId(SAVE_PROPERTYFAVOURITE)
      .jsonParams({
        "userid": user?.userid,
        "propertyid": data.propertyid,
      })
      .reqURL("property/save_propertyfavourite")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    }else{
      toast("For Add In Favourite List Login Required")
    }
  }
  
  const onResponse = (response, reqId) => {
    let newPropertiValue = [];
    switch (reqId) {
      case DELETE_PROPERTTLIST: 
        toast(`${response.data.massage}`  )    
        break;
      case UNFAVOURITE_PROPERTY:
        newPropertiValue = propertiValue.map(property => {
          if (property.propertyid.toString() === response.data.data.id.propertyid.toString()) {
            property.isfavourite = "N";
          }
          return property;
        });
        dispatch(setsearchproperty(newPropertiValue))
        Setfavourite(false)
        props.deletefavourite && props.deletefavourite(true)
        break;
      case SAVE_PROPERTYFAVOURITE:
        newPropertiValue = propertiValue.map(property => {
          if (property.propertyid.toString() === response.data.data.id.propertyid.toString()) {
            property.isfavourite = "Y";
          }
          return property;
        });
        dispatch(setsearchproperty(newPropertiValue))
        Setfavourite(true)
        break; 
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case DELETE_PROPERTTLIST:
        toast(`${response.data.massage}` )
        break;
      case UNFAVOURITE_PROPERTY:
        toast(`${response.data.massage}`)
        break;
      case SAVE_PROPERTYFAVOURITE:
        toast(`${response.data.massage}`)
        break;    
      default:
        break;
    }
   }
  
  const [priceText,setPriceText] = useState(`$ ${props.listdata.expected_monthly_rent} monthly `);
  const [days,setDays] = useState(`${props?.listdata?.isapproved === "Y" ? props.listdata.days_remaining +" " +"Days Left" : "$"+ props.listdata.expected_monthly_rent+" "+ "monthly" } `); 
      
  const pulse = keyframes`    
        0% {
            content:"${priceText}"
        }

        50% {
          content:"${days}"
        }

        100% {
          content:"${priceText}"
      }
      `
        const Bar = styled.div`
        &:after{
          content:"${priceText}";
        color: #fff;
        animation: ${pulse} 10s ease;
        animation-iteration-count:infinite  ;}
      `
  return (
    <>
      <div className="PropertyCard black10">
        <div className="propertyImageCOntainer">
      <Link to={`/property-details/${props?.listdata?.propertyid}`}   className='removeLinkDefaults'>
          <img src={props.path} className='w-100' alt="" />
          <button className='btnPrice fill-green00 white00 border-none px-3 py-2  full-radious' style={{display:props.onlyPrice,outline:"none"}} >$ {props?.listdata?.expected_monthly_rent} <span className='font-12'>monthly</span></button>
          
            <button className='fill-green00 white00 border-none px-3 py-2  full-radious animatePriceBtn' style={{display:props.daysLeft,outline:"none"}}>
              <Bar></Bar>  
            </button> 
            </Link>      
          {/* cross button */}
          <div className="heartBtn">
            {/* <button className='btnPrice fill-green00 white00 border-none py-2  full-radious' type='button' style={{ display: props.cross }} >days</button> */}
             </div>
           
          {/* unfavourite button */}
          {favourite ? <div className="heartBtn">
            <button className='favoheart red00' style={{ display: props.heart, outline: "none" }} onClick={() => unfavouriteProperty(props?.listdata)} ><i className="bi bi-heart-fill"></i></button> </div> :
            <div className="heartBtn">
              <button className='favoheart black00' type='button' onClick={() =>   user == null ? handleShow() : addFavourite(props?.listdata)} style={{ display: props.heart, outline: "none" }} ><i className="bi bi-heart-fill"></i></button> </div>}
           <div className="heartBtn">
            <button className='PropertyDispalyHeartBtn' type='button' onClick={() => unfavouriteProperty(props?.listdata)} style={{ display: props.unfavourite, outline: "none" }} >&#10006;</button> </div>   
          {/* heart button
          {/* <div className="heartBtn"><button className='PropertyDispalyHeartBtn' style={{ display: props.heart }} onClick={() => addFavourite(props?.listdata)} >&#10084;</button> </div> */}
          {/* outline heart code : &#9825; */}
        </div>
        <Link to={`/property-details/${props?.listdata?.propertyid}`}   className='removeLinkDefaults'>
          <div className='removeLinkDefaults'>
          <div className="metadataContainer m-2 pe-1">
            <p className='black00 font-regular m-0 text-truncate w-100 productCardPropertyName'>{props?.listdata?.propertyname}</p>
            <p className='black75  font-regular mt-1 font-14 productCardAddress'>{props?.listdata?.street_address} </p>
            <div className="d-flex justify-content-between">
              <p className='font-14 font-semibold black00 m-0'>{props?.listdata?.bedrooms_range}</p>
              <p className='font-14 font-semibold black00 m-0'>{props?.listdata?.bathrooms_range} Bath </p>
              <p className='font-14 font-semibold black00 m-0'>{props?.listdata?.total_area_in_sqft} Sq Ft</p>
            </div>
          </div>
         </div> 
         </Link>  
      </div>
      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Oops !!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <p className='textJustify'>
               Looks like you're not signed in. Please log in to save properties to your Favorites and enjoy a personalized experience. Don't have an account? Sign up now to start exploring your urban nest!
            </p>
        </Modal.Body>
        <Modal.Footer className='rowButton'>
        <Link to="/login" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Login</Link>
           <Link to="/signup" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Create account</Link>   
        </Modal.Footer>
      </Modal>
    </>
  )
}
