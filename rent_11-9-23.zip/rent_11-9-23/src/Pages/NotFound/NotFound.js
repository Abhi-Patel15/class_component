import React from 'react'
import { Link } from 'react-router-dom'
import '../../Common/common.css' 
import './NotFound.css'

export default function NotFound() {
  return (
    <>
    <div className='container-fluid '>
        <div className="notFoundContainer">
            <div className="subNotfound">
                <h1 className='header'>Oops !</h1>
                <p className='font-20 font-semibold'>404, Sorry the page you are looking dose not exist</p>
                <Link to="/" className='removeLinkDefaults px-5 py-2 border-none fill-green00 white00 '>Home</Link>
            </div>
        </div>
    </div>
    </>
  )
}
