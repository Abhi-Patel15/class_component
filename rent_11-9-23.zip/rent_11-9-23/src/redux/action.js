import {
    SET_TOKEN,
    SET_USER,
    LIST_PROPERTY1,
    LIST_PROPERTY2,
    LIST_PROPERTY3,
    COMPARE_PROPERTY,
    SEARCH_PROPERTY,
    STATE_CITY,
    COMPARE_PROPERTY_DELETE
    

} from "./action-types";

import {REHYDRATE} from 'redux-persist/lib/constants';
let initialState = {
    user: null,
    token: null,
    property1:null,
    property2:null,
    property3:null,
    compareproperty:null,
    searchproperty:null,
    statecity:null

};

export const setToken = (token) => ({type: SET_TOKEN, token});
export const setUser = (user) => ({type: SET_USER, user});
export const setproperty1 = (property1) => ({type: LIST_PROPERTY1,property1});
export const setproperty2 = (property2) => ({type: LIST_PROPERTY2,property2 });
export const setproperty3 = (property3) => ({type: LIST_PROPERTY3,property3});
export const setcompareproperty =(compareproperty)=>({type: COMPARE_PROPERTY,compareproperty});
export const setsearchproperty =(searchproperty)=>({type:SEARCH_PROPERTY,searchproperty});
export const setstatecity =(statecity)=>({type:STATE_CITY ,statecity})
export const logout = () => ({type: REHYDRATE, payload: initialState});
