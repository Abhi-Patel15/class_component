export const ADDRESS_TOKEN = "pk.eyJ1Ijoibml0aW5jaGlrYW5pIiwiYSI6ImNsaHJibHhpNTBkNnQzbG13dThzeWxuNTUifQ.n805py9K8WZqAdIbyBZu9g"
export const STATE_ERROR = 401
export const STATE_CODE404 = 404
export const STATE_ERROR500 = 500