import React, { useEffect, useState } from 'react';
import './ListProperty.css'
import '../../Common/common.css'
import { useFormik } from 'formik';
import * as Yup from "yup"
import { useDispatch, useSelector } from 'react-redux';
import { AMENITITES_COMMUTINY, APIRequest, AMENITITES_SMART, AMENITITES_ENERGY, UPLOAD_FILES, MULTI_UPLOAD_FILES, PROPERTY_MASTER_SAVE } from '../../api';
import LinearProgress from '@mui/material/LinearProgress';
import toast from 'react-simple-toasts';
import { setproperty2, setproperty3, setproperty1, logout } from '../../redux/action';
import Slider from "react-slick";
import { Link, useNavigate } from 'react-router-dom';
import Loading from '../../Components/Loading/Loading';
import Resizer from "react-image-file-resizer";
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';
import Modal from 'react-bootstrap/Modal';


export default function ListProperty4() {

    const MAX_FILE_SIZE = 10260 // 5MB

    const resizeFile = (file) =>
        new Promise((resolve) => {
            Resizer.imageFileResizer(
                file,
                1080,
                650,
                "JPEG",
                90,
                0,
                (uri) => {
                    resolve(uri);
                },
                "base64",
                
            );
        });

        const dataURIToBlob = (dataURI) => {
            const splitDataURI = dataURI.split(",");
            const byteString =
              splitDataURI[0].indexOf("base64") >= 0
                ? atob(splitDataURI[1])
                : decodeURI(splitDataURI[1]);
            const mimeString = splitDataURI[0].split(":")[1].split(";")[0];
          
            const ia = new Uint8Array(byteString.length);
            for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
          
            return new Blob([ia], { type: mimeString });
          };

    const property2 = useSelector(state => state.property2);
    const property3 = useSelector(state => state.property3);
    const property1 = useSelector(state => state.property1);
    const user = useSelector(state => state.user)
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [Ame_smaert, SetAme_smaert] = useState()
    const [Ame_energy, SetAme_energy] = useState()
    const [Ame_community, SetAme_community] = useState()
    const [enery_check, setenery_check] = useState(property1?.propertyAmenitiesEnergyEfficientList[0] ?? []);
    const [smart_check, setsmart_check] = useState(property1?.propertyAmenitiesSmartList[0] ?? []);
    const [community_check, setcommunity_check] = useState(property1?.propertyAmenitiesCommunityList[0] ?? []);
    const [property_image, setproperty_image] = useState(property1?.propertyImageList[0] ?? []);
    const [imagefile, Setimagefile] = useState(property1?.cover_image_url?.replace("D:\\khushal\\final rent\\rentwebsitereactjs\\public\\assets\\upload\\", '') ?? '');
    const [uploadsucess, SetUploadsucess] = useState(false);
    const [multiupload, Setmultiupload] = useState(false);
    const [slideshow, Setslideshow] = useState(1);
    const [multiuploaddata, Setmultiuploaddate] = useState("");
    const [loading, Setloading] = useState(false);
    const [smartOther, setSmartOther] = useState("")
    const [eneryOther, setEneryOther] = useState("")
    // const [error, setError] = useState()

    // const OtherValidationError = () => {
    //     let errors = []
    //     if(!smartOther){
    //         smartOther.error="text is reqerd"
    //     }
    // }
  
    const Inputsmart= smart_check.find((item)=> item.amenities_smart_id == 15)
    const Inputenery = enery_check.find((item)=>item.amenities_energy_efficient_id == 6)
    const settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: slideshow,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1750,
                settings: {
                    slidesToShow: slideshow > 1 ? `${slideshow - 1}` : 1,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 1440,
                settings: {
                    slidesToShow: slideshow > 2 ? `${slideshow - 2}` : 1,
                    slidesToScroll: 1,

                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: slideshow > 3 ? `${slideshow - 3}` : 1,
                    slidesToScroll: 2,
                    initialSlide: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: slideshow > 4 ? `${slideshow - 4}` : 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    useEffect(() => {
        new APIRequest.Builder()
            .post()
            .setReqId(AMENITITES_SMART)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/get_amenities_smart")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
        new APIRequest.Builder()
            .post()
            .setReqId(AMENITITES_ENERGY)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/get_amenities_energy_efficient")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
        new APIRequest.Builder()
            .post()
            .setReqId(AMENITITES_COMMUTINY)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/get_amenities_community")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
    }, [])
    const listproperty = useFormik({
        enableReinitialize: true,
        initialValues: {
            userid: user?.userid,
            propertyAmenitiesSmartList:
                [
                    {
                        amenities_smart_id: "",
                        amenities_smart: ""
                    }
                ],
            propertyAmenitiesEnergyEfficientList: [
                {
                    amenities_energy_efficient_id: "",
                    amenities_energy_efficient: ""
                }
            ],
            propertyAmenitiesCommunityList: [
                {
                    amenities_community_id: "",
                    amenities_community: ""
                }
            ],
            propertyImageList: [
                {
                    image_url: ""
                }
            ],
            cover_image_url: property1?.cover_image_url ?? "",
            virtual_tour_link: ""
        },
        validationSchema: Yup.object().shape({
            propertyImageList: Yup.array().min(4, " We kindly request at least 4 images to proceed").required("Required"),
            cover_image_url: Yup.string().required("Cover Image Required")
        }),
        onSubmit: value => {
            Setloading(true)
            const data = value.propertyAmenitiesSmartList.map((item)=>{
                if(item.amenities_smart_id == 15){
                    item.amenities_smart = smartOther
                }
                return item
            })
         
            const EneryData = value.propertyAmenitiesEnergyEfficientList.map((el)=>{
                if(el.amenities_energy_efficient_id == 6){
                    el.amenities_energy_efficient = eneryOther
                }
                return el
            })
            let finalvalue = { ...property2, ...property3, ...value }
            new APIRequest.Builder()
                .post()
                .setReqId(PROPERTY_MASTER_SAVE)
                .jsonParams(finalvalue)
                .reqURL("property/save_propertymaster")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    })


    const onResponse = async (response, reqId) => {
        switch (reqId) {
            case AMENITITES_SMART:
                SetAme_smaert(response?.data?.data)
                break;
            case AMENITITES_ENERGY:
                SetAme_energy(response?.data?.data)
                break;
            case AMENITITES_COMMUTINY:
                SetAme_community(response?.data?.data)
                break;
            case UPLOAD_FILES:
                Setimagefile(response.data.data)
                listproperty.setFieldValue('cover_image_url', response?.data?.data)
                SetUploadsucess(true)
                toast(`${response.data.massage}`)
                break;
            case MULTI_UPLOAD_FILES:
                Setmultiuploaddate(response)
                Setmultiupload(true)
                break;
            case PROPERTY_MASTER_SAVE:
                Setloading(false)
                dispatch(setproperty2(null));
                dispatch(setproperty3(null));
                dispatch(setproperty1(null));
                toast("Save Sucessfully")
                navigate('/my-account/my-listing');
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        if(response.data.status==STATE_ERROR){
            localStorage.clear()
            dispatch(logout())
            navigate("/login");
          }
        switch (reqId) {
            case AMENITITES_SMART:
                console.log(response)
                break;
            case AMENITITES_ENERGY:
                console.log(response)
                break;
            case AMENITITES_COMMUTINY:
                console.log(response)
                break;
            case UPLOAD_FILES:
                SetUploadsucess(false)
                toast(`${response.data.massage}`)
                break;
            case MULTI_UPLOAD_FILES:
                console.log(response)
                break;
            case PROPERTY_MASTER_SAVE:
                Setloading(false)
                toast("Property is not successfully saved")
                break;
            default:
                break;
        }
    }

    const FileUpload = async (e) => {
        const imageFile = e.target.files[0];

        const fileSizeKiloBytes = imageFile.size / 1024
        if (!imageFile) {
            toast("Please select image.");
            return false;
        }

        if (!imageFile.name.match(/\.(jpg|jpeg|png)$/)) {
            toast("We kindly ask you to choose images in JPG, JPEG, or PNG format. Thank you for your cooperation!");
            return false;
        }

        if (fileSizeKiloBytes > MAX_FILE_SIZE) {
            toast("File Size Should not greater than 10MB");
            return false;
        }

        try {
            const image = await resizeFile(imageFile);        
            const newFile = dataURIToBlob(image);
            SetUploadsucess(true)
            var data = new FormData();
            
            var file = newFile;
            data.append("image", file);
            new APIRequest.Builder()
                .post()
                .setReqId(UPLOAD_FILES)
                .jsonParams(data)
                .reqURL(`master/uploadfile`)
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();

        }
        catch (err) {
            console.log(err);
        }
        
    }
   
    const multiFileUpload = (e) => {
        Object.entries(e.target.files)?.map(async (item, id) => {
            const imageFile = item[1];

            const fileSizeKiloBytes = imageFile.size / 1024
            if (!imageFile) {
                toast("Please select image.");
                return false;
            }

            if (!imageFile.name.match(/\.(jpg|jpeg|png)$/)) {
                toast("We kindly ask you to choose images in JPG, JPEG, or PNG format. Thank you for your cooperation!");
                return false;
            }

            if (fileSizeKiloBytes > MAX_FILE_SIZE) {
                toast("File Size Should not greater than 10MB");
                return false;
            }

            try {
            const image = await resizeFile(imageFile);            
            const newFile = dataURIToBlob(image);

            var m_data = new FormData();
            var m_file = newFile;
            m_data.append("image", m_file);
            new APIRequest.Builder()
                .post()
                .setReqId(MULTI_UPLOAD_FILES)
                .jsonParams(m_data)
                .reqURL('master/uploadfile')
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
            e.preventDefault();
            }
            catch (err) {
                console.log(err);
            }
        })

    }

    useEffect(() => {
        property_image.length === 0 ? Setmultiupload(false) : Setmultiupload(true)
        imagefile ? SetUploadsucess(true) : SetUploadsucess(false)
        listproperty.setFieldValue('propertyAmenitiesEnergyEfficientList', enery_check)
        listproperty.setFieldValue('propertyAmenitiesCommunityList', community_check)
        listproperty.setFieldValue('propertyAmenitiesSmartList', smart_check)
        listproperty.setFieldValue('propertyImageList', property_image)
        enery_check.map((item)=>{
            if( item.amenities_energy_efficient_id == 6){
                setEneryOther(item.amenities_energy_efficient)
            }
        })
        smart_check.map((item)=>{
            if( item.amenities_smart_id == 15){
                setSmartOther(item.amenities_smart)
            }
        })
    }, [enery_check, community_check, smart_check, property_image])

    useEffect(() => {
        if (property_image.length === 0) {
            Setslideshow(1)
        } else if (property_image.length === 1) {
            Setslideshow(1)
        } else if (property_image.length === 2) {
            Setslideshow(2)
        } else if (property_image.length === 3) {
            Setslideshow(3)
        } else if (property_image.length === 4) {
            Setslideshow(4)
        } else if (property_image.length === 5) {
            Setslideshow(5)
        } else {
            Setslideshow(5)
        }

    }, [property_image])

    useEffect(() => {
        if (multiuploaddata) {
            const propertydata = [...property_image, { image_url: multiuploaddata?.data?.data }]
            setproperty_image(propertydata)
        }

    }, [multiuploaddata])

    const multiimageDelete = (id) => {
        const newproperty = [
            ...property_image.slice(0, id),
            ...property_image.slice(id + 1)
        ]
        setproperty_image(newproperty)
    }

    const coverImageDelete = (id) => {
        SetUploadsucess(false);
        Setimagefile([]);
        listproperty.setFieldValue('cover_image_url', '')
    }
    return (
        <>
            {loading && <Loading />}
            <div className="main">
                <div className='listPropertyContainer marginMain'>
                    <div className="container-fluid">
                        <h2 className='page-heading'>{property2?.propertyid ? "Update" : "List"}<span className='font-semibold'>Property</span></h2>

                        {/* progress bar */}
                        <div className="row my-5 progressBar">
                            <div className="d-flex">
                                <div className='me-4'>
                                    <p className='font-semibold green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property") }}>1. Personal Information</p>
                                    <div className='progresBar fill-green00'></div>
                                </div>
                                <div className='me-4'>
                                    <p className='font-semibold green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property2") }}>2. Property Information</p>
                                    <div className='progresBar fill-green00'></div>
                                </div>
                                <div className='me-4'>
                                    <p className='font-semibold green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property3") }}>3. Property Description</p>
                                    <div className='progresBar fill-green00'></div>
                                </div>
                                <div className='me-4'>
                                    <p className='font-semibold black00 mb-1'>4. Amenities and Pictures</p>
                                    <div className='progresBar fill-white25'></div>
                                </div>
                            </div>
                        </div>

                        <div className="row mt-2 progressBarTab">
                            <div className="round activate " onClick={() => { navigate("/list-property") }}>1</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property2") }}>2</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property3") }}>3</div>
                            <div className="Line"></div>
                            <div className="round activate ">4</div>
                        </div>
                        <div className="listFormContainer w-100 fill-white25 mt-3">
                            <form onSubmit={listproperty.handleSubmit}>
                                <div className="container-fluid pb-5">
                                    {/* form */}
                                    <div className="row">
                                        <div className="row mt-5  ">
                                            <label className='green00 font-semibold' htmlFor=""> Amenities</label><br />
                                            <div className="col-12 mt-2 mb-2">
                                                        <label className='green00 font-semibold' htmlFor=""> Smart Home Amenities</label><br />
                                                    </div>
                                            <div className="amenitiescontainer m-0 fill-white00">
                                                <div className="row p-3"> 
                                                    {Ame_smaert?.map((item, id) =>
                                                        <div className="col-md-4 col-sm-6 col-12  ">
                                                            <div className="d-flex">
                                                                <input key={id} type="checkbox" className='checkbox' name="" id=""
                                                                    defaultChecked={property1?.propertyAmenitiesSmartList[0].find(value => value.amenities_smart_id === item?.amenities_smart_id) ? true : false}
                                                                    onChange={(e) => {
                                                                        // add to list
                                                                        if (e.target.checked) {
                                                                            setsmart_check([
                                                                                ...smart_check,
                                                                                {
                                                                                    amenities_smart_id: item.amenities_smart_id,
                                                                                    amenities_smart: item.amenities_smart,
                                                                                },
                                                                            ]);
                                                                        } else {
                                                                            // remove from list
                                                                            setsmart_check(
                                                                                smart_check.filter((people) => people.amenities_smart_id !== item.amenities_smart_id),
                                                                            );
                                                                        }
                                                                    }} />
                                                                <p className='amenitiesText'>{item?.amenities_smart ?? ""}</p>
                                                            </div>   
                                                        </div>
                                                    )}
                                                  
                                                    <div className='d-flex justify-content-end w-100'>
                                                   { Inputsmart && <input 
                                                    type="text" 
                                                    className="shadow-none fill-white25 removeRadious  form-control border-black25 OtherInput" 
                                                    name='smartOther' 
                                                    value={smartOther}
                                                     defaultValue="Inputsmart"
                                                    onChange={e=>setSmartOther(e.target.value)} 
                                                    placeholder='other' 
                                                    />} 
                                                  </div> 
                                                </div>
                                                
                                            </div>
                                            <div className="col-12 mt-2 mb-2">
                                            <label className='green00 font-semibold' htmlFor=""> Energy-Efficient Amenities</label><br />
                                            </div>
                                            <div className="amenitiescontainer m-0  fill-white00">
                                                <div className="row p-3">
                                                    {Ame_energy?.map((item, id) =>
                                                        <div className="col-md-4 col-sm-6 col-12  ">
                                                           
                                                            <div className="d-flex" >
                                                                <input key={id} type="checkbox" className='checkbox' name="" id="" value={item}
                                                                    defaultChecked={property1?.propertyAmenitiesEnergyEfficientList[0].find(value => value.amenities_energy_efficient_id === item?.amenities_energy_efficient_id) ? true : false}
                                                                    onChange={(e) => {
                                                                        // add to list
                                                                        if (e.target.checked) {
                                                                            setenery_check([
                                                                                ...enery_check,
                                                                                {
                                                                                    amenities_energy_efficient_id: item.amenities_energy_efficient_id,
                                                                                    amenities_energy_efficient: item.amenities_energy_efficient,
                                                                                },
                                                                            ]);
                                                                        } else {
                                                                            // remove from list
                                                                            setenery_check(
                                                                                enery_check.filter((people) => people.amenities_energy_efficient_id !== item.amenities_energy_efficient_id),
                                                                            );
                                                                        }
                                                                    }} />
                                                                <p className='amenitiesText'>{item?.amenities_energy_efficient ?? ""}</p>
                                                            </div>
                                                        </div>
                                                    )}
                                                    <div className='d-flex justify-content-end'>
                                                    {Inputenery && <input 
                                                     type="text"    
                                                     name='eneryOther'
                                                     value={eneryOther}
                                                     onChange={e=>setEneryOther(e.target.value)}
                                                     className="shadow-none  fill-white25 removeRadious  form-control border-black25 OtherInput" 
                                                     placeholder='other' /> }
                                                    </div> 
                                                </div>
                                            </div>
                                            <div className="col-12 mt-2 mb-2">
                                            <label className='green00 font-semibold' htmlFor="">In-unit or Community Amenities </label><br />
                                            </div>
                                            <div className="amenitiescontainer m-0  fill-white00">
                                                <div className="row p-3">
                                                    {Ame_community?.map((item, id) =>
                                                        <div className="col-md-4 col-sm-6 col-12  ">
                                                            <div className="d-flex" key={id}>
                                                                <input type="checkbox" className='checkbox' name="" id=""
                                                                    defaultChecked={property1?.propertyAmenitiesCommunityList[0].find(value => value.amenities_community === `${item?.amenities_community}`) ? true : false}
                                                                    onChange={(e) => {
                                                                        // add to list
                                                                        if (e.target.checked) {
                                                                            setcommunity_check([
                                                                                ...community_check,
                                                                                {
                                                                                    amenities_community_id: item.amenities_community_id,
                                                                                    amenities_community: item.amenities_community,
                                                                                },
                                                                            ]);
                                                                        } else {
                                                                            // remove from list
                                                                            setcommunity_check(
                                                                                community_check.filter((people) => people.amenities_community_id !== item.amenities_community_id),
                                                                            );
                                                                        }
                                                                    }} />
                                                                <p className='amenitiesText'>{item?.amenities_community ?? ""}</p>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>

                                            </div>
                                        </div>

                                        {/* imageupload */}
                                        <div className="row mt-5 text-center">
                                            <div className="col-md-5 col-sm-6 col-12">
                                                <div className="imageUploadContainer">

                                                    {uploadsucess && <> <div className="customContainer">
                                                        <img src={`${imagefile}`} className="img-fluid p-2" />
                                                        <button className='buttonCross' type='buttton' onClick={() => coverImageDelete(imagefile)}>&#128473;</button>
                                                    </div> <button type="button" className='border-none fill-green00 white00 px-3 py-1 btn font-14 py-2 mb-1'>Upload Images</button></>}
                                                    {!uploadsucess && <h6 className='black75'>Upload Property’s Cover Image Here*</h6>}
                                                    <div className="upload-btn-wrapper">
                                                        {!uploadsucess && <button className="border-none fill-green00 white00 px-3 py-1 btn font-14 py-2">Upload Image</button>}
                                                        {!uploadsucess && listproperty.touched.cover_image_url && listproperty.errors.cover_image_url ? (
                                                            <><br /> <span className="error">{listproperty.errors.cover_image_url}</span></>
                                                        ) : null}

                                                        {!uploadsucess && <form encType="multipart/form-data" action="">
                                                            <input type="file" name="cover_image_url" id="picture" onChange={FileUpload} accept="image/png, image/jpg, image/jpeg" />

                                                        </form>}

                                                    </div>
                                                </div>
                                            </div>



                                            <div className="col-md-7 mt-sm-0 mt-1  col-sm-6 col-12">
                                                <div className="imageUploadContainer2">

                                                    {/*NOTE this is for upload button and peragraph  */}

                                                    {!multiupload && <div className="uploadButtonsContainer">
                                                        <h6 className='black75'>Upload Property’s Images Here*</h6>
                                                        <div className="upload-btn-wrapper">
                                                            <button type='button' className='border-none fill-green00 white00 px-3 py-1 btn font-14 py-2'>Upload Images</button>
                                                            {listproperty.touched.propertyImageList && listproperty.errors.propertyImageList ? (
                                                                <><br /> <span className="error">{listproperty.errors.propertyImageList}</span></>
                                                            ) : null}
                                                            <input type="file" name="filefield" onChange={multiFileUpload} accept="image/png, image/jpg, image/jpeg" multiple />

                                                        </div>
                                                    </div>}


                                                    {/* NOTE this is for slider  */}

                                                    {multiupload && <div className='parentMultiImage'>
                                                        <Slider {...settings} className="MultiImageSlider">
                                                            {property_image?.map((item, id) =>
                                                                <div className='sliderUploadedImageContainer'>
                                                                    <img key={id}
                                                                        src={`${item?.image_url}`} />
                                                                    <button className='buttonCross' type="button" onClick={() => multiimageDelete(id)}>&#128473;</button>
                                                                </div>
                                                            )}
                                                        </Slider>

                                                        <div className="upload-btn-wrapper mt-3">
                                                            <button type='button' className='border-none fill-green00 white00 px-3 py-1 btn font-14 py-2'>Upload Images</button>
                                                            <br /> {listproperty.touched.propertyImageList && listproperty.errors.propertyImageList ? (
                                                                <span className="error">{listproperty.errors.propertyImageList}</span>
                                                            ) : null}
                                                            <input type="file" name="filefield" onChange={multiFileUpload} accept="image/png, image/jpg, image/jpeg" multiple />

                                                        </div>
                                                    </div>}

                                                </div>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-md-6 col-sm-12  mt-3 ">
                                                <label className='green00 mb-1' htmlFor="">Add virtual tour link</label><br />
                                                <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25'
                                                    name="virtual_tour_link" id='virtual_tour_link' defaultValue={property1?.virtual_tour_link} onChange={listproperty.handleChange} />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <button type='submit' className='submitbutton border-none fill-green00 white00 px-3 py-2 text-center removeLinkDefaults'> Submit </button>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
