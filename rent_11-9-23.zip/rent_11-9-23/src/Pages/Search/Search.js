import React, { useState, useRef, useEffect } from 'react'
import './Search.css'
import Filter from '../../Components/Filter/Filter';
import ProductCard from '../../Components/ProductCard/ProductCard';
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import { APIRequest, PROPERTYSEARCH_FREETEXT,ADDRESS_SUGGESTION } from '../../api';
import { BiSearch } from 'react-icons/bi';
import { useFormik } from 'formik';
import toast from 'react-simple-toasts';
import { useDispatch, useSelector } from 'react-redux';
import { StandaloneSearchBox, LoadScript } from "@react-google-maps/api";
import Modal from 'react-bootstrap/Modal';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';
import { setstatecity } from '../../redux/action';
import { createRef } from 'react';
export default function Search() {
  const dispatch = useDispatch();
  const [properylist, Setpropertylist] = useState([]);
  const [listdata, SetListdata] = useState();
  const [citylist, Setcitylist] = useState([]);
  const [filteredCitylist, SetFilteredCitylist] = useState([]);
  const [unfavourite, Setunfavourite] = useState(false);
  const [nofound, Setnofound] = useState(false);
  const [address, Setaddress] = useState("");
  const user = useSelector(state => state.user);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [suggestionFocus, setSuggestionFocus] = useState(null);

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(ADDRESS_SUGGESTION)
      .jsonParams({
        "street_address": address
      })
      .reqURL("property/get_propertysearch_keyword")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [])
  const searchform = useFormik({
    initialValues: {
      login_userid: user?.userid,
      street_address: address
    },  
    onSubmit: values => {   
        new APIRequest.Builder()
        .post()
        .setReqId(PROPERTYSEARCH_FREETEXT)
        .jsonParams(values)
        .reqURL("property/get_propertysearch_freetext")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
        dispatch(setstatecity(values))
      },
    });
   
  const onResponse = (response, reqId) => {
    switch (reqId) {
      case PROPERTYSEARCH_FREETEXT:
          // toast(`${response?.data?.massage}`)
        if (response?.data?.issuccess) {                   
          Setpropertylist(response?.data?.data)
          SetListdata(response?.data?.data)
          Setnofound(true)
        }
        else {
          toast(`${response?.data?.massage}`)
          Setnofound(true)
        }
        break;
        case ADDRESS_SUGGESTION:
          Setcitylist(response.data.data)
          break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case PROPERTYSEARCH_FREETEXT:
        // setShow(true)
        Setnofound(true)
        break;
        case ADDRESS_SUGGESTION:
          Setcitylist(response.data.data)
          break;
      default:
        break;
    }
  }
  const navigate = useNavigate();
  const [suggestion, setSuggestion] = useState(false);

  useEffect(() => {
    if (address) {
      SetFilteredCitylist([
        ...citylist.filter(post => post.street_address.toLowerCase().includes(address.toLowerCase())),
      ]);
    }
    else {
      SetFilteredCitylist([ ...citylist ]);
    }
  }, [address])

  useEffect(() => {
    SetFilteredCitylist([ ...citylist ]);
  }, [citylist]);

  const autofill =(data)=>{
    searchform.setFieldValue("street_address", data)
    setSuggestion(false)
  }

  const handleKeyDown = (e) => {
    const keyCode = e.keyCode;
    if (keyCode === 38 ) {
      // arrow up key
      let nextFocus = (suggestionFocus ?? 0) - 1;
      if (nextFocus < 0) nextFocus = 0;
      setSuggestionFocus(nextFocus);
    } else if (keyCode === 40) {
      // arrow down key
      let nextFocus = (suggestionFocus ?? -1) + 1;
      if (nextFocus >= filteredCitylist.length) nextFocus = filteredCitylist.length - 1;
      setSuggestionFocus(nextFocus);
    }
    else if (keyCode === 13 ) {
      // enter key
      let addressData = searchform.values.street_address;
      if (suggestion) {
        e.preventDefault();
        addressData = filteredCitylist[suggestionFocus]?.street_address ?? searchform.values.street_address;
      }
      autofill(addressData);
    }
  }

  let menuRef = useRef();
  useEffect(() => {
    let handler = (event) => {
      if (!menuRef.current.contains(event.target)) {
        setTimeout(() => {
          setSuggestion(false)
        }, 200); 
      }
    }
    document.addEventListener("mousedown", handler);
    return () => {
      document.removeEventListener("mousedown", handler)
    }
  })

  useEffect(() => {
    setShow(nofound && properylist.length === 0);
  }, [nofound, properylist]);

  const handleChange = () => {
    setSuggestion(true)
  }
  const searchError = () => {
  if(listdata.length === 0){
    setShow(true)
  }
}

  return (
    <>
      <div className='main'>
        <div className="searchContainer marginMain mb-4">
          <div className="container">
            <div className="row ">
              <div className="col-12 p-0">
                <form onSubmit={searchform.handleSubmit} className="searchFrom">
                  <div ref={menuRef} className="d-flex mt-0 ms-2">                   
                        <input type="text" className='searchPageInput' placeholder='Search here...'
                          name='street_address' value={searchform.values.street_address}
                          onChange={e => {
                            setSuggestionFocus(null);
                            searchform.setFieldValue("street_address" ,e.target.value)
                            Setaddress(e.target.value);
                            handleChange();
                          }}
                          onKeyDown={handleKeyDown}
                          autoComplete={"off"}
                        />
                          <div className="suggestions suggestions_Search mt-2" style={{ display: !suggestion ? 'none' : 'block' }}>
                            {
                              filteredCitylist.map((data, key) =>
                                <button type ="button" varient ="primery"
                                onClick={()=>{searchform.setFieldValue("street_address" ,data?.street_address); setSuggestion(false); }} className={`singleSearchSuggestion ` + (suggestionFocus === key ? "active" : "")} 
                                style={{color:"black"}} key={"city_" + key}>{data?.street_address}</button>)
                            }
                          </div>                        

                        {/* {citylist?.filter(post => {
                        if (address === '') {
                          
                        } else if (post.street_address.toLowerCase().includes(address.toLowerCase())) {
                          return post;
                        }
                      })?.map((data, key) =>           
                          <button key ={key} type ="submit"  onClick={() => { searchform.setFieldValue("street_address" ,data?.street_address); setSuggestion(false);}} className='mb-1 singleSearchSuggestion' style={{color:"black"}}>
                           { data?.street_address}</button> 
                           )}                                                     */}
                           {/* </div>                     */}
                           {/* <BiSearch className='font-20 white00  ' /> */}
                    <button className='searchButton mt-0 fill-green00 removeRadious  border-none'  type='submit'><BiSearch className='font-20 white00'/></button>
                  </div>
                </form>
              </div>
            </div>
            <div className="row">
              {nofound && properylist.length !== 0 && <p className='font-14 black50 mb-0 mt-3' >Your recent searches</p>}
              {nofound && properylist.length === 0 && <p className='font-20 font-bold green00 text-center mt-5'>No Property Found !!!</p>}
              {properylist?.map((item, id) =>
                <div className="col-xxl-3 col-md-4 col-sm-6 col-12 ">
                  <div className="card-shadow">
                    <ProductCard listdata={listdata[id]}
                      path={`${item.cover_image_url}`}
                      heart="block" cross="none" unfavourite="none" daysLeft="none" onlyPrice="block" />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Oops !!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <p className='textJustify'>
            Sorry, we couldn't find any properties that match your search. Don't give up just yet! Try adjusting your filters or expanding your search area to find the urban nest you're looking for. Our listings are constantly updating.
            </p>
        </Modal.Body>
        <Modal.Footer>
           <button className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end' onClick={handleClose}>Okay</button>   
        </Modal.Footer>
      </Modal>
      {/* <Footer/> */}
    </>
  )
}
