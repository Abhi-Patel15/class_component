import { useFormik } from 'formik'
import {React,useState} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import toast from 'react-simple-toasts';
import * as Yup from "yup"
import { APIRequest, PROFILE_UPDATE } from '../../api'
import { logout, setUser } from "../../redux/action";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import './Myprofile.css'
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';
import { useNavigate } from 'react-router-dom';
export default function MyProfile() {

    const dispatch = useDispatch();
    const navigate = useNavigate()
    const user =useSelector(state=>state.user);

    const profile = useFormik({
        enableReinitialize: true,
        initialValues: {
            emailid: user?.emailid??"",
            firstname:user?.firstname?? "",
            lastname: user?.lastname?? "",
            mobileno: user?.mobileno?? "",
            mode: "update"
        },
        validationSchema: Yup.object().shape({
            // emailid: Yup.string().email('Please enter valid email').required(" Enter Email"),
            firstname: Yup.string().required(" Enter First Name").min(3, "Enter Minimum 3 Character"),
            lastname: Yup.string().required(" Enter Last Name").min(3, "Enter Minimum 3 Character"),
            mobileno:Yup.string().required(" Enter Number").length(10, " Enter 10 Digit Number").matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
                "Phone number is not valid"
            )

        }), onSubmit: values => {           
            new APIRequest.Builder()
                .post()
                .setReqId(PROFILE_UPDATE)
                .jsonParams(values)
                .reqURL("user/signup")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    })
    const onResponse = (response, reqId) => {
        switch (reqId) {
            case PROFILE_UPDATE:
                if (response.data.issuccess) {
                    toast(`${response.data.massage}`)
                    dispatch(setUser(response.data.data))
                }else{
                    toast.error(`${response.data.massage}`)  }
                break;
            default:
                break;
        }
    }
 
    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        if(response.data.status==STATE_ERROR){
            localStorage.clear()
            dispatch(logout())
            navigate("/login");
          }
        switch (reqId) {
            case PROFILE_UPDATE:
                toast("Profile is not successfully updated");
                break;
            default:
                break;
        }
    }

    const [deleteConfirm, setDeleteConfirm] = useState(false);
    const handleClose = () => setDeleteConfirm(false);
    const handleShow = () => setDeleteConfirm(true);


    return (
        <>
            <div className="myProfileContainer pb-5">
                <h4 className='mt-5 ms-3 mb-3'>My Profile</h4>
                <form onSubmit={profile.handleSubmit}>
                    <div className="row ps-3">
                        <div className="col-xl-4 col-md-5 col-md-6 col-12 mb-3">
                            <label className='green00 mb-2' htmlFor="emailid">Email*  </label><br />
                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25'
                                id='emailid'
                                name='emailid'
                                onChange={profile.handleChange}
                                value={profile.values.emailid} />
                            {profile.touched.emailid && profile.errors.emailid ? (
                                <span className="error">{profile.errors.emailid}</span>
                            ) : null}
                        </div>
                         <div className="col-md-6 col-12">  </div>

                        <div className="col-xl-4 col-md-5 col-md-6 col-12 mb-3">
                            <label className='green00 mb-2' htmlFor="firstname">First Name*</label><br />
                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25'
                                id='firstname'
                                name='firstname'
                                onChange={profile.handleChange}
                                value={profile.values.firstname} />
                            {profile.touched.firstname && profile.errors.firstname ? (
                                <span className="error">{profile.errors.firstname}</span>
                            ) : null}
                        </div>
                        <div className="col-md-6 col-12">  </div>

                        <div className="col-xl-4 col-md-5 col-md-6 col-12 mb-3">
                            <label className='green00 mb-2' htmlFor="lastname">Last Name*</label><br />
                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25'
                                id='lastname'
                                name='lastname'
                                onChange={profile.handleChange}
                                value={profile.values.lastname} />
                            {profile.touched.lastname && profile.errors.lastname ? (
                                <span className="error">{profile.errors.lastname}</span>
                            ) : null}
                        </div>
                        <div className="col-md-6 col-12">  </div>

                        <div className="col-xl-4 col-md-5 col-md-6 col-12 mb-3">
                            <label className='green00 mb-2' htmlFor="contactno"
                           >Contact No.*</label><br />
                           <div className='d-flex'>
                            <input value='+1' className='shadow-none fill-white25 removeRadious  border-black25  profileContect' disabled />
                            <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25'
                             id='mobileno'
                             name='mobileno'
                             onChange={profile.handleChange}
                             value={profile.values.mobileno}
                              />
                              </div>
                               {profile.touched.mobileno && profile.errors.mobileno ? (
                                <span className="error">{profile.errors.mobileno}</span>
                            ) : null}
                        </div>
                        <div className="col-md-6 col-12">  </div>

                        <div className="col-xl-4 col-md-5 col-md-6 col-12 mb-3 text-center">
                            <button type='submit' variant="primary" className='fill-green00 border-none white00 px-3 py-2 mt-3'>Update</button>
                        </div>
                    </div>
                </form>
                {/* <div className="row mt-5 ms-2 deleteContainer">
                    <p className='black75 font-semibold font-14 mb-1'>Close Account</p>
                    <p className='warningText  red00'>This will remove your login information from our system and you will not be able to login again. It cannot be undone.</p>
                    <button type='button' className='deleteAccountButton ms-3' onClick={handleShow} >Delete Account</button>        
                </div> */}
 
                
                     <Modal centered  show={deleteConfirm} onHide={handleClose}>
                        <Modal.Header >
                            <Modal.Title> <h5 className='red00'>Delete Account</h5></Modal.Title> 
                        </Modal.Header>
                        <Modal.Body>Are you sure, you want to delete this account ?</Modal.Body>
                        <Modal.Footer>
                            <button  className='border-none px-3 py-2 font-14 fill-red00 white00' onClick={handleClose}>Delete</button>
                            <button  className='border-none px-3 py-2 font-14' onClick={handleClose}>Cancel</button>
                        </Modal.Footer>
                    </Modal> 
                    {/*---*/}
            </div>
        </>
    )
}
