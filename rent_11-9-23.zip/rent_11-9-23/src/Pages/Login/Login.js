import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap';
import './Login.css'
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import { LOGIN, APIRequest, SIGNUP_SOCIAL, GUEST_LOGIN ,HOMEPAGE_SLIDER } from '../../api';
import { useSelector, useDispatch } from 'react-redux'
import { setToken, setUser } from "../../redux/action";
import toast from 'react-simple-toasts';
import { AiFillEyeInvisible, AiFillEye } from 'react-icons/ai'
import {AiOutlineHome} from 'react-icons/ai'
import {FcGoogle} from 'react-icons/fa'
import Loading from '../../Components/Loading/Loading'
import GoogleLogin from 'react-google-login';
import { gapi } from 'gapi-script'

export default function Login() {

    const email = localStorage.getItem("Email");
    const pwd =localStorage.getItem('pwd');
    const [homepage, Sethomepage] = useState(); 


    const dispatch = useDispatch()
    const navigate = useNavigate();
    const [password, Setpassword] = useState(false);
    const [passwordlength, Setpasswordlength] = useState();
    const [loading, Setloading] = useState(false);
    const [ischeck ,Setischeck] =useState(false);
 
    useEffect(() => {
        const initClient = () => {
            gapi.client.init({
                clientId: process.env.REACT_APP_GOOGLE_CLIENT_ID,
                scope: ''
            });
        };
        gapi.load('client:auth2', initClient);

        
       
        new APIRequest.Builder()
            .post()
            .setReqId(GUEST_LOGIN)
            .jsonParams({
                "emailid": "guest@rent.com",
                "password": "Guest@123"
            })
            .reqURL("user/signin")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
             
            new APIRequest.Builder()
            .post()
            .setReqId(HOMEPAGE_SLIDER)
            .jsonParams({
                "pagename": "SINGIN"
            })
            .reqURL("master/gethomepagemaster")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
    }, []);

    const onSuccess = (res) => {

        new APIRequest.Builder()
            .post()
            .setReqId(SIGNUP_SOCIAL)
            .jsonParams({
                firstname: res.profileObj.givenName,
                lastname: res.profileObj.familyName,
                emailid: res.profileObj.email,
                usertype: "USER",
                loginplatform: "google"
            })
            .reqURL("user/signup_social")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();

    };
    const onFailure = (err) => {
        console.log('error', err)
      if(err.error =="popup_closed_by_user"){
        toast("Log In was not successful. Please try again or contact support for assistance. ");
      }
    };



    const login = useFormik({
        enableReinitialize:true,
        initialValues: {
            emailid: email ?? "",
            password:pwd ?? ""
        },
        onSubmit: values => {
            passwordlength && new APIRequest.Builder()
                .post()
                .setReqId(LOGIN)
                .jsonParams(values)
                .reqURL("user/signin")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
            passwordlength && Setloading(true);
        }
    });

    useEffect(() => {
        Setpasswordlength(login.values.password.length)
    }, [login.values.password.length])


    const onResponse = (response, reqId) => {
        switch (reqId) {
            case LOGIN:
                if (response.data.data?.accessToken) {
                    dispatch(setToken(response.data.data.accessToken))
                    dispatch(setUser(response.data.data.userdetail))
                    ischeck && localStorage.setItem("Email" ,response.data.data.userdetail.emailid)
                    ischeck && localStorage.setItem("pwd" , login.values.password)
                    Setloading(false)

                } else {
                    dispatch(setUser(response.data.data))
                    Setloading(false)
                }
                if (response.data.issuccess) {
                    if (passwordlength <= 7) {
                        toast("Update Password");
                        navigate("/CreatePassword")
                        Setloading(false)
                    } else {
                        navigate("/")
                        login.resetForm();
                    }
                } else {
                    toast(`${response.data.massage}`)
                    Setloading(false)
                }
                break;
            case SIGNUP_SOCIAL:
                if (response.data.issuccess) {
                    toast("Login Sucessfully");
                    navigate("/");
                    dispatch(setUser(response.data.data))
                    Setloading(false)
                } else {
                    toast(`${response.data.massage}`)
                    Setloading(false)
                }
                break;
            case GUEST_LOGIN:
                if (response.data.data?.accessToken) {
                    dispatch(setToken(response.data.data.accessToken))
                }
                break;
                case HOMEPAGE_SLIDER:
                    Sethomepage(response.data.data[0]);
                    break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        switch (reqId) {
            case LOGIN:
                Setloading(false)
                break;
            case SIGNUP_SOCIAL:
                toast(`${response.data.massage}`)
                break;
            case GUEST_LOGIN:
                toast(`${response.data.massage}`)
                break;
                case HOMEPAGE_SLIDER:
                    console.log(response.data.data[0]);
                    break;
            default:
                break;
        }
    }

    const [loginShow, setLoginShow] = useState(false);
    const handleLoginPassShow = () => {
        if (loginShow === true) {
            setLoginShow(false)
        }
        else {
            setLoginShow(true)
        }
    }
  
    return (
        <>
            {loading && <Loading />}
            <div className="container-fluid">
                <div className="row">
                    <div className="d-none d-md-block col-md-6 p-0 order-md-1 order-2">
                        <div className="login_image_container m-0 p-0">
                            <img src={homepage?.imageurl === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/HomeMain.png` : `${homepage?.imageurl}`} className='loginImg ' alt="" />
                        </div>
                    </div><div className="col-md-6 p-0 order-md-2 order-1">
                        <form onSubmit={login.handleSubmit}>

                            <div className="login_form_container pt-2">
                            <Link to="/" className='removeLinkDefaults text-white ms-4 mt-2 font-20'><AiOutlineHome/></Link>
                                <h1><span className='font-semibold'>Login</span> Here</h1>

                                <div className='inputGroup mb-4'>
                                    <label className='label-ph mb-1' htmlFor="emailid">Email</label><br />
                                    <input className='input-light' type="text"
                                        id='emailid'
                                        name='emailid'
                                        onChange={login.handleChange}
                                        value={login.values.emailid}
                                        required />
                                </div>
                                <div className='inputGroup passwordContainer mb-4'>
                                    <label className='label-ph mb-1' htmlFor="password">Password</label><br />
                                    <input className='input-password' type={loginShow == true ? "text" : "password"}
                                        id='password'
                                        name='password'
                                        onChange={login.handleChange}
                                        value={login.values.password}
                                        required />
                                    <button type="button" className='bg-none border-none eyeIcon mt-2' onClick={handleLoginPassShow}>{loginShow == true ? <AiFillEyeInvisible /> : <AiFillEye />}</button>
                                </div>
                                <div className='keepLogin mb-4'>
                                    <div className="d-flex">
                                        <input type="checkbox" className='checkbox_login' name="" id=""  onChange={(e)=> {
                                            if(e.target.checked){
                                                Setischeck(true)
                                            }else{
                                                Setischeck(false)
                                            }
                                        } }/>
                                        <label className='smallTextLabel' htmlFor="">Keep me logged in</label>
                                    </div>
                                    <Link  className="white00" to="/Forgot">Forgot Password ?</Link>
                                </div>
                                <div className='group3'>
                                    <button type='submit' variant="primary" className='loginBTN'>Login</button><br />
                                    <label className='orLabel'>or</label><br />
                                    <GoogleLogin
                                        className='googleBTN whiteHover py-4'
                                        clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
                                        buttonText="Login with google"
                                        onSuccess={onSuccess}
                                        onFailure={onFailure}
                                        cookiePolicy={'single_host_origin'}
                                        isSignedIn={false}
                                    ></GoogleLogin>
                                    {/* <button variant="secondary" type='button' className='googleBTN whiteHover'>Log in with Google</button> */}
                                    <br /></div>

                                <p className='text-center signupLink  mt-3 px-4 '>Don’t have account yet ? 
                               <br /> <Link to="/signup" className='link'>Create your account HERE !</Link></p>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </>

    )
}
