import React, { useEffect, useState } from 'react'
import './ListProperty.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from "yup"
import { useDispatch, useSelector } from 'react-redux';
import { logout, setproperty3 } from '../../redux/action';
import { APIRequest, BEDROOM, BATHROOM, PETPOLICY, OVERLOOKING, PROPERTYTYPE } from '../../api';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';

export default function ListProperty3() {
    const property1 = useSelector(state => state.property1);
    const property3 = useSelector(state => state.property3);
    const property2 = useSelector(state => state.property2);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [bathroom, Setbathroom] = useState();
    const [bedroom, Setbedroom] = useState();
    const [petpolicy, Setpetpolicy] = useState();
    const [overlooking, Setoverlooking] = useState();
    const [propertype, Setpropertype] = useState();
    const [textAreaCount, setTextAreaCount] = useState(0)
    
    useEffect(() => {
        new APIRequest.Builder()
        .post()
        .setReqId(BATHROOM)
        .jsonParams({ "isactive": "Y" })
        .reqURL("master/getbathrooms")
        .response(onResponse)
        .error(onError)
            .build()
            .doRequest();
            new APIRequest.Builder()
            .post()
            .setReqId(BEDROOM)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/getbedrooms")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
            new APIRequest.Builder()
            .post()
            .setReqId(PETPOLICY)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/getpetpolicy")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
            new APIRequest.Builder()
            .post()
            .setReqId(OVERLOOKING)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/getoverlooking")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
            new APIRequest.Builder()
            .post()
            .setReqId(PROPERTYTYPE)
            .jsonParams({ "isactive": "Y" })
            .reqURL("master/getpropertytype")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
        }, []);
        
        
        
        const listproperty = useFormik({
            initialValues: {
                description: property3?.description ?? "",
                property_type_id: property3?.property_type_id ?? "",
                property_type_name: property3?.property_type_name ?? "",
                bedrooms_id: property3?.bedrooms_id ?? "",
                bedrooms_range: property3?.bedrooms_range ?? "",
                bathrooms_id: property3?.bathrooms_id ?? "",
                bathrooms_range: property3?.bathrooms_range ?? "",
                parking_type: property3?.parking_type ?? "",
                pet_policy_id: property3?.pet_policy_id ?? "",
                pet_policy_condition: property3?.pet_policy_condition ?? "",
                overlooking_id: property3?.overlooking_id ?? "",
                overlooking_type: property3?.overlooking_type ?? "",
                expected_monthly_rent: property3?.expected_monthly_rent ?? "",
                total_area_in_sqft: property3?.total_area_in_sqft ?? "",
                security_deposit: property3?.security_deposit ?? ""
            },
            validationSchema: Yup.object().shape({
                description: Yup.string().required("Description is required").min(5, 'Minimum 5 Character Required').max(600, "Maximum 600 Characters Allowed"),
                property_type_name: Yup.string().required("Property Type is required"),
                bedrooms_range: Yup.string().required("No of Bedrooms is required"),
                bathrooms_range: Yup.string().required("No of Bathroom is required"),
                parking_type: Yup.string().required("Parking Type is required"),
                pet_policy_condition: Yup.string().required("Pet Policy is required"),
                // overlooking_type: Yup.string().required("Required"),
                expected_monthly_rent: Yup.string().required("Expected Monthly Rent is required").matches(/^[0-9]+$/, "Must be only digits"),
                total_area_in_sqft: Yup.string().required("Total Area in Sq Ft is required").matches(/^[0-9]+$/, "Must be only digits"),
                security_deposit: Yup.string().required("Security Deposit is required").matches(/^[0-9]+$/, "Must be only digits"),
            }),
            onSubmit: value => {
                dispatch(setproperty3(value))
                navigate("/list-property4")
            }

    });
    
    
    const onResponse = (response, reqId) => {
        switch (reqId) {
            case BATHROOM:
                Setbathroom(response?.data?.data)
                break;
                case BEDROOM:
                    Setbedroom(response?.data?.data)
                    break;
                    case PETPOLICY:
                        Setpetpolicy(response?.data?.data)
                        break;
                        case OVERLOOKING:
                            Setoverlooking(response?.data?.data)
                            break;
                            case PROPERTYTYPE:
                                Setpropertype(response?.data?.data)
                                break;
                                default:
                                    break;
                                }
                            }
                            
                            const onError = (response, reqId) => {
                                if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
                                    navigate('/not')
                                }
                                if (response.data.status == STATE_ERROR) {
                                    localStorage.clear()
                                    dispatch(logout())
                                    navigate("/login");
                                }
                                switch (reqId) {
                                    case BATHROOM:
                console.log(response)
                break;
            case BEDROOM:
                console.log(response)
                break;
                case PETPOLICY:
                    console.log(response)
                    break;
                    case OVERLOOKING:
                        console.log(response)
                        break;
                        case PROPERTYTYPE:
                            console.log(response)
                            break;
                            default:
                                break;
                            }
                        }
                        
                        useEffect(() => {
                            if (property3?.description) {
                                listproperty.setFieldValue("description", property3?.description)
            listproperty.setFieldValue("property_type_name", property3?.property_type_name)
            listproperty.setFieldValue("bedrooms_range", property3?.bedrooms_range)
            listproperty.setFieldValue("bathrooms_range", property3?.bathrooms_range)
            listproperty.setFieldValue("pet_policy_condition", property3?.pet_policy_condition)
            listproperty.setFieldValue("overlooking_type", property3?.overlooking_type)
            listproperty.setFieldValue("expected_monthly_rent", property3?.expected_monthly_rent)
            listproperty.setFieldValue("total_area_in_sqft", property3?.total_area_in_sqft)
            listproperty.setFieldValue("parking_type", property3?.parking_type)
            listproperty.setFieldValue("security_deposit", property3?.security_deposit)
        }
    }, [])

    
    return (
        <>
            <div className="main">
                <div className='listPropertyContainer marginMain'>
                    <div className="container-fluid">
                        <h2 className='page-heading'>{property2?.propertyid ? "Update" : "List"} <span className='font-semibold'>Property</span></h2>

                        {/* progress bar */}
                        {property2?.propertyid ?
                            <div className="row my-5 progressBar">
                                <div className="d-flex">
                                    <div className='me-4'>
                                        <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property") }}>1. Personal Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property2") }}>2. Property Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold  black00 mb-1 cursorPointer' onClick={() => { navigate("/list-property3") }}>3. Property Description</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold  black50 mb-1 cursorPointer' onClick={() => { navigate("/list-property4") }}>4. Amenities and Pictures</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                </div>
                            </div> :
                            <div className="row my-5 progressBar">
                                <div className="d-flex">
                                    <div className='me-4'>
                                        <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property") }}>1. Personal Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    <div className='me-4'>
                                        <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property2") }}>2. Property Information</p>
                                        <div className='progresBar fill-green00'></div>
                                    </div>
                                    {property3 === null ?
                                        <div className='me-4'>
                                            <p className='font-semibold  black00 mb-1'>3. Property Description</p>
                                            <div className='progresBar fill-white25'></div>
                                        </div> :
                                        <div className='me-4'>
                                            <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property3") }}>3. Property Description</p>
                                            <div className='progresBar fill-green00'></div>
                                        </div>
                                    }
                                    {property1 === null ?
                                        <div className='me-4'>
                                            <p className='font-semibold  black50 mb-1'>4. Amenities and Pictures</p>
                                            <div className='progresBar fill-white25'></div>
                                        </div> :
                                        <div className='me-4'>
                                            <p className='font-semibold  green00 mb-1 cursorPointer' onClick={() => { navigate("/list-property4") }}>4. Amenities and Pictures</p>
                                            <div className='progresBar fill-green00'></div>
                                        </div>
                                    }
                                </div>
                            </div>}

                        {property2?.propertyid ? <div className="row mt-2 progressBarTab">
                            <div className="round activate" onClick={() => { navigate("/list-property") }}>1</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property2") }} >2</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property3") }}>3</div>
                            <div className="Line"></div>
                            <div className="round activate" onClick={() => { navigate("/list-property4") }}>4</div>
                        </div> :
                            <div className="row mt-2 progressBarTab">
                                <div className="round activate" onClick={() => { navigate("/list-property1") }}>1</div>
                                <div className="Line"></div>
                                {property2 === null ? <div className="round  ">2</div> : <div className="round activate" onClick={() => { navigate("/list-property2") }}>2</div>}
                                <div className="Line"></div>
                                {property3 === null ? <div className="round  ">3</div> : <div className="round activate" onClick={() => { navigate("/list-property3") }}>3</div>}
                                <div className="Line"></div>
                                {property1 === null ? <div className="round  ">4</div> : <div className="round" onClick={() => { navigate("/list-property4") }}>4</div>}
                            </div>}

                        <div className="listFormContainer w-100 fill-white25 mt-3">
                            <form onSubmit={listproperty.handleSubmit}>
                                <div className="container-fluid pb-5">
                                    {/* form */}
                                    <div className="row">
                                        <div className="col-md-12 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="description">Description*  </label><br />
                                            <textarea className='shadow-none fill-white25 removeRadious form-control border-black25 border-bottom-0'
                                                name='description'
                                                id='description'
                                                rows="3"
                                                maxlength="600"
                                                defaultValue={property3?.description}
                                                onChange={e=>{
                                                listproperty.setFieldValue("description",e.target.value);
                                                setTextAreaCount(e.target.value.length);
                                                const textarea = document.getElementById('description');
                                                textarea.scrollTop = textarea.scrollHeight;
                                                }} 
                                                style={{ overflowY: 'scroll' }} />
                                                <div className={`textEreacount ${textAreaCount>="500"?"error":"green00"}`} >{`${textAreaCount}/600`}</div>
                                                {textAreaCount>="500"?<p className='error'>Maximum 600 Characters Allowed</p>:""}
                                            {listproperty.touched.description && listproperty.errors.description ? (
                                                <span className="error">{listproperty.errors.description}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-4 col-sm-6 col-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="property_type_name">Property Type*  </label><br />
                                            <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                                name='property_type_name'
                                                id='property_type_name'
                                                value={listproperty.values.property_type_name}
                                                onChange={async (e) => {
                                                    const select = e.target;
                                                    const id = select.children[select.selectedIndex].id;
                                                    await listproperty.setFieldValue('property_type_name', e.target.value);
                                                    await listproperty.setFieldValue('property_type_id', id);
                                                }} >
                                                <option value="">-Select-</option>
                                                {propertype?.map((item, id) => <option key={id} id={item?.property_type_id} value={item?.property_type_name} >{item?.property_type_name}</option>)}
                                            </select>
                                            {listproperty.touched.property_type_name && listproperty.errors.property_type_name ? (
                                                <span className="error">{listproperty.errors.property_type_name}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">No of Bedrooms*  </label><br />
                                            <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                                name='bedrooms_range'
                                                id='bedrooms_range'
                                                value={listproperty.values.bedrooms_range}
                                                onChange={async (e) => {
                                                    const select = e.target;
                                                    const id = select.children[select.selectedIndex].id;
                                                    await listproperty.setFieldValue('bedrooms_range', e.target.value);
                                                    await listproperty.setFieldValue('bedrooms_id', id);
                                                }} >
                                                <option value="">-Select-</option>
                                                {bedroom?.map((item, id) => <option key={id} id={item?.bedrooms_id} value={item?.bedrooms_range}>{item?.bedrooms_range}</option>)}
                                            </select>
                                            {listproperty.touched.bedrooms_range && listproperty.errors.bedrooms_range ? (
                                                <span className="error">{listproperty.errors.bedrooms_range}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">No of Bathroom*  </label><br />
                                            <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                                name='bathrooms_range'
                                                id='bathrooms_range'
                                                value={listproperty.values.bathrooms_range}
                                                onChange={async (e) => {
                                                    const select = e.target;
                                                    const id = select.children[select.selectedIndex].id;
                                                    await listproperty.setFieldValue('bathrooms_range', e.target.value);
                                                    await listproperty.setFieldValue('bathrooms_id', id);
                                                }} >
                                                <option id='' value="">-Select-</option>
                                                {bathroom?.map((item, id) => <option key={id} id={item?.bathrooms_id} value={item?.bathrooms_range}>{item?.bathrooms_range}</option>)}
                                            </select>
                                            {listproperty.touched.bathrooms_range && listproperty.errors.bathrooms_range ? (
                                                <span className="error">{listproperty.errors.bathrooms_range}</span>
                                            ) : null}
                                        </div>

                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Parking Type*</label><br />
                                            <input type="text" className=' shadow-none fill-white25 removeRadious    form-control border-black25'
                                                name='parking_type'
                                                id='parking_type'
                                                defaultValue={property3?.parking_type}
                                                onChange={listproperty.handleChange} />
                                            {listproperty.touched.parking_type && listproperty.errors.parking_type ? (
                                                <span className="error">{listproperty.errors.parking_type}</span>
                                            ) : null}
                                        </div>


                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Pet Policy*   </label><br />
                                            <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                                name='pet_policy_condition'
                                                id='pet_policy_condition'
                                                value={listproperty.values.pet_policy_condition}
                                                onChange={async e => {
                                                    const select = e.target;
                                                    const id = select.children[select.selectedIndex].id;
                                                    await listproperty.setFieldValue('pet_policy_condition', e.target.value);
                                                    await listproperty.setFieldValue('pet_policy_id', id);
                                                }}  >
                                                <option id='' value="">-Select-</option>
                                                {petpolicy?.map((item, id) => <option key={id} id={item?.pet_policy_id} value={item?.pet_policy_condition}>{item?.pet_policy_condition}</option>)}

                                            </select>
                                            {listproperty.touched.pet_policy_condition && listproperty.errors.pet_policy_condition ? (
                                                <span className="error">{listproperty.errors.pet_policy_condition}</span>
                                            ) : null}
                                        </div>

                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Overlooking  </label><br />
                                            <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                                name='overlooking_type'
                                                id='overlooking_type'
                                                value={listproperty.values.overlooking_type}
                                                onChange={async (e) => {
                                                    const select = e.target;
                                                    const id = select.children[select.selectedIndex].id;
                                                    await listproperty.setFieldValue('overlooking_type', e.target.value);
                                                    await listproperty.setFieldValue('overlooking_id', id);
                                                }} >
                                                <option id='' value="">-Select-</option>
                                                {overlooking?.map((item, id) => <option key={id} id={item?.overlooking_id} value={item?.overlooking_type}>{item?.overlooking_type}</option>)}

                                            </select>
                                            {listproperty.touched.overlooking_type && listproperty.errors.overlooking_type ? (
                                                <span className="error">{listproperty.errors.overlooking_type}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Expected Monthly Rent* </label><br />
                                            <div className="input-group ">
                                                <span className="dollerInput">$</span>
                                                <input type="text" className="shadow-none fill-white25 removeRadious form-control border-black25" aria-label="Amount (to the nearest dollar)"  
                                                name='expected_monthly_rent'
                                                id='expected_monthly_rent'
                                                defaultValue={property3?.expected_monthly_rent}
                                                onChange={listproperty.handleChange} />
                                            </div>
                                            {listproperty.touched.expected_monthly_rent && listproperty.errors.expected_monthly_rent ? (
                                                <span className="error">{listproperty.errors.expected_monthly_rent}</span>
                                            ) : null}
                                            {/* <input type="text" className='shadow-none  fill-white25 removeRadious    form-control border-black25'
                                                name='expected_monthly_rent'
                                                id='expected_monthly_rent'
                                                defaultValue={property3?.expected_monthly_rent}
                                                onChange={listproperty.handleChange} />
                                            {listproperty.touched.expected_monthly_rent && listproperty.errors.expected_monthly_rent ? (
                                                <span className="error">{listproperty.errors.expected_monthly_rent}</span>
                                            ) : null} */}
                                        </div>
                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Security Deposit*  </label><br />
                                            <div className="input-group ">
                                                <span className="dollerInput">$</span>
                                                <input type="text" className="shadow-none fill-white25 removeRadious form-control border-black25" aria-label="Amount (to the nearest dollar)"   
                                                name='security_deposit'
                                                id='security_deposit'
                                                defaultValue={property3?.security_deposit}
                                                onChange={listproperty.handleChange} />
                                                </div>
                                                {listproperty.touched.security_deposit && listproperty.errors.security_deposit ? (
                                                <span className="error">{listproperty.errors.security_deposit}</span>
                                            ) : null}   
                                            {/* <input type="text" className=' shadow-none fill-white25 removeRadious    form-control border-black25'
                                                name='security_deposit'
                                                id='security_deposit'
                                                defaultValue={property3?.security_deposit}
                                                onChange={listproperty.handleChange} />
                                            {listproperty.touched.security_deposit && listproperty.errors.security_deposit ? (
                                                <span className="error">{listproperty.errors.security_deposit}</span>
                                            ) : null} */}
                                        </div>
                                        <div className="col-md-4 col-sm-12 mt-3">
                                            <label className='green00 font-semibold mb-1' htmlFor="">Total Area in Sq Ft*  </label><br />
                                            <input type="text" className=' shadow-none fill-white25 removeRadious    form-control border-black25'
                                                name='total_area_in_sqft'
                                                id='total_area_in_sqft'
                                                defaultValue={property3?.total_area_in_sqft}
                                                onChange={listproperty.handleChange} />
                                            {listproperty.touched.total_area_in_sqft && listproperty.errors.total_area_in_sqft ? (
                                                <span className="error">{listproperty.errors.total_area_in_sqft}</span>
                                            ) : null}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <button type='submit' className='submitbutton border-none fill-green00 white00 px-3 py-2 text-center removeLinkDefaults'> Next </button>
                                    </div>

                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
