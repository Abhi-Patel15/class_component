import { React, useDebugValue, useEffect, useState, useCallback } from 'react'
import ProductCard from '../../Components/ProductCard/ProductCard';
import './Favourites.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import { APIRequest, GET_PROPERTYFAVOURITE } from '../../api';
import { useDispatch, useSelector } from 'react-redux';
import { setcompareproperty } from '../../redux/action';
import toast from 'react-simple-toasts';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';

export default function Favourites() {

  const user = useSelector(state => state.user)
  const listcompare = useSelector(state => state.compareproperty)
  const [properylist, Setpropertylist] = useState([]);
  const [listdata, SetListdata] = useState();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [comparelist, SetComparelist] = useState(listcompare);
  const [unfavourite, Setunfavourite] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [dataReload, setDataReload] = useState(false)

  useEffect(() => { 
   fatchProperty(); 
  }, [deleteConfirm,unfavourite]);

const fatchProperty = ()=>{
  new APIRequest.Builder()
  .post()
  .setReqId(GET_PROPERTYFAVOURITE)
  .jsonParams({
    "userid": user?.userid,
    "isactive": "Y"
  })
  .reqURL("property/get_propertyfavourite")
  .response(onResponse)
  .error(onError)
  .build()  
  .doRequest();
}
// setTimeout(()=>{
//   setDatareload(true)
// },1500)


  const onResponse = (response, reqId) => {
    switch (reqId) {
      case GET_PROPERTYFAVOURITE:
        if (response?.data?.issuccess) {
          Setpropertylist(response?.data?.data)
          SetListdata(response?.data?.data)
          setDataReload(true)
        }
        else {
          toast(`${response?.data?.massage}`)
        }
        break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case GET_PROPERTYFAVOURITE:
        console.log(response)
        break;
      default:
        break;
    }
  }
  
  const CompareFunction = () => {
    if (comparelist.length >= 5) {
      setDeleteConfirm(true)                                                 
    } else {
      dispatch(setcompareproperty(comparelist))
      navigate("/comparision")
    }
  }

  useEffect(()=>{
    Setunfavourite()
  },[unfavourite])
  
  return (
    <>
      <div className='main'>
        <div className="favouritesContainer">
          <div className="container">
            <div className="row  ">
              <div className="d-flex">
                <h2 className="page-heading">Favorites</h2>
                {comparelist?.length >= 1 ? <button className='compareBTN fill-green00 white00 px-3 py-1' onClick={CompareFunction}>Compare</button> : <p></p>}
              </div>
            </div> <div className="row">
            {/* {properylist.length === 0 && <p className='font-20 font-bold green00 text-center mt-5'>No Favorites Found</p>} */}
              {dataReload && properylist?.map((item, id) =>
                <div className=" col-xxl-3 col-md-4 col-sm-6 col-12">
                  <div className="card-shadow" key={id}>
                    <ProductCard listdata={listdata[id]} edit="block"
                      path={`${item.cover_image_url}`}
                      heart="none" cross="none" unfavourite="block"
                      deletefavourite={Setunfavourite} fatchProperty={fatchProperty} daysLeft="none" onlyPrice="block" />
                    <div className="selectionDiv black10">
                    <label className="font-14">
                      <input  type="checkbox" className='me-2' value={item?.propertyid} defaultChecked={listcompare?.find(value => value === `${item?.propertyid}`) ? true : false}
                        onChange={(e) => {
                          if (e.target.checked) {   
                            if (comparelist.length >= 4 ) {
                              setDeleteConfirm(true)
                            }                       
                              const compareData =[...comparelist,e.target.value ]               
                               SetComparelist(compareData) 
                               dispatch(setcompareproperty(compareData)) 
                          }
                          else {
                            const data =comparelist.filter((item) => item !== e.target.value)
                            dispatch(setcompareproperty(data))
                            SetComparelist(data);
                          }
                        }} />Select for comparision</label>
                    </div>
                  </div>
                </div>)}
               {dataReload && properylist.length === 0  && <p className='font-20 font-bold green00 text-center mt-5'>No Favorites Found</p>}
            </div>
          </div>
        </div>
      </div>
      <Modal centered show={deleteConfirm} onHide={()=>{setDeleteConfirm(false);}}>
        <Modal.Header >
          <Modal.Title> <h5 className='green00'>Favorites Property</h5></Modal.Title>
        </Modal.Header>
        <Modal.Body>Please select a maximum of 4 properties to compare</Modal.Body>
        <Modal.Footer>
          <button className='border-none px-3 py-2 font-14' onClick={() => { setDeleteConfirm(false);}}>Ok</button>
        </Modal.Footer>
      </Modal>

    </>
  )
}
