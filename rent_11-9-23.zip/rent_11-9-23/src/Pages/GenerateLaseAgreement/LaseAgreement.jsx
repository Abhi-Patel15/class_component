import { useState, useEffect, useRef } from 'react';
import * as React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import './style.css';

const LeaseSchema = Yup.object().shape({
  landlordName: Yup.string().required('Required'),
  landlordAddress: Yup.string().required('Required'),
  tenantName: Yup.string().required('Required'),
  tenantAddress: Yup.string().required('Required'),
  leaseStartDate: Yup.date().required('Required'),
  leaseEndDate: Yup.date().required('Required'),
  rentAmount: Yup.number().required('Required'),
  securityDeposit: Yup.number().required('Required'),
  utilitiesIncluded: Yup.boolean(),
  includedUtilities: Yup.string(),
  inspectionFrequency: Yup.string().required('Required'),
  noticePeriod: Yup.number().required('Required'),
  petPolicy: Yup.string().required('Required'),
  smokingPolicy: Yup.string().required('Required'),
  parkingPolicy: Yup.string().required('Required'),
  landscapingResponsibility: Yup.string().required('Required'),
  guestPolicy: Yup.string().required('Required'),
  wasteDisposalPolicy: Yup.string().required('Required'),
});

export default function LaseAgreement() {
  const [htmlPreview, setHtmlPreview] = useState('');

  const petPolicyOptions = [
    'No pets allowed',
    'Only small pets allowed',
    'Pets allowed with approval',
    'Dogs allowed',
    'Cats allowed',
  ];
  const smokingPolicyOptions = [
    'No smoking allowed',
    'Smoking allowed outside only',
    'Smoking allowed with restrictions',
  ];
  const parkingPolicyOptions = [
    'No parking allowed',
    'Parking allowed with permit',
    'Parking allowed in designated areas',
    'Street Parking',
    'Garage Parking',
  ];
  const landscapingResponsibilityOptions = [
    'Tenant responsible for lawn maintenance and/or snow removal',
    'Landlord responsible for lawn maintenance and/or snow removal',
    'Shared responsibility for lawn maintenance and/or snow removal',
  ];
  const guestPolicyOptions = [
    'No guests allowed',
    'Guests allowed with approval',
    'Guests allowed with restrictions',
  ];
  const wasteDisposalPolicyOptions = [
    'Tenant responsible for waste disposal',
    'Landlord responsible for waste disposal',
    'Shared responsibility for waste disposal',
  ];
  const previewRef = useRef(null);
  useEffect(() => {
    if (htmlPreview && previewRef.current) {
      window.scrollTo({
        top: previewRef.current.offsetTop - 20,
        behavior: 'smooth',
      });
    }
  }, [htmlPreview]);

  return (
    <div className="lase mt-5">
      <div className="containers mt-5">
        <div className="intro">
          <h1 className="title">Welcome to Urbanesting Lease Generator!</h1>
          <p>
            As a courtesy to our valued customers, we offer this lease agreement
            generator to help you get started with creating your own lease
            agreements. Please note that this tool provides a template that you
            can use as a starting point, but you should consult with a qualified
            attorney to ensure that your lease agreement is legally compliant
            and meets your specific needs.
          </p>
          <p>
            <strong>Disclaimer:</strong> Urbanesting is not a law firm, and we
            do not offer legal advice. This lease generator is intended for
            informational purposes only and should not be considered a
            substitute for legal advice. By using this tool, you agree that
            Urbanesting is not responsible for any errors or omissions, or for
            any actions taken based on the information provided here.
          </p>
        </div>
        <h1 className="title">Generate Lease Agreement</h1>
        <p>Please fill in the required fields to generate a lease agreement.</p>
        <Formik
          initialValues={{
            landlordName: '',
            landlordAddress: '',
            tenantName: '',
            tenantAddress: '',
            leaseStartDate: '',
            leaseEndDate: '',
            rentAmount: '',
            securityDeposit: '',
            utilitiesIncluded: false,
            includedUtilities: '',
            inspectionFrequency: '',
            noticePeriod: '',
            petPolicy: 'No pets allowed',
            smokingPolicy: 'No smoking allowed',
            parkingPolicy: 'No parking allowed',
            landscapingResponsibility:
              'Tenant responsible for lawn maintenance',
            guestPolicy: 'No guests allowed',
            wasteDisposalPolicy: 'Tenant responsible for waste disposal',
          }}
          validationSchema={LeaseSchema}
          onSubmit={(values) => {
            let preview = `
                          <h2>Lease Agreement</h2>
            <p>This Lease Agreement is made on ${
              values.leaseStartDate
            } between ${
              values.landlordName
            } (hereinafter referred to as the 'Landlord'), with address at ${
              values.landlordAddress
            }, and ${
              values.tenantName
            } (hereinafter referred to as the 'Tenant'), with address at ${
              values.tenantAddress
            }.</p>
            
            <p>1. Term: The term of this lease shall begin on ${
              values.leaseStartDate
            } and end on ${
              values.leaseEndDate
            }. The Tenant agrees to vacate the premises upon lease expiration. Tenant shall be granted the option to renew the lease with agreed-upon terms.</p>
            
            <p>2. Rent: Tenant agrees to pay Landlord the sum of $${
              values.rentAmount
            } as rent for the premises, payable in monthly installments of $${
              values.rentAmount
            } each. Rent shall be paid by the 1st of each month through an agreed payment method.</p>
            
            <p>3. Security Deposit: Tenant shall pay a security deposit of $${
              values.securityDeposit
            } to Landlord before taking possession of the premises. The security deposit will be held for potential damages and will be returned within [number] days after lease termination, minus any deductions for repairs. Tenant shall not use the security deposit as rent payment.</p>
            
            <p>4. Utilities: ${
              values.utilitiesIncluded ? 'Utilities are' : 'Utilities are not'
            } included in the rent. ${
              values.utilitiesIncluded
                ? `Included Utilities: ${
                    values.includedUtilities || 'None specified.'
                  }`
                : ''
            }</p>
            
            <p>5. Maintenance and Repairs: The Landlord shall be responsible for maintaining the structure of the property and performing necessary repairs. Tenant is responsible for minor maintenance and promptly reporting any damages or repairs needed. Landlord shall provide ${
              values.inspectionFrequency
            } inspections to identify maintenance needs. Tenant shall promptly notify Landlord of any required repairs.</p>
            
            <p>6. Use of Premises: The Tenant agrees to use the premises solely for residential purposes and shall not engage in any unlawful activities. Any changes to the purpose of use require Landlord's written consent. Tenant shall not alter or damage any structural components. Tenant shall keep the premises clean and sanitary.</p>
            
            <p>7. Pet Policy: ${values.petPolicy}</p>

            
            <p>8. Alterations: Tenant shall not make any alterations, additions, or improvements to the premises without Landlord's written consent. Any approved alterations become the property of the Landlord. Tenant may decorate and modify the premises with temporary changes, subject to prior approval.</p>
            
            <p>9. Subletting: Tenant shall not sublet the premises or any part thereof without Landlord's prior written approval. Subletting without consent may result in immediate termination of the lease. Tenant remains responsible for subtenant actions and lease compliance.</p>
            
            <p>10. Inspections: Landlord has the right to enter the premises for inspection or repairs with reasonable notice to Tenant. Regular inspections will be conducted ${
              values.inspectionFrequency
            } to ensure the property's condition. Tenant shall provide access for inspections and make reasonable accommodations for maintenance visits.</p>
            
            <p>11. Termination: Either party may terminate this lease with proper notice as required by law. Tenant must provide ${
              values.noticePeriod
            } days written notice, and Landlord must provide ${
              values.noticePeriod
            } days written notice for termination. Early termination may result in penalties as specified in the lease.</p>
            
            <p>12. Governing Law: This agreement shall be governed by the laws of the state of [State Name]. Any disputes arising from this lease shall be resolved in [venue for disputes]. Both parties agree to mediation before pursuing legal action. Tenant acknowledges that legal fees may be incurred.</p>
            
            <p>13. Maintenance Responsibilities: Landlord is responsible for major repairs and structural maintenance. Tenant shall promptly report any issues to Landlord. Tenant shall maintain cleanliness, and promptly address plumbing and electrical issues. Tenant shall keep outdoor areas free from debris.</p>
            
            <p>14. Noise and Nuisance: Tenant shall not engage in any activities that disturb neighbors or cause a nuisance. Tenant shall abide by noise ordinances and refrain from disruptive behavior. Parties and loud gatherings are not permitted without Landlord's written consent.</p>
            
            <p>15. Smoking: ${values.smokingPolicy}</p>

            
            <p>16. Hazardous Materials: Tenant shall not store hazardous materials or engage in activities that pose environmental risks within the premises. Tenant shall follow local regulations for waste disposal and recycling.</p>
            
            <p>17. Parking: ${values.parkingPolicy}</p>

            
            <p>18. Notice and Communication: All notices and communications between Landlord and Tenant shall be in writing and delivered through [specified method]. Landlord's contact information for notices is [contact details]. Tenant shall provide updated contact information to Landlord.</p>
            
            <p>19. Entry and Access: Landlord shall provide advance notice of entry for non-emergency reasons. Entry may be necessary for repairs, inspections, or showing the property to prospective tenants. Landlord shall respect Tenant's privacy and rights. Tenant shall grant access within reasonable hours.</p>
            
            <p>20. Insurance: Landlord is not responsible for Tenant's personal property. Tenant is encouraged to obtain renter's insurance to cover personal belongings and liability. Landlord shall maintain property insurance for structural coverage.</p>
            
            <p>21. Default and Remedies: Tenant's failure to comply with lease terms may result in default. Landlord shall provide written notice of any violations and a reasonable opportunity to cure. Landlord may seek remedies as allowed by law in case of default.</p>
            
            <p>22. Lead Disclosure: Landlord discloses any knowledge of lead-based paint in the property. Tenant acknowledges receipt of the lead-based paint pamphlet and agrees to take precautions if applicable.</p>
            
            <p>23. Security and Locks: Tenant shall not change locks without Landlord's written consent. Tenant shall ensure security of the premises, including locking doors and windows when absent. Lost keys shall be reported to Landlord.</p>
            
            <p>24. Emergencies: Tenant shall report emergencies to Landlord immediately. Tenant shall follow emergency protocols and instructions provided by Landlord. Landlord shall maintain emergency contacts for repairs.</p>
            
            <p>25. Waiver of Liability: Tenant waives any claims against Landlord for personal injury or property damage, except in cases of Landlord's negligence. Tenant is advised to take precautions for safety.</p>
            
            <p>26. Pest Control: Tenant shall promptly report any pest infestations to Landlord. Landlord shall arrange for pest control services if necessary. Tenant shall follow Landlord's instructions for pest prevention and control.</p>
            
            <p>27. Guest Policy: ${values.guestPolicy}</p>
            
            <p>28. Water and Sewer: Tenant shall use water and sewer facilities responsibly. Tenant shall report any leaks or plumbing issues promptly. Tenant shall not flush items that may clog plumbing.</p>
            
            <p>29. Waste Disposal: ${values.wasteDisposalPolicy}</p>

            
            <p>30. Appliances and Fixtures: Tenant shall use appliances and fixtures responsibly. Tenant shall promptly report malfunctions to Landlord. Tenant shall not disassemble or repair appliances without Landlord's consent.</p>
            
            <p>31. Renewable Energy: Tenant may install renewable energy systems (solar panels, wind turbines) with Landlord's consent. Any modifications shall comply with local regulations and shall not damage the property.</p>
            
            <p>32. Lockouts: Tenant locked out of the premises shall contact Landlord for assistance. Tenant shall be responsible for lockout-related expenses. Landlord shall provide emergency contact information for lockouts.</p>
            
            <p>33. Landscaping: ${values.landscapingResponsibility}</p>

            
            <p>34. Renewable Lease Terms: Both parties may negotiate renewable lease terms before the lease expiration. Any changes or modifications to lease terms shall be in writing and agreed upon by both parties.</p>
            
            <p>35. Dispute Resolution: In case of disputes, both parties shall attempt to resolve issues through mediation. If mediation is unsuccessful, either party may seek legal remedies. The prevailing party shall be entitled to recover legal fees.</p>
            
            <p>36. Severability: If any provision of this lease is found to be unenforceable, the remaining provisions shall remain in full force and effect. The unenforceable provision shall be modified or replaced with a valid provision that most closely reflects the original intent.</p>
            
            <p>37. Attorney's Fees: In the event of a legal dispute, the prevailing party shall be entitled to recover reasonable attorney's fees and court costs from the non-prevailing party.</p>
            
            <p>38. Quiet Enjoyment: Landlord warrants that Tenant shall have quiet enjoyment of the premises without interference. Tenant shall not disturb other tenants or neighbors and shall comply with property rules and regulations.</p>
            
            <p>39. Rental History: Tenant authorizes Landlord to verify rental history and credit information provided in the application. False information may result in lease termination.</p>
            
            <p>40. Holdover: If Tenant remains in possession of the premises after lease expiration without renewal or agreement, Tenant shall be responsible for double the monthly rent until vacating the property.</p>
            
            <!-- Add more lease terms and conditions here -->
            `;

            setHtmlPreview(preview);
          }}
        >
          {({ values, errors, touched }) => (
            <Form className="form">
              <div className="form-section">
                <h2 className="form-section-header">Landlord Information</h2>
                <div className="field mobileVeiw">
                    <div className='labelwidth text-break '>

                  <label htmlFor="landlordName ">Name of the Landlord:</label>
                    </div>
                  <Field
                    id="landlordName"
                    name="landlordName"
                    placeholder="e.g. John Doe"
                    className={
                      errors.landlordName && touched.landlordName
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="landlordName"
                    component="div"
                    className="errorslase"
                  />
                </div>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="landlordAddress">
                    Address of the Landlord:
                  </label>
                  </div>
                  <Field
                    id="landlordAddress"
                    name="landlordAddress"
                    placeholder="e.g. 123 Main St, New York, NY 10001"
                    className={
                      errors.landlordAddress && touched.landlordAddress
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="landlordAddress"
                    component="div"
                    className="errorslase"
                  />
                </div>
              </div>

              {/* Tenant Information Section */}
              <div className="form-section">
                <h2 className="form-section-header">Tenant Information</h2>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="tenantName">Tenant Name:</label>
                  </div>
                  <Field
                    id="tenantName"
                    name="tenantName"
                    placeholder="e.g. Jane Smith"
                    className={
                      errors.tenantName && touched.tenantName
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="tenantName"
                    component="div"
                    className="errorslase"
                  />
                </div>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="tenantAddress">Tenant Address:</label>
                  </div>
                  <Field
                    id="tenantAddress"
                    name="tenantAddress"
                    placeholder="e.g. 456 Elm St, New York, NY 10001"
                    className={
                      errors.tenantAddress && touched.tenantAddress
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="tenantAddress"
                    component="div"
                    className="errorslase"
                  />
                </div>
              </div>

              {/* Lease Terms Section */}
              <div className="form-section">
                <h2 className="form-section-header ">Lease Terms</h2>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="leaseStartDate">Lease Start Date:</label>
                  </div>
                  <Field
                    id="leaseStartDate"
                    type="date"
                    name="leaseStartDate"
                    className={
                      errors.leaseStartDate && touched.leaseStartDate
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="leaseStartDate"
                    component="div"
                    className="errorslase"
                  />
                </div>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="leaseEndDate">Lease End Date:</label>
                  </div>
                  <Field
                    id="leaseEndDate"
                    type="date"
                    name="leaseEndDate"
                    className={
                      errors.leaseEndDate && touched.leaseEndDate
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="leaseEndDate"
                    component="div"
                    className="errorslase"
                  />
                </div>
              </div>

              {/* Rent and Deposit Section */}
              <div className="form-section">
                <h2 className="form-section-header">Rent and Deposit</h2>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="rentAmount">Rent Amount:</label>
                  </div>
                  <Field
                    id="rentAmount"
                    type="number"
                    name="rentAmount"
                    placeholder="e.g. 1000"
                    className={
                      errors.rentAmount && touched.rentAmount
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="rentAmount"
                    component="div"
                    className="errorslase"
                  />
                </div>
                <div className="field mobileVeiw">
                <div className='labelwidth text-break'>
                  <label htmlFor="securityDeposit">Security Deposit:</label>
                  </div>
                  <Field
                    id="securityDeposit"
                    type="number"
                    name="securityDeposit"
                    placeholder="e.g. 1000"
                    className={
                      errors.securityDeposit && touched.securityDeposit
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="securityDeposit"
                    component="div"
                    className="errorslase"
                  />
                </div>
              </div>

              {/* Utilities Section */}
              <div className="form-section">
              <h2 className="form-section-header">Utilities</h2>
                <div className="field">
                  <label htmlFor="utilitiesIncluded">Utilities Included:</label>
                  <Field type="checkbox" name="utilitiesIncluded" />
                </div>
                {values.utilitiesIncluded && (
                  <div className="field">
                    <label htmlFor="includedUtilities">
                      Included Utilities:
                    </label>
                    <Field
                      id="includedUtilities"
                      type="text"
                      name="includedUtilities"
                      placeholder="e.g. Water, Electricity"
                      className={
                        errors.includedUtilities && touched.includedUtilities
                          ? 'error-input'
                          : ''
                      }
                    />
                    <ErrorMessage
                      name="includedUtilities"
                      component="div"
                      className="errorslase"
                    />
                  </div>
                )}
              </div>

              <div className="form-section">
                <h2 className="form-section-header">Additional Lease Terms</h2>
                <div className="field mobileVeiw">
                <div  className='labelwidth text-break'>
                  <label htmlFor="inspectionFrequency">
                    Inspection Frequency:
                  </label>
                  </div>
                  <Field
                    id="inspectionFrequency"
                    type="text"
                    name="inspectionFrequency"
                    placeholder="e.g. Monthly, Quarterly"
                    className={
                      errors.inspectionFrequency && touched.inspectionFrequency
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="inspectionFrequency"
                    component="div"
                    className="errorslase"
                  />
                </div>
                <div className="field mobileVeiw"> 
                <div  className='labelwidth text-break'>
                  <label htmlFor="noticePeriod">Notice Period (days):</label>
                  </div>
                  <Field
                    id="noticePeriod"
                    type="number"
                    name="noticePeriod"
                    placeholder="e.g. 30"
                    className={
                      errors.noticePeriod && touched.noticePeriod
                        ? 'error-input'
                        : ''
                    }
                  />
                  <ErrorMessage
                    name="noticePeriod"
                    component="div"
                    className="errorslase"
                  />
                </div>
                {[
                  {
                    id: 'petPolicy',
                    label: 'Pet Policy:',
                    options: petPolicyOptions,
                  },
                  {
                    id: 'smokingPolicy',
                    label: 'Smoking Policy:',
                    options: smokingPolicyOptions,
                  },
                  {
                    id: 'parkingPolicy',
                    label: 'Parking Policy:',
                    options: parkingPolicyOptions,
                  },
                  {
                    id: 'landscapingResponsibility',
                    label: 'Landscaping Responsibility:',
                    options: landscapingResponsibilityOptions,
                  },
                  {
                    id: 'guestPolicy',
                    label: 'Guest Policy:',
                    options: guestPolicyOptions,
                  },
                  {
                    id: 'wasteDisposalPolicy',
                    label: 'Waste Disposal Policy:',
                    options: wasteDisposalPolicyOptions,
                  },
                ].map(({ id, label, options }) => (
                  <div className="field mobileVeiw" key={id}>
                    <div  className='labelwidth text-break'>
                    <label htmlFor={id}>{label}</label>
                    </div>
                    <Field
                      as="select"
                      name={id}
                      className={errors[id] && touched[id] ? 'error-input' : ''}
                    >
                      {options.map((option, index) => (
                        <option key={index} value={option} style={{outline:"0px"}} className='w-75'>
                          {option}
                        </option>
                      ))}
                    </Field>
                    <ErrorMessage name={id} component="div" className="errorslase" />
                  </div>
                ))}
              </div>

              <button type="submit" className="submit-btn">
                Generate Preview
              </button>
            </Form>
          )}
        </Formik>
        {htmlPreview ? (
          <div className="pdf-preview" id="pdf-preview" ref={previewRef}>
            <h2>Lease Agreement Preview</h2>
            <div
              className="pdf-content"
              dangerouslySetInnerHTML={{ __html: htmlPreview }}
            />
            <p className="note">
              Please copy and paste the generated lease into your preferred word
              processing software for further modification. The option to
              download the lease agreement as a PDF is coming soon.
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}

