import React from 'react'
import '../NotFound/NotFound.css'
import '../../Common/common.css' 
import { Link, useNavigate } from 'react-router-dom'

export const Maintenance = () => {
  return (
    <>
    <div className='container-fluid '>
        <div className="notFoundContainer">
            <div className="subNotfound">
                <h1 className='header'>Oops !</h1>
                <h3 className=' font-semibold'> 500, Sorry Our website is under maintenance </h3>
                <Link to="/" className='removeLinkDefaults px-5 py-2 border-none fill-green00 white00 '>Home</Link>
            </div>
        </div>
    </div>
    </>
  )
}
