import React, { useState } from 'react';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import './style.css';

var formConfig = [
  {
    header: 'Utilities',
    items: [
      'Electricity connected',
      'Water connected',
      'Gas connected',
      'Internet set up',
      'Phone line connected',
      'Cable TV set up',
      'Sewer service connected',
      'Trash service set up',
      'Heating and cooling systems checked',
    ],
    name: 'utilities',
  },
  {
    header: 'Cleaning',
    items: [
      'Floors cleaned',
      'Windows cleaned',
      'Bathroom cleaned',
      'Kitchen cleaned',
      'Cabinets wiped',
      'Dusting completed',
      'Appliances cleaned',
      'Carpets vacuumed or cleaned',
      'Baseboards cleaned',
      'Blinds or curtains cleaned',
      'Ceiling fans cleaned',
      'Light fixtures cleaned',
    ],
    name: 'cleaning',
  },
  {
    header: 'Safety',
    items: [
      'Smoke detectors checked',
      'Carbon monoxide detectors checked',
      'Fire extinguisher checked',
      'Emergency exits identified',
      'First-aid kit available',
      'Electrical outlets checked',
      'GFCI outlets tested',
      'Safety rails installed where needed',
      'Chimney or fireplace inspected',
    ],
    name: 'safety',
  },
  {
    header: 'Security',
    items: [
      'Locks changed or rekeyed',
      'Security system set up',
      'Security lights installed',
      'Window locks checked',
      'Spare keys created',
      'Peepholes installed on exterior doors',
      'Motion detectors installed',
      'Security cameras installed',
      'Window security film applied',
    ],
    name: 'security',
  },
  {
    header: 'Other',
    items: [
      'Mail forwarding set up',
      'Trash collection schedule confirmed',
      'Recycling set up',
      'New address updated',
      'Home insurance purchased',
      'Pest control service scheduled',
      'Lawn care or landscaping planned',
      'School registration completed',
      'Vehicle registration updated',
      "Driver's license address updated",
    ],
    name: 'other',
  },
];

var MoveInSchema = Yup.object().shape({
  utilities: Yup.array().of(Yup.string()),
  cleaning: Yup.array().of(Yup.string()),
  safety: Yup.array().of(Yup.string()),
  security: Yup.array().of(Yup.string()),
  other: Yup.array().of(Yup.string()),
});

var FormSection = ({ name, header, items, printing }) => (
  <div className={`form-section ${printing ? '' : 'hidden'}`}>
    <h2 className="form-section-header">{header}</h2>
    {items.map((item, index) => (
      <div className="field" key={index}>
        <label>
          <Field type="checkbox" className="me-2" name={name} value={item} />
          {item}
        </label>
      </div>
    ))}
  </div>
);

export default function MoveInChecklist() {
  const [progress, setProgress] = useState(0);
  const [activeCategory, setActiveCategory] = useState('utilities');
  const [printing, setPrinting] = useState(false);

  const calculateProgress = (values) => {
    const totalItems = formConfig.reduce(
      (acc, section) => acc + section.items.length,
      0
    );
    const checkedItems = Object.values(values).reduce(
      (acc, items) => acc + items.length,
      0
    );
    setProgress((checkedItems / totalItems) * 100);
  };

  const printChecklist = () => {
    setPrinting(true);
    setTimeout(() => {
      window.print();
      setPrinting(false);
    }, 500);
  };

  return (
    <div className="moveIncheck ">
      <div className="containers mt-5">
        <h1 className="title mt-5">Urbanesting Move-in Checklist</h1>
        <p>
          Welcome to Urbanesting! Please use this checklist to make sure your
          move-in process goes smoothly.
        </p>
        <div className="nav-bar">
          {formConfig.map(({ name, header }) => (
            <button
              key={name}
              className={`nav-button ${
                activeCategory === name ? 'active' : ''
              }`}
              onClick={() => setActiveCategory(name)}
            >
              {header}
            </button>
          ))}
        </div>
        <div className="progress-bar">
          <div className="progress" style={{ width: `${progress}%` }} />
        </div>
        <Formik
          initialValues={{
            utilities: [],
            cleaning: [],
            safety: [],
            security: [],
            other: [],
          }}
          validationSchema={MoveInSchema}
        >
          {({ values }) => {
            calculateProgress(values);
            return (
              <Form className="form">
                {formConfig.map((section) => (
                  <FormSection
                    key={section.name}
                    name={section.name}
                    header={section.header}
                    items={section.items}
                    printing={printing || activeCategory === section.name}
                  />
                ))}
                <button
                  type="button"
                  className="print-btn"
                  onClick={printChecklist}
                >
                  Print Checklist
                </button>
              </Form>
            );
          }}
        </Formik>
      </div>
    </div>
  );
}

