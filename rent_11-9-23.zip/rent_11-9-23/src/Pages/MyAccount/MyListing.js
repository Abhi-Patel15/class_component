import React, { useEffect, useState } from 'react'
import ProductCard from '../../Components/ProductCard/ProductCard';
import './MyAccount.css'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { MdModeEdit } from 'react-icons/md';
import { APIRequest, GET_PROPERTYPEDETAILS, PAYMENTFOR_PROPERTY, PROPERTY_OCCUPIED_USER, PAYMENT_AUTH_CLIENT } from '../../api';
import { useDispatch, useSelector } from 'react-redux';
import { logout, setproperty1, setproperty2, setproperty3 } from '../../redux/action';
import toast from 'react-simple-toasts';
import { Payment } from './payment';
import Loading from '../../Components/Loading/Loading';
import Modal from 'react-bootstrap/Modal';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';

export default function MyListing() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { propertyid } = useParams();
    const [searchParams] = useSearchParams();
    const user = useSelector(state => state.user)
    const [properylist, Setpropertylist] = useState([]);
    const [listdata, SetListdata] = useState();
    const [paymentdata, SetPaymentdata] = useState([]);
    const [paymentmodal, Setpaymentmodal] = useState(false);
    const [loading, Setloading] = useState(true)
    const [paymentconfirm, Setpaymentconfirm] = useState(false);
    const [renew, Setrenew] = useState(false);
    const [dataReload, setDataReload] = useState(false)
    

    useEffect(() => {
        if (propertyid && searchParams.get('payment_intent')) {
            new APIRequest.Builder()
                .post()
                .setReqId(PAYMENT_AUTH_CLIENT)
                .jsonParams({
                    "userid": user?.userid,
                    "propertyid": propertyid,
                    "payment_id": searchParams.get('payment_intent')
                })
                .reqURL("property/payment_auth_by_client")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();

        }
    }, [])

    const fatchProperty = () => {
        new APIRequest.Builder()
            .post()
            .setReqId(GET_PROPERTYPEDETAILS)
            .jsonParams({
                "userid": user?.userid,
                "isactive": "Y"
            })
            .reqURL("property/get_propertydetail")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
    }
    useEffect(() => {
        fatchProperty();
    }, [paymentconfirm, paymentmodal])

    const occupiedHandler = (item, id) => {
        if (id === "occupied") {
            new APIRequest.Builder()
                .post()
                .setReqId(PROPERTY_OCCUPIED_USER)
                .jsonParams({
                    "userid": user?.userid,
                    "isoccupied": "Y",
                    "propertyid": item?.propertyid
                })
                .reqURL("property/property_occupied_by_user")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
        else if (id === "Renew") {
            Setpaymentmodal(true); SetPaymentdata(item);Setrenew(true);
        }
    }

    const onResponse = (response, reqId) => {
        switch (reqId) {
            case GET_PROPERTYPEDETAILS:
                Setpropertylist(response?.data?.data)
                SetListdata(response?.data?.data)
                Setloading(false)
                break;

            case PAYMENTFOR_PROPERTY:
                toast(`${response?.data?.massage}`)
                break;
            case PROPERTY_OCCUPIED_USER:                
                toast(`${response?.data?.massage}`)
                fatchProperty();
                break;
            case PAYMENT_AUTH_CLIENT:               
                if (response.data.issuccess) {
                    Setpaymentconfirm(true)
                } else {
                    toast("Error in Payment")
                    navigate('/my-account/my-listing')
                }
                break;
            default:
                break;
        }
    }
    
    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        switch (reqId) {
            case GET_PROPERTYPEDETAILS:                
                Setloading(false)
                break;
            case PAYMENTFOR_PROPERTY:
                toast(`${response?.data?.massage}`)
                break;
            case PROPERTY_OCCUPIED_USER:
                toast(`${response?.data?.massage}`)
                break;
            case PAYMENT_AUTH_CLIENT:
                toast("Error in Payment")
                break;
            default:
                break;
        }
    }

    const editProperty = (data) => {
        dispatch(setproperty2({
            days_remaining:data.days_remaining,
            isapproved:data.isapproved,
            isactive:data.isactive,
            isoccupied:data.isoccupied,
           // ispayment: data.ispayment,
            propertyid: data.propertyid,
            propertyname: data.propertyname,
            lease_terms: data.lease_terms,
            street_address: data.street_address,
            units: data.units,
            city: data.city,
            state: data.state,
            zip: data.zip,
        }));
        dispatch(setproperty3({
            description: data.description,
            property_type_id: data.property_type_id,
            property_type_name: data.property_type_name,
            bedrooms_id: data.bedrooms_id,
            bedrooms_range: data.bedrooms_range,
            bathrooms_id: data.bathrooms_id,
            bathrooms_range: data.bathrooms_range,
            parking_type: data.parking_type,
            pet_policy_id: data.pet_policy_id,
            pet_policy_condition: data.pet_policy_condition,
            overlooking_id: data.overlooking_id,
            overlooking_type: data.overlooking_type,
            expected_monthly_rent: data.expected_monthly_rent,
            total_area_in_sqft: data.total_area_in_sqft,
            security_deposit:data.security_deposit
        }));

        dispatch(setproperty1({
            propertyAmenitiesSmartList: [
                data.propertyAmenitiesSmartList?.map((item, id) => {
                    return {
                        amenities_smart_id: item.amenities_smart_id,
                        amenities_smart: item.amenities_smart
                    }
                })

            ],
            propertyAmenitiesEnergyEfficientList: [
                data.propertyAmenitiesEnergyEfficientList?.map((item, id) => {
                    return {
                        amenities_energy_efficient_id: item.amenities_energy_efficient_id,
                        amenities_energy_efficient: item.amenities_energy_efficient
                    }
                })

            ],
            propertyAmenitiesCommunityList: [
                data.propertyAmenitiesCommunityList?.map((item, id) => {
                    return {
                        amenities_community_id: item.amenities_community_id,
                        amenities_community: item.amenities_community
                    }
                })
            ],
            propertyImageList: [
                data.propertyImageList?.map((item, id) => {
                    return {
                        image_url: item.image_url,

                    }
                })
            ],
            cover_image_url: data.cover_image_url,
            virtual_tour_link: data.virtual_tour_link
        }
        ))
        navigate("/list-property")
    }
    return (
        <>
            {loading && <Loading />}
            <div className="myProfileContainer pb-5">
                <h4 className='mt-5 ms-3 mb-0'>My Listings</h4>
                <div className="row g-3">
                    {properylist?.map((item, id) =>
                        <div className="col-xxl-3  col-md-4 col-sm-6 col-12">
                            <div className="card-shadow" key={id}>
                                <ProductCard listdata={listdata[id]} edit="block"
                                    path={`${item.cover_image_url}`} heart="none" cross="block" unfavourite="none" daysLeft="block" onlyPrice="none" />
                                <div className="d-flex">{
                                    item?.ispayment !== "N"
                                        ? <select className="shadow-none makePaymentBtn w-100 border-none py-2    green00 font-regular form-select form-select-md form-control removeRadious"
                                            onClick={(e) => occupiedHandler(item, e.target.value)}>
                                            <option value="available">Available</option>
                                            <option value="occupied">Occupied</option>
                                            {item?.isrenewpaymentallowed !== "N" && <option value="Renew">Renew</option>}
                                        </select> :
                                        <button className=" makePaymentBtn w-100 border-none   fill-green00 white00 font-regular py-2"
                                            onClick={() => { Setpaymentmodal(true); SetPaymentdata(item); }} >Pay now</button>}
                                    <button className='border-none fill-white00 green00 p-2 px-3' onClick={() => { editProperty(item) }}
                                    ><MdModeEdit /></button>
                                </div>

                            </div>
                        </div>
                    )}

                </div>

            </div>
            <Payment paymentmodal={paymentmodal} Setpaymentmodal={Setpaymentmodal} paymentdata={paymentdata} renew={renew} Setrenew={Setrenew} fatchProperty={fatchProperty}/>

            <Modal centered show={paymentconfirm} onHide={() => { Setpaymentconfirm(false); navigate('/my-account/my-listing'); }}>
                <Modal.Header >
                    <Modal.Title> <h5 className='green00'>Payment Confirmation</h5></Modal.Title>
                </Modal.Header>
                <Modal.Body>Thank You for Listing Your Property! Payment Confirmed. </Modal.Body>
                <Modal.Footer>
                    <button className='border-none px-3 py-2 font-14' onClick={() => { navigate('/my-account/my-listing'); Setpaymentconfirm(false) }}>Ok</button>
                </Modal.Footer>
            </Modal>
        </>
    )
}
