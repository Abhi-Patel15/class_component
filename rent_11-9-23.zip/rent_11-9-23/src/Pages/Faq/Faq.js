import React, { useEffect, useState } from 'react'
import './Faq.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import { APIRequest, GET_FAQ } from '../../api';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';


export default function   Faq() {
  const [select, Setselect] = useState("landlord");
  const [faqdata, Setfaqdata] = useState([])
  const navigate = useNavigate()

  useEffect(() => {
    Setfaqdata([])
    new APIRequest.Builder()
      .post()
      .setReqId(GET_FAQ)
      .jsonParams({
        "applicableto": select
      })
      .reqURL("master/getfaq")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [select])

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case GET_FAQ:
        Setfaqdata(response.data.data)
        break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case GET_FAQ:
        console.log(response)
        break;
      default:
        break;
    }
  }
 
  return (
    <>
      <div className='main'>
        <div className="faq_container marginMain">
          <div className="container-fluid p-0 ">
            <h2 className='page-heading'><span className='font-semibold'>FAQ</span>s</h2>           
            <p className='faqpera1 black50'>Not able to find an answer, you can <Link to='/contact-us' className='underline black00'>contact us</Link> anytime.</p>
          </div>
          <div className="container-fluid p-md-4 p-sm-3 p-2 mt-5  fill-white25 ">
            <div className="row mb-md-5">
              <div className="col-md-8 col-xs-12  ">
                <select className='shadow-none roleDropdown fill-white25 form-select form-select-lg form-control' name="" id="" onChange={e => Setselect(e.target.value)}>
                  <option value="landlord">I'm landlord</option>
                  <option value="renter">I'm Tenant</option>
                </select>
              </div>


              {/* 25-11 <div className="col-md-4 col-xs-12 ">
                  <div className="searchbox2 d-flex float-md-end ">
                    <input type="text" />
                     
                    <button className='p-0 text-center bg-none border-none' onClick={()=>{alert("search")}}><BiSearch className='black75 searchIconFaq'/></button>
                  </div> 
              </div> */}

              <div className="faqAccordianContainer">
                <div className="accordion mt-3 " id="accordionExample">
                  {faqdata?.map((item, id) => <>
                    <div className="accordion-item removeRadious">
                      <h2 className="accordion-header" id={`#heading_${id}`}>
                        <button className="accordion-button shadow-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target={`#collapse_${id}`} aria-expanded="false" aria-controls={`collapse_${id}`}>
                          {item?.question}
                        </button>
                      </h2>
                      <div id={`collapse_${id}`} className="accordion-collapse collapse " aria-labelledby={`#eading_${id}`} data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <p className='text-justify'>{item?.answer}</p>
                        </div>
                      </div>
                    </div>
                  </>)}


                </div>
              </div>

            </div>


          </div>
        </div>
      </div>


    </>
  )
}
