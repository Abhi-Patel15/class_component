import React, { useEffect, useState, useRef } from "react";
import Navbar from "../../Components/Navbar/Navbar";
import Select from "react-select";
import "./ListProperty.css";
import "../../Common/common.css";
import { Link, useNavigate } from "react-router-dom";
import * as Yup from "yup";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { logout, setproperty2 } from "../../redux/action";
import { APIRequest, CITYLIST, STATELIST } from "../../api";
import { ADDRESS_TOKEN, STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from "../../Common/AddressToken";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { SignalCellular0Bar } from "@material-ui/icons";

export default function ListProperty2() {
  const inputRef = useRef(null);

  const handlePlaceChanged = () => {
    const [place] = inputRef.current.getPlaces();
    if (place) {
      console.log(place.formatted_address);
      console.log(place.geometry.location.lat());
      console.log(place.geometry.location.lng());
    }
  };
  const property1 = useSelector((state) => state.property1);
  const property3 = useSelector((state) => state.property3);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const property2 = useSelector((state) => state.property2);
  const propertys = useSelector((state)=>state.property2)
  const [stateid, Setstateid] = useState();
  const [value, setValue] = useState(property2?.street_address);
  const [suggestions, setSuggestions] = useState([]);
  const [validation, SetValidation] = useState(false);
  const [visiblity, setVisiblity] = useState(false);

  const DataValidasion = {
    propertyname: Yup.string().max(256, "Maximum 256 Character Allowed"),
    lease_terms: Yup.string()
      .required("Lease Terms is required")
      .max(256, "Maximum 256 Character Allowed"),
    street_address: Yup.string()
      .required("Street Address is required ")
      .min(3, "Enter Minimum 3 Character")
      .max(500, "Maximum 500 Character Allowed")
      .test("street_address", "Invalid address", function (value){
        if(property2 !==null && property2.isapproved !== undefined){
          const nameArr = validation;
         return nameArr;
        }else{
        return suggestions.some((el)=>el.place_name.trim().toLowerCase() == (value).trim().toLowerCase())
      }
      }),

    units: Yup.string().max(250, "Maximum 250 Character Allowed"),
    // city: Yup.string().required("Required"),
    // state: Yup.string().required("Required"),
    // zip: Yup.string().length(4, "Zip Code Should be 4 Digit").required("Please Enter Zip Code").matches(/^[0-9]+$/, "Must be only digits"),
  };
  const listproperty = useFormik({
    initialValues: {
      days_remaining: property2?.days_remaining,
      isapproved: property2?.isapproved,
      isactive: property2?.isactive,
      isoccupied: property2?.isoccupied,
      ispayment: property2?.ispayment,
      propertyid: property2?.propertyid ?? null,
      propertyname: property2?.propertyname ?? "",
      lease_terms: property2?.lease_terms ?? "",
      street_address: property2?.street_address ?? "",
      units: property2?.units ?? "",
    },
    enableReinitialize: true,
    validationSchema: Yup.object().shape(DataValidasion),
    onSubmit: (values) => {
      if (values.propertyid) {
        dispatch(setproperty2(values));
        navigate("/list-property3");
      } else {
        delete values.propertyid;
        delete values.days_remaining;
        delete values.isactive;
        delete values.isoccupied;
        delete values.ispayment;
        dispatch(setproperty2(values));
        navigate("/list-property3");
      }
    },
  });
  useEffect(() => {
    if (property2?.propertyname) {
      listproperty.setFieldValue("propertyname", property2?.propertyname);
      listproperty.setFieldValue("lease_terms", property2?.lease_terms);
      listproperty.setFieldValue("street_address", property2?.street_address);
      listproperty.setFieldValue("units", property2?.units);
      listproperty.setFieldValue("city", property2?.city);
      listproperty.setFieldValue("state", property2?.state);
      listproperty.setFieldValue("zip", property2?.zip);
    }
  }, []);

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    if(response.data.status==STATE_ERROR){
      localStorage.clear()
      dispatch(logout())
      navigate("/login");
    }
    switch (reqId) {
      case CITYLIST:
        console.log(response.data.data);
        break;
      case STATELIST:
        console.log(response.data.data);
        break;
      default:
        break;
    }
  };

  const property =
    (listproperty.values.street_address === 0 && value === undefined ) ||
    (listproperty.values.street_address === value && suggestions.length === 0);
  useEffect(() => {
    if (suggestions.length === 0) {
      SetValidation(property);
    }
    return setSuggestions([]);
  }, [property]);
  
  const handleChange = async (event) => {
    setValue(event.target.value);
    try {
      const endpoint = `https://api.mapbox.com/geocoding/v5/mapbox.places/${event.target.value}.json?access_token=${ADDRESS_TOKEN}&autocomplete=true`;
      const response = await fetch(endpoint);
      const results = await response.json();
      const Address = results?.features.some((el)=>el.place_name.trim().toLowerCase() == (event.target.value).trim().toLowerCase())
      SetValidation(Address)
      setSuggestions(results?.features);
    } catch (error) {
      console.log("Error fetching data: ", error);
    }
    listproperty.setFieldValue("street_address", event.target.value);
  };
  const handleFocus = () => {
    setVisiblity("true");
  };

  const handleBlur = () => {
    setTimeout(() => {
      setVisiblity(false);
    }, 200);
  };
 
  const handleSuggestionClick = (suggestionvalue) => {
    setValue(suggestionvalue.place_name);
    setVisiblity(false);
    SetValidation(
      suggestions.length > 0 &&
        !suggestions.some(
          (suggestion) =>
            suggestion.place_name.toLowerCase() === value.trim().toLowerCase()
        )
    );
    listproperty.setFieldValue("street_address", suggestionvalue.place_name);
  };
  return (
    <>
      <div className="main">
        <div className="listPropertyContainer marginMain">
          <div className="container-fluid">
            <h2 className="page-heading">
              {property2?.propertyid ? "Update" : "List"}{" "}
              <span className="font-semibold">Property</span>
            </h2>

            {/* progress bar */}
            {property2?.propertyid ? (
              <div className="row my-5 progressBar">
                <div className="d-flex">
                  <div className="me-4">
                    <p
                      onClick={() => {
                        navigate("/list-property");
                      }}
                      className="font-semibold  green00 mb-1 cursorPointer"
                    >
                      1. Personal Information
                    </p>
                    <div className="progresBar fill-green00"></div>
                  </div>
                  <div className="me-4">
                    <p
                      onClick={() => {
                        navigate("/list-property2");
                      }}
                      className="font-semibold  black00 mb-1 cursorPointer"
                    >
                      2. Property Information
                    </p>
                    <div className="progresBar fill-green00"></div>
                  </div>
                  <div className="me-4">
                    <p
                      onClick={() => {
                        navigate("/list-property3");
                      }}
                      className="font-semibold  black50 mb-1 cursorPointer"
                    >
                      3. Property Description
                    </p>
                    <div className="progresBar fill-green00"></div>
                  </div>
                  <div className="me-4">
                    <p
                      onClick={() => {
                        navigate("/list-property4");
                      }}
                      className="font-semibold  black50 mb-1 cursorPointer"
                    >
                      4. Amenities and Pictures
                    </p>
                    <div className="progresBar fill-green00"></div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="row my-5 progressBar">
                <div className="d-flex">
                  <div className="me-4">
                    <p
                      className="font-semibold  green00 mb-1 cursorPointer"
                      onClick={() => {
                        navigate("/list-property");
                      }}
                    >
                      1. Personal Information
                    </p>
                    <div className="progresBar fill-green00"></div>
                  </div>
                  {property2 === null ? (
                    <div className="me-4">
                      <p className="font-semibold  black00 mb-1">
                        2. Property Information
                      </p>
                      <div className="progresBar fill-white25"></div>
                    </div>
                  ) : (
                    <div className="me-4">
                      <p
                        className="font-semibold  green00 mb-1 cursorPointer"
                        onClick={() => {
                          navigate("/list-property2");
                        }}
                      >
                        2. Property Information
                      </p>
                      <div className="progresBar fill-green00"></div>
                    </div>
                  )}
                  {property3 === null ? (
                    <div className="me-4">
                      <p className="font-semibold  black50 mb-1">
                        3. Property Description
                      </p>
                      <div className="progresBar fill-white25"></div>
                    </div>
                  ) : (
                    <div className="me-4">
                      <p
                        className="font-semibold  green00 mb-1 cursorPointer"
                        onClick={() => {
                          navigate("/list-property3");
                        }}
                      >
                        3. Property Description
                      </p>
                      <div className="progresBar fill-green00"></div>
                    </div>
                  )}
                  {property1 === null ? (
                    <div className="me-4">
                      <p className="font-semibold  black50 mb-1">
                        4. Amenities and Pictures
                      </p>
                      <div className="progresBar fill-white25"></div>
                    </div>
                  ) : (
                    <div className="me-4">
                      <p
                        className="font-semibold  green00 mb-1 cursorPointer"
                        onClick={() => {
                          navigate("/list-property4");
                        }}
                      >
                        4. Amenities and Pictures
                      </p>
                      <div className="progresBar fill-green00"></div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {property2?.propertyid ? (
              <div className="row mt-2 progressBarTab">
                <div
                  className="round activate"
                  onClick={() => {
                    navigate("/list-property");
                  }}
                >
                  1
                </div>
                <div className="Line"></div>
                <div
                  className="round activate"
                  onClick={() => {
                    navigate("/list-property2");
                  }}
                >
                  2
                </div>
                <div className="Line"></div>
                <div
                  className="round activate"
                  onClick={() => {
                    navigate("/list-property3");
                  }}
                >
                  3
                </div>
                <div className="Line"></div>
                <div
                  className="round activate"
                  onClick={() => {
                    navigate("/list-property4");
                  }}
                >
                  4
                </div>
              </div>
            ) : (
              <div className="row mt-2 progressBarTab">
                <div
                  className="round activate"
                  onClick={() => {
                    navigate("/list-property1");
                  }}
                >
                  1
                </div>
                <div className="Line"></div>
                {property2 === null ? (
                  <div className="round  ">2</div>
                ) : (
                  <div
                    className="round activate"
                    onClick={() => {
                      navigate("/list-property2");
                    }}
                  >
                    2
                  </div>
                )}
                <div className="Line"></div>
                {property3 === null ? (
                  <div className="round  ">3</div>
                ) : (
                  <div
                    className="round activate"
                    onClick={() => {
                      navigate("/list-property3");
                    }}
                  >
                    3
                  </div>
                )}
                <div className="Line"></div>
                {property1 === null ? (
                  <div className="round  ">4</div>
                ) : (
                  <div
                    className="round"
                    onClick={() => {
                      navigate("/list-property4");
                    }}
                  >
                    4
                  </div>
                )}
              </div>
            )}

            <div className="listFormContainer w-100 fill-white25 mt-3">
              <form onSubmit={listproperty.handleSubmit}>
                <div className="container-fluid pb-5">
                  {/* form */}
                  <div className="row">
                    <div className="col-md-6 col-sm-12  mt-3 ">
                      <label className="green00 font-semibold mb-1" htmlFor="">
                        Property Name{" "}
                      </label>
                      <br />
                      <input
                        type="text"
                        className="shadow-none fill-white25 removeRadious  form-control border-black25"
                        name="propertyname"
                        id="propertyname"
                        defaultValue={property2?.propertyname}
                        onChange={listproperty.handleChange}
                      />
                      {listproperty.touched.propertyname &&
                      listproperty.errors.propertyname ? (
                        <span className="error">
                          {listproperty.errors.propertyname}
                        </span>
                      ) : null}
                    </div>
                    <div className="col-md-6 col-sm-12 mt-3">
                      <label className="green00 font-semibold mb-1" htmlFor="">
                        Lease Terms* <span className="small">(e.g 1.6 Year, 6 Months)</span>{" "}
                      </label>
                      <br />
                      <input
                        type="text"
                        className="shadow-none fill-white25 removeRadious    form-control border-black25"
                        name="lease_terms"
                        id="lease_terms"
                        defaultValue={property2?.lease_terms}
                        onChange={listproperty.handleChange}
                      />
                      {listproperty.touched.lease_terms && 
                      listproperty.errors.lease_terms ? (
                        <span className="error">
                          {listproperty.errors.lease_terms}
                        </span>
                      ) : null}
                    </div>
                    <div className="col-md-6 col-sm-12 mt-3">
                      <label className="green00 font-semibold mb-1" htmlFor="">
                        Street Address*{" "}
                      </label>
                      <br />
                      <div className="Wrapper">
                        <input
                          className="shadow-none fill-white25 removeRadious form-control border-black25 "
                          value={value}
                          suggestion={suggestions}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onFocus={handleFocus}
                          isTyping={value !== ""} 
                          disabled={property2 !==null && property2.isapproved !== undefined? true :false}
                          />
                        {visiblity && suggestions?.length > 0 && (
                          <div className="suggestion1  ">
                            {suggestions.map((suggestion, index) => {
                              return (
                                <p
                                  className="datas"
                                  key={index}
                                  onClick={() =>
                                    handleSuggestionClick(suggestion)
                                  }
                                >
                                  {suggestion.place_name}
                                </p>
                              );
                            })}
                          </div>
                        )}
                      </div>
                      {listproperty.touched.street_address  && (property2 !==null && property2.isapproved !== undefined?!validation:false )&&
                      listproperty.errors.street_address ? (
                        <span className="error">
                          {listproperty.errors.street_address}
                        </span>
                      ) : null}
                    </div>
                    <div className="col-md-6 col-sm-12 mt-3">
                      <label className="green00 font-semibold mb-1" htmlFor="">
                        {" "}
                        Units #{" "}
                      </label>
                      <br />
                      <input
                        type="text"
                        className="shadow-none fill-white25 removeRadious form-control border-black25"
                        name="units"
                        id="units"
                        autoComplete="address-line2"
                        defaultValue={property2?.units}
                        onChange={listproperty.handleChange}
                        disabled={property2 !==null && property2.isapproved !== undefined? true :false}
                      />         
                      {listproperty.touched.units &&
                      listproperty.errors.units ? (
                        <span className="error">
                          {listproperty.errors.units}
                        </span>
                      ) : null}
                    </div>
                  </div>
                  <div className="row">
                    <button
                      type="submit"
                      className="submitbutton border-none fill-green00 white00 px-3 py-2 text-center removeLinkDefaults"
                    >
                
                      Next
                    </button>
                    <ToastContainer />
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
