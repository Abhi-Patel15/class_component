import React from 'react'
import {Elements} from '@stripe/react-stripe-js';
import {loadStripe} from '@stripe/stripe-js';
import CheckoutForm from './MyAccount/checkoutform';
const stripePromise = loadStripe('pk_test_51M2qopSFtaxZehQTQClyCqrqfGi3X3tEe95hMWdsuaJcj0m4pwLEzkAyCykDg50ZYOT8JkRQ0LkgZs5QdyEl18ws00BL85qXxs');

const Paymenttest = () => {
    const options = {
        // passing the client secret obtained from the server
        clientSecret: 'pi_3MKiUrSFtaxZehQT1cFrTKN9_secret_sEtZ1levaI2dm4xahCbaxbiWW',
      };
  return (
    <>
      <Elements stripe={stripePromise} options={options}>
      <CheckoutForm></CheckoutForm>
    </Elements>
    </>
  )
}

export default Paymenttest