import React, { useEffect,useState } from 'react'
import './Comparision.css'
import '../../Common/common.css'
import Navbar from '../../Components/Navbar/Navbar';   
import Footer from '../../Components/Footer/Footer';  
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { APIRequest,COMPARE1_PROPERTTLIST,COMPARE2_PROPERTTLIST,COMPARE3_PROPERTTLIST,COMPARE4_PROPERTTLIST } from '../../api';
import { setcompareproperty, setcomparepropertydelete } from '../../redux/action';
import { light } from '@mui/material/styles/createPalette';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';

export default function Comparision() {
   const listcompare=useSelector(state=>state.compareproperty)

   const dispatch =useDispatch();
   const [properylist ,Setpropertylist]=useState([]);
   const [properylist1 ,Setpropertylist1]=useState([]);
   const [properylist2 ,Setpropertylist2]=useState([]);
   const [properylist3 ,Setpropertylist3]=useState([]);
   const [comparelist ,SetComparelist] =useState(listcompare);  
   const navigate = useNavigate()
  
   useEffect(()=>{
      if(listcompare[0]){
      new APIRequest.Builder()
      .post()
      .setReqId(COMPARE1_PROPERTTLIST)
      .jsonParams({
         "propertyid": listcompare[0],
          "isactive": "Y"
      })
      .reqURL("property/get_propertydetail")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
   }
     if(listcompare[1]){
      new APIRequest.Builder()
      .post()
      .setReqId(COMPARE2_PROPERTTLIST)
      .jsonParams({
         "propertyid": listcompare[1],
          "isactive": listcompare[1]? "Y" :"N"
      })
      .reqURL("property/get_propertydetail")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
   }
   if(listcompare[2]){
      new APIRequest.Builder()
      .post()
      .setReqId(COMPARE3_PROPERTTLIST)
      .jsonParams({
         "propertyid": listcompare[2],
          "isactive": listcompare[2]?"Y":"N"
      })
      .reqURL("property/get_propertydetail")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
   }
   if(listcompare[2]){
      new APIRequest.Builder()
      .post()
      .setReqId(COMPARE4_PROPERTTLIST)
      .jsonParams({
         "propertyid": listcompare[3],
          "isactive": listcompare[3]? "Y":"N"
      })
      .reqURL("property/get_propertydetail")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
   }

  },[])
 


  const removeFavouritr =(id)=>{
   const data = comparelist.filter((item) => item.toString() !== id.toString()); 
    dispatch(setcompareproperty(data))   
   SetComparelist(data)
  }

  const onResponse = (response, reqId) => {
      switch (reqId) {
          case COMPARE1_PROPERTTLIST:
              Setpropertylist(response?.data?.data)
              break;
              case COMPARE2_PROPERTTLIST:
               Setpropertylist1(response?.data?.data)
               break;
               case COMPARE3_PROPERTTLIST:
              Setpropertylist2(response?.data?.data)
              break;
              case COMPARE4_PROPERTTLIST:
              Setpropertylist3(response?.data?.data)
              break;   
          default:
              break;
      }
  }

  const onError = (response, reqId) => {
   if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
      switch (reqId) {
          case COMPARE1_PROPERTTLIST:
              console.log(response)
              break;
              case COMPARE2_PROPERTTLIST:
               console.log(response?.data)
               break;
               case COMPARE3_PROPERTTLIST:
               console.log(response?.data)
               break;
               case COMPARE4_PROPERTTLIST:
               console.log(response?.data)
               break;
              default:
              break;    
      }
  }

  
  return (
    <>
    <div className='main'>
      <div className="comparisionContainer marginMain">
        <h2 className="page-heading">Comparision</h2>


        <div className="container-fluid Parent">
          <div className="row  mt-4 new_row">          
           

            {properylist?.map((item ,id)=>
             <div className="valueList" key={id}>
             <div className="propertyImageContainer d-flex" >
                <img  src={`${properylist[0]?.cover_image_url}`} className='w-100' alt="" /> 
                <button className='btnPrice fill-green00 white00 border-none px-3 py-2  full-radious'>$ {item?.expected_monthly_rent} <span className='font-12'>monthly</span></button> 
                <button type='button' className='m-0 p-0 fill-white00 border-none  red00 heartBtn removeBtn'  onClick={()=> {removeFavouritr(item?.propertyid);Setpropertylist([])}}>&#10006;</button>
             </div>

             <p className='mb-0  mt-2 meta-title font-semibold green00'>Name</p>
             <div className="d-flex justify-content-between">
                <p className='black50 font-regular m-0 propertyName'>{item?.propertyname}</p>
                
             </div> 
            <hr className='m-0 mt-1' /> 
           
            <p className='mb-0 mt-2 meta-title font-semibold green00'>Address</p>
            <p className='black50 font-regular m-0  amenities compareAddressData'>{item?.street_address}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Lease Terms</p>
            <p className='black50 font-regular m-0  propertyName'>{item?.lease_terms}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bedroom</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bedrooms_range} Bedrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bathrooms</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bathrooms_range} Bathrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Property Type</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.property_type_name}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Pet Policy</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.pet_policy_condition}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Overlooking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.overlooking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Square ft.</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.total_area_in_sqft}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Parking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.parking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Security Deposit</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.security_deposit}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Smart Home Amenities</p>         
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{properylist[0]?.propertyAmenitiesSmartList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_smart }</span>})}</p> <hr className='m-0 mt-1' />

         <p className='mb-0 mt-2 meta-title font-semibold green00'> Energy-Efficient Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{properylist[0]?.propertyAmenitiesEnergyEfficientList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_energy_efficient }</span>})}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>In-unit or Community Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{properylist[0]?.propertyAmenitiesCommunityList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_community}</span>})}</p> <hr className='m-0 mt-1' />
            <Link to={`/property-details/${item?.propertyid}`} ><button className='fill-green00 white00 w-100 border-none mt-3 p-2'>View Details</button></Link>
          </div>
            )}
            {properylist1?.map((item ,id)=>
             <div className="valueList" key={id}>
             <div className="propertyImageContainer d-flex" >
                <img src={`${item?.cover_image_url}`} className='w-100' alt="" /> 
                <button className='btnPrice fill-green00 white00 border-none px-3 py-2  full-radious'>$ {item?.expected_monthly_rent} <span className='font-12'>monthly</span></button> 
                <button type='button' className='m-0 p-0 fill-white00 border-none  red00 heartBtn removeBtn'  onClick={()=> {removeFavouritr(item?.propertyid);Setpropertylist1([])}}>&#10006;</button>
             </div>

             <p className='mb-0  mt-2 meta-title font-semibold green00'>Name</p>
             <div className="d-flex justify-content-between">
                <p className='black50 font-regular m-0 propertyName'>{item?.propertyname}</p>
             </div> 
            <hr className='m-0 mt-1' /> 
           
            <p className='mb-0 mt-2 meta-title font-semibold green00'>Address</p>
            <p className='black50 font-regular m-0  amenities compareAddressData'>{item?.street_address}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Lease Terms</p>
            <p className='black50 font-regular m-0  propertyName'>{item?.lease_terms}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bedroom</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bedrooms_range} Bedrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bathrooms</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bathrooms_range} Bathrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Property Type</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.property_type_name}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Pet Policy</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.pet_policy_condition}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Overlooking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.overlooking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Square ft.</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.total_area_in_sqft}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Parking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.parking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Security Deposit</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.security_deposit}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Smart Home Amenities</p>         
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item.propertyAmenitiesSmartList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_smart }</span>})}</p> <hr className='m-0 mt-1' />

         <p className='mb-0 mt-2 meta-title font-semibold green00'> Energy-Efficient Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesEnergyEfficientList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_energy_efficient }</span>})}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>In-unit or Community Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesCommunityList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_community}</span>})}</p> <hr className='m-0 mt-1' />

            <Link to={`/property-details/${item?.propertyid}`} ><button className='fill-green00 white00 w-100 border-none mt-3 p-2'>View Details</button></Link>
          </div>
            )}
            {properylist2?.map((item ,id)=>
             <div className="valueList" key={id}>
             <div className="propertyImageContainer d-flex" >
                <img src={`${item?.cover_image_url}`} className='w-100' alt="" /> 
                <button className='btnPrice fill-green00 white00 border-none px-3 py-2  full-radious'>$ {item?.expected_monthly_rent} <span className='font-12'>monthly</span></button> 
                <button type='button' className='m-0 p-0 fill-white00 border-none  red00 heartBtn removeBtn'  onClick={()=>{ removeFavouritr(item?.propertyid);Setpropertylist2([])}}>&#10006;</button>
             </div>

             <p className='mb-0  mt-2 meta-title font-semibold green00'>Name</p>
             <div className="d-flex justify-content-between">
                <p className='black50 font-regular m-0 propertyName'>{item?.propertyname}</p>
                  </div> 
            <hr className='m-0 mt-1' /> 
           
            <p className='mb-0 mt-2 meta-title font-semibold green00'>Address</p>
            <p className='black50 font-regular m-0  amenities compareAddressData'>{item?.street_address}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Lease Terms</p>
            <p className='black50 font-regular m-0  propertyName'>{item?.lease_terms}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bedroom</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bedrooms_range} Bedrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bathrooms</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bathrooms_range} Bathrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Property Type</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.property_type_name}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Pet Policy</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.pet_policy_condition}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Overlooking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.overlooking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Square ft.</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.total_area_in_sqft}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Parking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.parking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Security Deposit</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.security_deposit}</p> <hr className='m-0 mt-1' />
          
             <p className='mb-0 mt-2 meta-title font-semibold green00'>Smart Home Amenities</p>         
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item.propertyAmenitiesSmartList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_smart }</span>})}</p> <hr className='m-0 mt-1' />

         <p className='mb-0 mt-2 meta-title font-semibold green00'> Energy-Efficient Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesEnergyEfficientList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_energy_efficient }</span>})}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>In-unit or Community Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesCommunityList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_community}</span>})}</p> <hr className='m-0 mt-1' />
            <Link to={`/property-details/${item?.propertyid}`} ><button className='fill-green00 white00 w-100 border-none mt-3 p-2'>View Details</button></Link>
          </div>
            )}
            {properylist3?.map((item ,id)=>
             <div className="valueList" key={id}>
             <div className="propertyImageContainer d-flex" >
                <img src={`${item?.cover_image_url}`} className='w-100' alt="" /> 
                <button className='btnPrice fill-green00 white00 border-none px-3 py-2  full-radious'>$ {item?.expected_monthly_rent} <span className='font-12'>monthly</span></button> 
                <button  type ='button' className='m-0 p-0 fill-white00 border-none  red00 heartBtn removeBtn'  onClick={()=>{removeFavouritr(item?.propertyid); Setpropertylist3([])}}>&#10006;</button>
             </div>

             <p className='mb-0  mt-2 meta-title font-semibold green00'>Name</p>
             <div className="d-flex justify-content-between">
                <p className='black50 font-regular m-0 propertyName '>{item?.propertyname}</p>
                </div> 
            <hr className='m-0 mt-1' /> 
           
            <p className='mb-0 mt-2 meta-title font-semibold green00'>Address</p>
            <p className='black50 font-regular m-0  amenities compareAddressData '>{item?.street_address}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Lease Terms</p>
            <p className='black50 font-regular m-0  propertyName'>{item?.lease_terms}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bedroom</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bedrooms_range} Bedrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Bathrooms</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.bathrooms_range} Bathrooms</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Property Type</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.property_type_name}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Pet Policy</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.pet_policy_condition}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Overlooking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.overlooking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Square ft.</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.total_area_in_sqft}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Parking</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.parking_type}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Security Deposit</p>
            <p className='black50 font-regular m-0 propertyName'>{item?.security_deposit}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>Smart Home Amenities</p>         
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item.propertyAmenitiesSmartList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_smart }</span>})}</p> <hr className='m-0 mt-1' />

         <p className='mb-0 mt-2 meta-title font-semibold green00'> Energy-Efficient Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesEnergyEfficientList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_energy_efficient }</span>})}</p> <hr className='m-0 mt-1' />

            <p className='mb-0 mt-2 meta-title font-semibold green00'>In-unit or Community Amenities</p>
            <p className='black50 font-regular m-0 amenities amenitiesFav'>{item?.propertyAmenitiesCommunityList?.map(function(item,index){
                         return <span key={`demo_snap_${index}`}>{ (index ? ', ' : '') + item.amenities_community}</span>})}</p> <hr className='m-0 mt-1' />
            <Link to={`/property-details/${item?.propertyid}`} ><button className='fill-green00 white00 w-100 border-none mt-3 p-2'>View Details</button></Link>
          </div>
            )}    
          
         
            {/* last for adding new (always be in the last position) */}
          {comparelist.length !==4 && <div className="AddNew"><Link className="removeLinkDefaults" to="/favorites" onClick={()=>{ dispatch(setcompareproperty(comparelist))  }}>
            <div className=" addPropertyBox text-center fill-white25">
                  <button className='fill-white00 green00 border-none font-bold mt-4'>+</button>
                  <p className='mt-3 black75 font-regular green00'>Add A property to <br/> compare</p>
               </div> 
               </Link>
            </div>   }  

           


          </div>
        </div>


      </div>
      </div>
  
    </>
  )
}
