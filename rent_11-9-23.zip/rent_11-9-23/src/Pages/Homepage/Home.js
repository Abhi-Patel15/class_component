import React, { useEffect, useState, useRef, createRef } from 'react'
import Select from 'react-select'
import './Homepage.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import ProductCard from '../../Components/ProductCard/ProductCard'
import { BiSearch } from 'react-icons/bi';
import Slider from "react-slick";
import { APIRequest, PROPERTYTYPE, STATELIST, CITYLIST, GET_PROPERTYSEARCH, LIST_PRIMECITY, LOGIN, FEATURED_PROPERTY, HOMEPAGE_SLIDER, ADDRESS_SUGGESTION } from '../../api';
import { CgSearch } from 'react-icons/cg'
import { useFormik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import { logout, setsearchproperty, setstatecity, setToken } from '../../redux/action';
import toast from 'react-simple-toasts';
import parse from 'html-react-parser';
import Modal from 'react-bootstrap/Modal';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';
import axios from 'axios';



const Home = () => {
  const [propertype, Setpropertype] = useState();
  const [homepage, Sethomepage] = useState();
  const [citylist, Setcitylist] = useState([]);
  const [filteredCitylist, SetFilteredCitylist] = useState([]);
  const [statelist, Setstatelist] = useState([]);
  const [stateid, Setstateid] = useState();
  const [primecity, SetPrimeCity] = useState([]);
  const [featuredproperty, Setfeaturedproperty] = useState([]);
  const [address, Setaddress] = useState("");
  const [listdata, SetListdata] = useState();
  const user = useSelector(state => state.user);
  const token = useSelector(state => state.token)
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [suggestionFocus, setSuggestionFocus] = useState(null);
  // const [suggestionRefs, setSuggestionRefs] = useRef([]);
  const [dataReload, setDataReload] = useState(true)


  const searchproperty = useFormik({
    initialValues: {
      login_userid: user?.userid,
      street_address: "",
      min_amount: "",
      max_amount: "",
      property_type_name: ""
    },
    onSubmit: values => {
      new APIRequest.Builder()
        .post()
        .setReqId(GET_PROPERTYSEARCH)
        .jsonParams(values)
        .reqURL('property/get_propertysearch')
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      dispatch(setstatecity(values))
    }
  });


  useEffect(() => {
    if (user === null) {
      new APIRequest.Builder()
        .post()
        .setReqId(LOGIN)
        .jsonParams({
          "emailid": "guest@rent.com",
          "password": "Guest@123"
        })
        .reqURL("user/signin")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    }
  }, [])



  useEffect(() => {
    if (token) {
      new APIRequest.Builder()
        .post()
        .setReqId(PROPERTYTYPE)
        .jsonParams({ "isactive": "Y" })
        .reqURL("master/getpropertytype")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      new APIRequest.Builder()
        .post()
        .setReqId(ADDRESS_SUGGESTION)
        .jsonParams({
          "street_address": address
        })
        .reqURL("property/get_propertysearch_keyword")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      new APIRequest.Builder()
        .post()
        .setReqId(STATELIST)
        .jsonParams({ "isactive": "Y" })
        .reqURL("master/get_statemaster")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      new APIRequest.Builder()
        .post()
        .setReqId(LIST_PRIMECITY)
        .jsonParams({ "isactive": "Y" })
        .reqURL("master/get_prime_city_property")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
      new APIRequest.Builder()
        .post()
        .setReqId(FEATURED_PROPERTY)
        .jsonParams({
          "start_limit": 0,
          "end_limit": 10
        })
        .reqURL("property/get_propertysearch")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();

      new APIRequest.Builder()
        .post()
        .setReqId(HOMEPAGE_SLIDER)
        .jsonParams({
          "pagename": "HOMEPAGE"
        })
        .reqURL("master/gethomepagemaster")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    }
  }, [token])



  useEffect(() => {
    if (address) {
      SetFilteredCitylist([
        ...citylist.filter(post => post.street_address.toLowerCase().includes(address.toLowerCase())),
      ]);
    }
    else {
      SetFilteredCitylist([...citylist]);
    }
  }, [address])

  useEffect(() => {
    SetFilteredCitylist([...citylist]);
  }, [citylist]);

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case PROPERTYTYPE:
        Setpropertype(response?.data?.data)
        break;
      case ADDRESS_SUGGESTION:
        Setcitylist(response.data.data)
        break;
      case STATELIST:
        Setstatelist(response.data.data)
        break;
      case GET_PROPERTYSEARCH:
        if (response.data.data.length === 0) {
          // toast("No Property Found")
          setShow(true)
        } else {
          dispatch(setsearchproperty(response.data.data))
          navigate("/property-display")
        }

        break;
      case LOGIN:
        if (response.data.data?.accessToken) {
          dispatch(setToken(response.data.data.accessToken))
          // setDataReload(false)
        }
        break;
      case LIST_PRIMECITY:
        SetPrimeCity(response.data.data)
        break;
      case FEATURED_PROPERTY:
        Setfeaturedproperty(response.data.data);
        SetListdata(response?.data?.data)
        break;
      case HOMEPAGE_SLIDER:
        Sethomepage(response.data.data[0]);
        break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if (response.data.status == STATE_ERROR && dataReload) {
      localStorage.clear()
      dispatch(logout())
      navigate("/");

    }
    if (STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status) {
      navigate('/not')
    }
    switch (reqId) {
      case PROPERTYTYPE:
        // console.log(response?.data?.data)
        break;
      case ADDRESS_SUGGESTION:
        // console.log(response?.data?.data)
        break;
      case STATELIST:
        // console.log(response?.data?.data)
        break;
      case GET_PROPERTYSEARCH:
        // console.log(response?.data?.data)
        break;
      case LOGIN:
        toast("Something Went Wrong")
        break;
      case LIST_PRIMECITY:
        console.log(response.data.data)
        break;
      case FEATURED_PROPERTY:
        console.log(response.data.data,)
        break;
      case HOMEPAGE_SLIDER:
        console.log(response.data.data)
        break;
      default:
        break;
    }
  }

  const settings = {
    dots: true,
    infinite: featuredproperty.length >= 3 ? true : false,
    swipeable: true,
    draggable: true,
    // speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    // speed: 2500,
    autoplaySpeed: 2500,
    cssEase: "linear",
    // 
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
        }
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  const settings2 = {
    dots: true,
    infinite: primecity.length >= 3 ? true : false,
    // speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    // speed: 1000,
    autoplaySpeed: 2500,
    cssEase: "linear"
  };

  const settings3 = {
    className: "center",
    centerMode: false,
    infinite: primecity.length >= 3 ? true : false,
    slidesToShow: 3,
    speed: 500,
    rows: 2,
    slidesPerRow: 1,
    dots: true,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 2500,
    cssEase: "linear",
    focusOnSelect: true
  };
  const stateOptions = statelist?.map((item) => { return { "label": item.state, "value": item.stateid } })
  const cityOptions = stateid && citylist?.map((item) => { return { "label": item.city, "value": item.cityid } })

  const primecitySearch = (e) => {
    dispatch(setstatecity({
      street_address: e.street_address,
      // city: e.city,
    }))
    new APIRequest.Builder()
      .post()
      .setReqId(GET_PROPERTYSEARCH)
      .jsonParams({ street_address: e.city })
      .reqURL('property/get_propertysearch')
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }

  const [suggestion, setSuggestion] = useState(false)
  let menuRef = useRef();
  useEffect(() => {
    let handler = (event) => {
      if (!menuRef.current.contains(event.target)) {
        setTimeout(() => {
          setSuggestion(false)
        }, 200);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => {
      document.removeEventListener("mousedown", handler)
    }
  }, [])

  const handleChange = () => {
    setSuggestion(true)
  }
  const autofill = (data) => {
    searchproperty.setFieldValue("street_address", data)
    setSuggestion(false)
  }


  const handleKeyDown = (e) => {
    const keyCode = e.keyCode;
    if (keyCode === 38) {
      // arrow up key
      let nextFocus = (suggestionFocus ?? 0) - 1;
      if (nextFocus < 0) nextFocus = 0;
      setSuggestionFocus(nextFocus);
    } else if (keyCode === 40) {
      // arrow down key
      let nextFocus = (suggestionFocus ?? -1) + 1;
      if (nextFocus >= filteredCitylist.length) nextFocus = filteredCitylist.length - 1;
      setSuggestionFocus(nextFocus);
    }
    else if (keyCode === 13) {
      // enter key
      let addressData = searchproperty.values.street_address;
      if (suggestionFocus !== null) {
        addressData = filteredCitylist[suggestionFocus]?.street_address ?? searchproperty.values.street_address;
      }
      autofill(addressData);
    }
  }

  return (
    <>
      <div className='main'>
        <div className="heroMainContainerWeb container-fluid p-0">
          <div className="row home_Row1 p-0">
            <div className="col-lg-8 col-xxl-9 p-0">
              <div className="box1 gradient-bg h-100">
                {homepage && <h1 className='white00   hero-heading'>{parse(homepage?.text)}
                </h1>}
                <form className="searchBox px-4" onSubmit={searchproperty.handleSubmit}>
                  <div ref={menuRef} className="Location me-1 marginEnd">
                    <p className='font-bold mb-0'>Location</p>
                    <input className={`LocaionInput ps-2 p-0 `} type="text" placeholder='Enter here...'
                      name='street_address'
                      id='street_address'
                      autoComplete={"off"}
                      onKeyDown={handleKeyDown}
                      value={searchproperty.values.street_address} onChange={e => {
                        setSuggestionFocus(null);
                        Setaddress(e.target.value);
                        searchproperty.setFieldValue("street_address", e.target.value);
                        handleChange();
                      }} />
                    <div className="suggestions" style={{ display: !suggestion ? 'none' : 'block' }}>
                      {
                        filteredCitylist.map((data, key) =>
                          <button type="button" varient="primery"
                            onClick={() => { autofill(data?.street_address) }} className={`singleSearchSuggestion ` + (suggestionFocus === key ? "active" : "")}
                            style={{ color: "black" }} key={"city_" + key}>{data?.street_address}</button>)
                      }
                    </div>
                  </div>
                  <div className="Location me-1 marginEnd">
                    <p className='font-bold mb-0'>Price</p>
                    <div className="d-flex">
                      <input className='minmaxInput me-1   p-0' placeholder='$ Min' type="text"
                        id='min_amount' name='min_amount'
                        value={searchproperty.values.min_amount} onChange={searchproperty.handleChange} />
                      <input className='minmaxInput me-1   p-0' placeholder='$ Max' type="text"
                        id='max_amount' name='max_amount'
                        onChange={searchproperty.handleChange} value={searchproperty.values.max_amount} />
                      <button className='bg-none border-none' type='submit'><BiSearch className='searchIcon ' /></button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div className="col-lg-4 col-xxl-3  p-0  ">
              <div className="box2 gradient-bg h-100">
                <img src={homepage?.imageurl === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/HomeMain.png` : `${homepage?.imageurl}`} className='w-100' alt="" />
              </div>
            </div>
          </div>
        </div>
        <div className='heroMainContainerTab container-fluid p-0'>
          {homepage && <h1 className='white00 hero-heading-tab'>{parse(homepage?.text)}
          </h1>}
          <div className='overly'></div>
          <img src={homepage?.imageurl === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/HomeMain.png` : `${homepage?.imageurl}`} alt="" className="HomeImg" />
          <div className='heroTabSearch margingTablet'>
            <form onSubmit={searchproperty.handleSubmit}>
              <div className="container-fluid">
                <div ref={menuRef} className="row p-0">
                  <input type="text"
                    placeholder='Location'
                    name='street_address'
                    id='street_address'
                    autoComplete={"off"}
                    className='tabSearchInput border-none bg-none px-2 py-2 border-bottom-black'
                    onKeyDown={handleKeyDown}
                    value={searchproperty.values.street_address} onChange={e => {
                      setSuggestionFocus(null);
                      Setaddress(e.target.value);
                      searchproperty.setFieldValue("street_address", e.target.value);
                      handleChange();
                    }} />
                  <div className="suggestions" style={{ display: !suggestion ? 'none' : 'block' }}>
                    {
                      filteredCitylist.map((data, key) =>
                        <button type="button" varient="primery"
                          onClick={() => { autofill(data?.street_address) }} className={`singleSearchSuggestion ` + (suggestionFocus === key ? "active" : "")}
                          style={{ color: "black" }} key={"city_" + key}>{data?.street_address}</button>)
                    }
                  </div>
                </div>

                <div className="row">
                </div>
                <div className="row p-0 mt-1 InputRow">
                  <input type="text" placeholder='$Min' name='min_amount' id='min_amount' className='tabSearchInput border-none bg-none px-2 py-2 border-bottom-black InputFilde'
                    value={searchproperty.values.min_amount} onChange={searchproperty.handleChange} />
                  <input type="text" name='max_amount' id='max_amount' placeholder='$Max' className='tabSearchInput border-none bg-none px-2 py-2 border-bottom-black InputFilde'
                    value={searchproperty.values.max_amount} onChange={searchproperty.handleChange} />
                </div>
              </div>
              <div className='mt-1 d-flex justify-content-center'>
                <button type='submit' className='float-end border-none fill-black00 white00 px-2 py-1 font-20'><BiSearch /></button>
              </div>
            </form>
          </div>
        </div>

        <div className="HomeMainContainer">
          <div className="container-fluid p-0">
            <div className="row mt-5 pt-5">
              <div className="col-12 text-center">
                {primecity.length !== 0 && <h2 className='font-thin'>Have a look at our <span className='font-bold'>Prime Location </span></h2>}
              </div>
              <div className="cityContainer">
                <div className="row ">
                  <Slider {...settings3} >
                    {primecity?.map((item, id) =>
                      <div className="col-md-4 col-sm-6 col-12 mt-4">
                        <button className="bg-none border-none w-100" onClick={() => primecitySearch(item)}><div className="singleCityContainer">
                          <img src={item.image_url === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/Rectangle_118.png` : `${item.image_url}`} className='w-100 ' style={{height:"22vh"}} alt="" />
                          <div className="overlayPrimeCities">
                            <p className='white00 font-20  font-bold'>{item.city} <span className='font-14 font-regular'>{item.description}</span></p>
                          </div>
                        </div>
                        </button>
                      </div>
                    )}</Slider>

                </div>
              </div>

              <div className="cityContainerTab">
                <Slider {...settings2} className="homepageSlider">
                  {primecity?.map((item, id) =>
                    <div className='w-100 pe-sm-3'  >
                      <div className="col-md-4 col-sm-6 col-12 mt-4 ">
                        <button className="bg-none border-none w-100" onClick={() => primecitySearch(item)}><div className="singleCityContainer">
                          <img src={item.image_url === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/Rectangle_118.png` : `${item.image_url}`} className='w-100' style={{height:"30vh"}} alt="" />
                          <div className="overlayPrimeCities">
                            <p className='white00 font-bold'>{item.city} <span className='font-12 font-regular'>{item.description}</span></p>
                          </div>
                        </div> </button>
                      </div>
                    </div>)}
                </Slider>
              </div>
            </div>
            <div className="row mt-5 pt-5">
              <div className="col-12 text-center">
                {featuredproperty.length !== 0 && <h2 className='font-thin'> Recent <span className='font-bold'>Properties</span></h2>}
              </div>
              <div className="featuredPropertyContainer">
                <div className="row">

                  <Slider {...settings} className="homepageSlider">
                    {featuredproperty?.map((item, id) =>
                      <div className='w-100 px-sm-1'>
                        <div className="card-shadow">
                          <ProductCard
                            path={item.cover_image_url === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/Rectangle_118.png` : `${item.cover_image_url}`}
                            listdata={listdata[id]} heart="none" cross="none" unfavourite="none" daysLeft="none" onlyPrice="block" />
                        </div>
                      </div>
                    )}
                  </Slider>

                </div>
              </div>
            </div>
            <div className="row mt-5 pt-5">
              <div className="col-12 text-center">
                <h2 className='font-thin'>How we <span className='font-bold'>Work?</span></h2>
              </div>
              <div className="weWorkContainer fill-white25 p-md-5 p-3 mt-4" >
                <h2 className='black00 font-regular'>For Landlords</h2>

                <p className='black75 font-regular pt-2 text-justify'>Effortlessly List Your Properties and Connect with Potential Tenants with Urbanesting. Our intuitive platform makes it easy to create professional listings that showcase your property's unique features, including smart home and energy-efficient amenities. We simplify your rental process.</p>
                <Link to={user?.userid !== undefined ? "/list-property" : '/login'} className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>List a property</Link>
              </div>

              <div className="weWorkContainer fill-white25 p-md-5 p-3 mt-4" >
                <h2 className='black00 font-regular'>For Tenants</h2>

                <p className='black75 font-regular pt-2 text-justify'>Discover Smart Home and Energy-Efficient Rentals with Urbanesting. Customize your search with our smart home and energy-efficient amenity filter options, finding rentals that align with your sustainability values and offer modern, tech-savvy features. Find your perfect rental and connect with property listers in a few clicks.</p>
                <Link to="/search" className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end'>Find a property</Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Oops !!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p className='textJustify'>
            Sorry, we couldn't find any properties that match your search. Don't give up just yet! Try adjusting your filters or expanding your search area to find the urban nest you're looking for. Our listings are constantly updating.
          </p>
        </Modal.Body>
        <Modal.Footer>
          <button className='removeLinkDefaults fill-green00 border-none white00 px-5 py-2 float-end' onClick={handleClose}>Okay</button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default Home