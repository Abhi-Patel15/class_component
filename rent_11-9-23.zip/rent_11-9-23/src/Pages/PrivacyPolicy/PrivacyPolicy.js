import { React, useEffect, useState } from 'react'
import '../../Common/common.css'
import { APIRequest, GET_STATICPAGE } from '../../api'
import parse from 'html-react-parser'; 
import Loading from '../../Components/Loading/Loading';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';
import { useNavigate } from 'react-router-dom';


export default function PrivacyPolicy() {
  const [contenet, Setcontenet] = useState('');
  const navigate = useNavigate()

  useEffect(() => {
      new APIRequest.Builder()
          .post()
          .setReqId(GET_STATICPAGE)
          .jsonParams({
              "pagecode": "privacy_policy",
              "isactive": "Y"
          })
          .reqURL("master/getstaticpages")
          .response(onResponse)
          .error(onError)
          .build()
          .doRequest();
  }, [])

  const onResponse = (response, reqId) => {
      switch (reqId) {
          case GET_STATICPAGE:
              Setcontenet(response?.data?.data[0]?.content)
             break;
          default:
              break;
      }
  }
  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
        navigate('/not')
      }
      switch (reqId) {
          case GET_STATICPAGE:
              console.log(response?.data?.data)
              break;
          default:
              break;
      }
  }
  return (
     <>
  
     <div className="container marginMain main">
     <h3 className='text-center'>Privacy Policy</h3>
      {contenet===""?<Loading/>:parse(contenet)}    
     </div>
    
     </>
  )
}
