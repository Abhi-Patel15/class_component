import React from 'react'
import './Loading.css'
import '../../Common/common.css';

export default function Loading() {
  return (
    <div className='loadingContainer'>
        <img src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/loading-gif.gif`} className='loadingGIf'></img><br />
        <p className='font-20 loadingText font-bold'>Loading ...</p>
    </div>
  )
}
