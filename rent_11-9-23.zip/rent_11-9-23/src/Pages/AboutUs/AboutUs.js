import { React, useEffect, useState } from "react";
import "./AboutUs.css";
import "../../Common/common.css";
import { APIRequest, GET_STATICPAGE } from "../../api";
import parse from "html-react-parser";
import Loading from "../../Components/Loading/Loading";
import { STATE_CODE404, STATE_ERROR500 } from "../../Common/AddressToken";
import { useNavigate } from "react-router-dom";

export default function AboutUs() {
  const [contenet, Setcontenet] = useState([]);
  const navigate = useNavigate()

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(GET_STATICPAGE)
      .jsonParams({
        pagecode: "about_us",
        isactive: "Y",
      })
      .reqURL("master/getcommentby")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, []);

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case GET_STATICPAGE:
        Setcontenet(response?.data.data);
        break;
      default:
        break;
    }
  };
  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case GET_STATICPAGE:
        console.log(response?.data?.data);
        break;
      default:
        break;
    }
  };

  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const testimonials = [
    {
      id: 1,
      image: `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/testimonial2.jpg`,
      name: "Frencis Underwood",
      city: "New york city, USA",
      description:
        "dipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempusdipiscing elit.",
    },
    {
      id: 2,
      image: `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/testimonial3.jpg`,
      name: "Alvaro Morte",
      city: "Medrid, Spain",
      description:
        " ac aliquet dipiscing elit. Nunc vulputate libero et velit interdum, odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus",
    },
    {
      id: 3,
      image: `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/tesimonial-user.png`,
      name: "Andres Fonniosa",
      city: "Tokyo, Japan",
      description:
        "Class aptent taciti sociosq dipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. u ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tempus",
    },
  ];

  const handleTestimonialPrev = () => {
    setCurrentTestimonial(currentTestimonial - 1);
    if (currentTestimonial <= 0) {
      setCurrentTestimonial(contenet.length - 1);
    }
  };

  const handleTestimonialNext = () => {
    setCurrentTestimonial(currentTestimonial + 1);
    if (currentTestimonial >= contenet.length - 1) {
      setCurrentTestimonial(0);
    }
  };

  return (
    <>
      <div className="main">
        <div className="AboutUsContainer">
          <div className="container-fluid">
            {/* {contenet==="" ? <Loading/>:parse(contenet)}  */}
            {/* <div>
                    <div className="container-fluid">
                        <div className="about-main-bg">
                            <h1>About Us</h1>
                        </div>
                        <div className="container">
                            <div className="row">
                                <div className="col-md-2"></div>
                                <div className="col-md-8">
                                    <div className="about-text text-center mt-5">
                                        <p>Welcome to Urbanesting, your trusted online real estate platform for finding the perfect place to call home. We are passionate about connecting renters with quality properties and empowering landlords to reach their target audience. With our innovative features and user-friendly interface, we aim to revolutionize the way people search for rental properties.</p>
                                        <div className="mt-5">
                                            <img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" />
                                            <h4 className="mb-3">Our Mission</h4>
                                            <p>At Urbanesting, our mission is to simplify the rental process by providing a seamless and transparent experience for both tenants and property owners. We believe that finding a new home should be an exciting journey, not a stressful task. Our dedicated team is committed to delivering a platform that offers comprehensive property listings, robust search filters, and valuable tools to enhance the entire rental experience.</p>
                                        </div>
                                        <div className="mt-5">
                                            <img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" />
                                            <h4 className="mb-3">Our Story</h4>
                                            <p>Urbanesting was born out of a shared frustration with the outdated and cumbersome rental processes. As renters ourselves, we understand the challenges and pain points involved in finding a suitable place to live. We saw an opportunity to leverage technology and create a platform that streamlines the search process, saves time, and ensures trust and reliability in every transaction.</p>
                                        </div>
                                        <div className="mt-5">
                                            <img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" />
                                            <h4 className="mb-3">Our Values</h4>
                                            <p><b>Integrity:</b> We prioritize honesty, transparency, and fairness in all our interactions. We believe in building trust with our users and maintaining the highest ethical standards.</p>
                                            <p><b>Innovation:</b> We constantly strive to innovate and improve our platform, staying ahead of the curve in the rapidly evolving real estate industry. We embrace new technologies to deliver a cutting-edge user experience.</p>
                                            <p><b>User-Centric Approach:</b> We put our users at the center of everything we do. We listen to their feedback, understand their needs, and continuously enhance our platform to exceed their expectations.</p>
                                            <p><b>Community Engagement:</b> We believe in fostering a vibrant community of renters, landlords, and real estate professionals. We encourage collaboration, networking, and knowledge sharing to create a supportive ecosystem.</p>
                                        </div>
                                        <div className="mt-5">
                                            <img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" />
                                            <h4 className="mb-3">How We Serve You</h4>
                                            <p><b>Comprehensive Property Listings:</b>  Our platform offers an extensive database of verified rental properties, ranging from apartments and houses to condos and townhomes. We ensure that each listing provides accurate information, high-quality photos, and virtual tours whenever possible.</p>
                                            <p><b>Advanced Search Filters:</b> We provide robust search filters that allow users to refine their search based on location, price range, property type, amenities, and more. In addition, we offer eco-friendly and energy-efficient related search filters, allowing you to prioritize properties that align with your sustainability values. Filter by eco-friendly features such as energy-efficient appliances, solar panels, smart technologies, and more, to find homes that contribute to a greener lifestyle.</p>
                                            <p><b>Verified Listings:</b> We have implemented a rigorous verification process to ensure that all property listings on our platform are accurate and trustworthy. Our partnership with property owners, agents, and our own verification procedures offer peace of mind to users.</p>
                                            <p><b>Interactive Map View:</b> Our interactive map view feature allows you to explore rental properties visually. Easily navigate through different neighborhoods, view property locations, and access essential information within a geographical context. This helps you gain a better understanding of the area and make informed decisions about where to rent.</p>
                                        </div>
                                        <div className="mt-5">
                                            <img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" />
                                            <h4 className="mb-3">Join the Urbanesting Community</h4>
                                            <p>We invite you to join our community of renters and property owners who value convenience, reliability, and exceptional service. Whether you are looking for your next home or seeking tenants for your property, Urbanesting is here to simplify the rental process and make your experience enjoyable.</p>
                                            <p>Discover your urban nest today!</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-2"></div>
                            </div>
                            
                        </div>
                    </div>
                            </div> */}
            <div className="about-main-bg mb-3">
                <h1>About Us</h1>
            </div>
            <div className="data container">             
            <div className="about-us-container">
              <div className="card">
                <h2 className="card-title">Welcome to Urbanesting</h2>
                <p className="card-content">
                  Your trusted online real estate platform for finding the
                  perfect place to call home. We are passionate about connecting
                  renters with quality properties and empowering landlords to
                  reach their target audience. With our innovative features and
                  user-friendly interface, we aim to revolutionize the way
                  people search for rental properties.
                </p>
              </div>
              <div className="card"><img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" /></div>
              <div className="card">
                <h4 className="sub-heading">Our Mission</h4>
                <p className="card-content">
                  At Urbanesting, our mission is to simplify the rental process
                  by providing a seamless and transparent experience for both
                  tenants and property owners. We believe that finding a new
                  home should be an exciting journey, not a stressful task. Our
                  dedicated team is committed to delivering a platform that
                  offers comprehensive property listings, robust search filters,
                  and valuable tools to enhance the entire rental experience.
                </p>
              </div>
              <div className="card"><img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" /></div>
              <div className="card">
                <h4 className="sub-heading">Our Story</h4>
                <p className="card-content">
                  Urbanesting was born out of a shared frustration with the
                  outdated and cumbersome rental processes. As renters
                  ourselves, we understand the challenges and pain points
                  involved in finding a suitable place to live. We saw an
                  opportunity to leverage technology and create a platform that
                  streamlines the search process, saves time, and ensures trust
                  and reliability in every transaction.
                </p>
              </div>
              <div className="card"><img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" /></div>
              <div className="card">
                <h4 className="sub-heading">Our Values</h4>
                <div className="value-card">
                  <h4 className="value-card-title">Integrity</h4>
                  <p className="value-card-content">
                    We prioritize honesty, transparency, and fairness in all our
                    interactions. We believe in building trust with our users
                    and maintaining the highest ethical standards.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="value-card-title">Innovation</h4>
                  <p className="value-card-content">
                    We constantly strive to innovate and improve our platform,
                    staying ahead of the curve in the rapidly evolving real
                    estate industry. We embrace new technologies to deliver a
                    cutting-edge user experience.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="value-card-title">User-Centric Approach</h4>
                  <p className="value-card-content">
                    We put our users at the center of everything we do. We
                    listen to their feedback, understand their needs, and
                    continuously enhance our platform to exceed their
                    expectations.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="value-card-title">Community Engagement</h4>
                  <p className="value-card-content">
                    We believe in fostering a vibrant community of renters,
                    landlords, and real estate professionals. We encourage
                    collaboration, networking, and knowledge sharing to create a
                    supportive ecosystem.
                  </p>
                </div>
              </div>
              <div className="card"><img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" /></div>
              <div className="card">
                <h4 className="sub-heading">How We Serve You</h4>
                <div className="value-card">
                  <h4 className="service-card-title">
                    Comprehensive Property Listings
                  </h4>
                  <p className="service-card-content">
                    Our platform offers an extensive database of verified rental
                    properties, ranging from apartments and houses to condos and
                    townhomes. We ensure that each listing provides accurate
                    information, high-quality photos, and virtual tours whenever
                    possible.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="service-card-title">
                    Advanced Search Filters
                  </h4>
                  <p className="service-card-content">
                    We provide robust search filters that allow users to refine
                    their search based on location, price range, property type,
                    amenities, and more. In addition, we offer eco-friendly and
                    energy-efficient related search filters, allowing you to
                    prioritize properties that align with your sustainability
                    values. Filter by eco-friendly features such as
                    energy-efficient appliances, solar panels, smart
                    technologies, and more, to find homes that contribute to a
                    greener lifestyle.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="service-card-title">Verified Listings</h4>
                  <p className="service-card-content">
                    We have implemented a rigorous verification process to
                    ensure that all property listings on our platform are
                    accurate and trustworthy. Our partnership with property
                    owners, agents, and our own verification procedures offer
                    peace of mind to users.
                  </p>
                </div>

                <div className="value-card">
                  <h4 className="service-card-title">Interactive Map View</h4>
                  <p className="service-card-content">
                    Our interactive map view feature allows you to explore
                    rental properties visually. Easily navigate through
                    different neighborhoods, view property locations, and access
                    essential information within a geographical context. This
                    helps you gain a better understanding of the area and make
                    informed decisions about where to rent.
                  </p>
                </div>
              </div>
              <div className="card"><img src="https://hoch-rent.s3.amazonaws.com/heroImg.JPEG" className="img-fluid mb-4" /></div>
              <h4 className="join-community">Join the Urbanesting Community</h4>
              <p className="card-content">
                We invite you to join our community of renters and property
                owners who value convenience, reliability, and exceptional
                service. Whether you are looking for your next home or seeking
                tenants for your property, Urbanesting is here to simplify the
                rental process and make your experience enjoyable.
              </p>

              <p className="discover-nest">Discover your urban nest today!</p>
            </div>
            </div>
            <div className="container">
              <div className="row mt-5 pt-2">
                <div className="col-lg-3 col-md-6 col-sm-6 col-12 mb-2 ">
                  <div className="features pt-3 ps-3">
                    <img
                      src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/compare2.png`}
                      className="mb-2"
                      alt=""
                    />
                    <br />
                    <b className="green00 featureHeading ">
                      Compare properties
                    </b>
                    <label className="featurePera1 black75">
                      Select Properties and compare them to find best for you.
                    </label>
                  </div>
                </div>
                <div className="col-lg-3 col-md-6 col-sm-6 col-12 mb-2 ">
                  <div className="features pt-3 ps-3">
                    <img
                      src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/tour.png`}
                      className="mb-2"
                      alt=""
                    />
                    <br />
                    <b className="green00 featureHeading ">Request a tour</b>
                    <label className="featurePera1 black75">
                      You can contact the landlord withinfew clicks.
                    </label>
                  </div>
                </div>
                <div className="col-lg-3 col-md-6 col-sm-6 col-12 mb-2 ">
                  <div className="features pt-3 ps-3">
                    <img
                      src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/seamless.png`}
                      className="mb-2"
                      alt=""
                    />
                    <br />
                    <b className="green00 featureHeading ">
                      Seamless property search
                    </b>
                    <label className="featurePera1 black75">
                      With over 20k property listed here you can find one for
                      without hustle.
                    </label>
                  </div>
                </div>
                <div className="col-lg-3 col-md-6 col-sm-6 col-12 mb-2 ">
                  <div className="features pt-3 ps-3">
                    <img
                      src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/best.png`}
                      className="mb-2"
                      alt=""
                    />
                    <br />
                    <b className="green00 featureHeading ">Best in business</b>
                    <label className="featurePera1 black75">
                      we’ve the heighest success ration in this business.
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="row mt-5 text-center">
              <div className="testimonial_container hide show">
                <div className="testimonialImgContainer mt-4  ">
                  <img
                    src={contenet[currentTestimonial]?.imageurl}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <p className="green00 reviewerName font-semibold">
                  {contenet[currentTestimonial]?.personname}
                </p>
                <label
                  htmlFor=""
                  className="green00 reviewerLocation font-regular"
                >
                  {contenet[currentTestimonial]?.address}
                </label>
                <p className="review black75">
                  {contenet[currentTestimonial]?.description}{" "}
                </p>
              </div>
            </div>
            <div className="row text-center d-felx">
              <div className="btnAboutUSContainer">
                <button
                  className="fill-green00 prevNextBtn"
                  onClick={handleTestimonialPrev}
                >
                  &lt;
                </button>
                <button
                  className="fill-green00 prevNextBtn"
                  onClick={handleTestimonialNext}
                >
                  &gt;
                </button>
              </div>
            </div>
            {/* {contenet.length>0 && contenet.map((item)=>(
            <div className="row mt-5 text-center">
              <div className="testimonial_container hide show">
                <div className="testimonialImgContainer mt-4  ">
                  <img
                    src={item.imageurl}
                    className="img-fluid"
                    alt=""
                  />
                </div>
                <p className="green00 reviewerName font-semibold">
                  {item.personname}
                </p>
                <label
                  htmlFor=""
                  className="green00 reviewerLocation font-regular"
                >
                  {item.address}
                </label>
                <p className="review black75">
                  {item.description}{" "}
                </p>
              </div>
            </div>))} */}
            <div className="container text-center">
              <div className="row numbersContainer fill-green00 px-sm-5">
                <div className="col-lg-3 col-sm-6 col-12 singleNumber-container white00 border-sm-0  border-bottom ">
                  <h4 className="mt-3">50000+</h4>
                  <p>Landlords partner</p>
                </div>

                <div className="col-lg-3 col-sm-6 col-12 singleNumber-container white00 border-sm-0 border-bottom ">
                  <h4 className="mt-3">85000+</h4>
                  <p>Happy renters living peacefully</p>
                </div>

                <div className="col-lg-3 col-sm-6 col-12 singleNumber-container white00 border-sm-0 border-bottom ">
                  <h4 className="mt-3">78+</h4>
                  <p>Cities across nation</p>
                </div>

                <div className="col-lg-3 col-sm-6 col-12 singleNumber-container white00 border-sm-0  border-bottom ">
                  <h4 className="mt-3">5845+</h4>
                  <p>Issue solved</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
