document.addEventListener('DOMContentLoaded', async () => {
    // Load the publishable key from the server. The publishable key
    // is set in your .env file.
    const publishableKey = "pk_test_51M2qopSFtaxZehQTQClyCqrqfGi3X3tEe95hMWdsuaJcj0m4pwLEzkAyCykDg50ZYOT8JkRQ0LkgZs5QdyEl18ws00BL85qXxs";//await fetch('/config').then((r) => r.json());
    if (!publishableKey) {
      addMessage(
        'No publishable key returned from the server. Please check `.env` and try again'
      );
      alert('Please set your Stripe publishable API key in the .env file');
    }
  
    const stripe = Stripe(publishableKey, {
      apiVersion: '2020-08-27',
    });
  
    // On page load, we create a PaymentIntent on the server so that we have its clientSecret to
    // initialize the instance of Elements below. The PaymentIntent settings configure which payment
    // method types to display in the PaymentElement.
    clientSecret = "pi_3M3kALSFtaxZehQT12H9dzOc_secret_P6zEj8iVtY2SMwb6wd1VIbx6L";
  
    // Initialize Stripe Elements with the PaymentIntent's clientSecret,
    // then mount the payment element.
    const elements = stripe.elements({ clientSecret });
    const paymentElement = elements.create('payment');
    paymentElement.mount('#payment-element');
  
    // When the form is submitted...
    const form = document.getElementById('payment-form');
    let submitted = false;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
  
      // Disable double submission of the form
      if (submitted) { return; }
      submitted = true;
      form.querySelector('button').disabled = true;
  
      const nameInput = document.querySelector('#name');
  
      // Confirm the card payment given the clientSecret
      // from the payment intent that was just created on
      // the server.
      const { error: stripeError } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/strip/return.html`,
        }
      });
  
      if (stripeError) {
        addMessage(stripeError.message);
  
        // reenable the form.
        submitted = false;
        form.querySelector('button').disabled = false;
        return;
      }
    });
  });
  