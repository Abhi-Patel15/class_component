import { SET_USER, SET_TOKEN, LIST_PROPERTY1, LIST_PROPERTY2, LIST_PROPERTY3, COMPARE_PROPERTY, SEARCH_PROPERTY ,STATE_CITY, COMPARE_PROPERTY_DELETE } from "./action-types";
import { REHYDRATE } from "redux-persist/lib/constants";

let initial = {
  user: null,
  token: null,
  property1: null,
  property2: null,
  property3: null,
  compareproperty: null,
  searchproperty: null,
  statecity:null
};

const reducer = (state = initial, action) => {
  switch (action.type) {
    case SET_USER:
      return Object.assign({}, state, { user: action.user });
    case SET_TOKEN:
      return Object.assign({}, state, { token: action.token });
    case LIST_PROPERTY1:
      return Object.assign({}, state, { property1: action.property1 });
    case LIST_PROPERTY2:
      return  Object.assign({}, state, { property2: action.property2 });
    case LIST_PROPERTY3:
      return Object.assign({}, state, { property3: action.property3 });
    case COMPARE_PROPERTY:
      return Object.assign({}, state, { compareproperty: action.compareproperty });
    case SEARCH_PROPERTY:
      return Object.assign({}, state, { searchproperty: action.searchproperty });
    case STATE_CITY:
        return Object.assign({}, state, { statecity: action.statecity });
    case REHYDRATE:
      return { ...state, ...action.payload };
    default:
      return state;
  }
};

export default reducer;
