import React, { useEffect, useState } from 'react'
import './Signup.css';
import { Link } from 'react-router-dom';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import { useFormik } from "formik";
import * as Yup from "yup"
import { useNavigate } from 'react-router-dom';
import { APIRequest, SIGNUP, SIGNUP_SOCIAL, GUEST_LOGIN, HOMEPAGE_SLIDER } from '../../api';
import toast from 'react-simple-toasts';
import { AiFillEyeInvisible, AiFillEye } from 'react-icons/ai'
import Loading from '../../Components/Loading/Loading';
import GoogleLogin from 'react-google-login';
import { gapi } from 'gapi-script';
import { useSelector, useDispatch } from 'react-redux'
import { setToken, setUser } from "../../redux/action";
import {AiOutlineHome} from 'react-icons/ai'
import swal from 'sweetalert';


export default function Signup() {

    const dispatch = useDispatch();
    const [homepage, Sethomepage] = useState();

    useEffect(() => {
        const initClient = () => {
            gapi.client.init({
                clientId: process.env.REACT_APP_GOOGLE_CLIENT_ID,
                scope: ''
            });
        };
        gapi.load('client:auth2', initClient);

        new APIRequest.Builder()
            .post()
            .setReqId(GUEST_LOGIN)
            .jsonParams({
                "emailid": "guest@rent.com",
                "password": "Guest@123"
            })
            .reqURL("user/signin")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();

        new APIRequest.Builder()
            .post()
            .setReqId(HOMEPAGE_SLIDER)
            .jsonParams({
                "pagename": "SINGUP"
            })
            .reqURL("master/gethomepagemaster")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
    }, []);

    const onSuccess = (res) => {

        new APIRequest.Builder()
            .post()
            .setReqId(SIGNUP_SOCIAL)
            .jsonParams({
                firstname: res.profileObj.givenName,
                lastname: res.profileObj.familyName,
                emailid: res.profileObj.email,
                usertype: "USER",
                loginplatform: "google"
            })
            .reqURL("user/signup_social")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();

    };
    const onFailure = (err) => {
        toast("Sign Up was not successful. Please try again or contact support for assistance.");
    };


    const navigate = useNavigate()

    const [passlength, SetPasslength] = useState(false)
    const [passnum, SetPassnum] = useState(false)
    const [passuppar, SetPassuppar] = useState(false)
    const [passlower, SetPasslower] = useState(false)
    const [passchar, SetPasschar] = useState(false)
    const [loading, Setloading] = useState(false)


    const popover = (
        <Popover id="popover-basic" placement='bottom-end'>
            <Popover.Body>
                <p className={passlength ? "green00" : "colorRed"}>Minimum 8 Characters</p>
                <p className={passuppar ? "green00" : "colorRed"}>At least contain one upper case letter [A-Z]</p>
                <p className={passlower ? "green00" : "colorRed"}>At least contain one lower case letter [a-z]</p>
                <p className={passnum ? "green00" : "colorRed"}>At least contain one number[0-9]</p>
                <p className={passchar ? "green00" : "colorRed"}>At least contain one special symbol [!@#$%^&*()]</p>
            </Popover.Body>
        </Popover>
    );

    const signup = useFormik({
        initialValues: {
            firstname: "",
            lastname: "",
            emailid: "",
            password: "",
            passwordconfirm: "",
            checked: false
        }
        , validationSchema: Yup.object().shape({
            firstname: Yup.string().required(" Enter First Name").min(3, "Enter Minimum 3 Character"),
            lastname: Yup.string().required(" Enter Last Name"),
            emailid: Yup.string().email('Please enter valid email').required(" Enter Email"),
            password: Yup.string().required('Enter Password').matches(
                /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
            ),
            passwordconfirm: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required(" Enter Confirm Password"),
            checked: Yup.boolean().oneOf([true], 'You must accept the "Terms of Service" and "Privacy Policy" to proceed')
        }), onSubmit: (values) => {
            Setloading(true)
            delete values.passwordconfirm;
            delete values.checked;

            new APIRequest.Builder()
                .post()
                .setReqId(SIGNUP)
                .jsonParams(values)
                .reqURL("user/signup")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    })
    const onResponse = (response, reqId) => {
        switch (reqId) {
            case SIGNUP:
                if (response.data.issuccess) {
                    // toast("Thank you for joining us at Urbanesting! We've just sent a verification email to your registered email address. Please take a moment to check your inbox and complete the verification process. In case you can't find the email, kindly take a look in your spam folder. We are excited to have you onboard!")
                    swal({
                        text:"Thank you for joining us at Urbanesting! We've just sent a verification email to your registered email address. Please take a moment to check your inbox and complete the verification process. In case you can't find the email, kindly take a look in your spam folder. We are excited to have you onboard!",
                    });
                    navigate("/login");
                 
                    Setloading(false)
                } else {
                    toast(`${response.data.massage}`)
                    Setloading(false)
                }
                break;
            case SIGNUP_SOCIAL:
                if (response.data.issuccess) {
                    toast("Signup Sucessfully");
                    navigate("/");
                    dispatch(setUser(response.data.data))
                    Setloading(false)
                }else {
                    toast(`${response.data.massage}`)
                    Setloading(false)
                }
                break;
            case GUEST_LOGIN:
                if (response.data.data?.accessToken) {
                    dispatch(setToken(response.data.data.accessToken))
                }
                break;
            case HOMEPAGE_SLIDER:
                Sethomepage(response.data.data[0]);
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        switch (reqId) {
            case SIGNUP:
                Setloading(false)
                break;
            case SIGNUP_SOCIAL:
                toast(`${response.data.massage}`)
                break;
            case GUEST_LOGIN:
                toast(`${response.data.massage}`)
                break;
            case HOMEPAGE_SLIDER:
                console.log(response.data.data[0]);
                break;
            default:
                break;
        }
    }
    
    useEffect(() => {

        if (signup?.values.password === "") {
            SetPasschar(false)
            SetPasslength(false)
            SetPasslower(false)
            SetPassuppar(false)
            SetPassnum(false)
        }

        var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        var letterNumber = /[0-9]+/;
        var letterUpper = /[A-Z]+/;
        var letterlower = /[a-z]+/;


        var strings = signup?.values.password ?? "";
        var i = 0;
        var character = '';
        while (i <= strings.length) {
            character = strings.charAt(i);
            if (letterNumber.test(character) && !passnum) {
                SetPassnum(true)
            } if (letterUpper.test(character) && !passuppar) {
                SetPassuppar(true)
            }
            if (letterlower.test(character) && !passlower) {
                SetPasslower(true)
            }
            if (format.test(character) && !passchar) {
                SetPasschar(true)
            }
            if (i >= 8 && !passlength) {
                SetPasslength(true)
            }
            i++;
        }

    }, [signup?.values?.password])

    const [signupShow, setsignupShow] = useState(false);
    const handleLoginPassShow = () => {
        if (signupShow === true) {
            setsignupShow(false)
        }
        else {
            setsignupShow(true)
        }
    }
    const [signupShow2, setsignupShow2] = useState(false);
    const handleLoginPassShow2 = () => {
        if (signupShow2 === true) {
            setsignupShow2(false)
        }
        else {
            setsignupShow2(true)
        }
    }

    return (
        <>
            {loading && <Loading />}
            <div className="container-fluid">
                <div className="row">
                    <div className="d-none d-md-block col-md-6 p-0 order-md-1 order-2">
                        <div className="login_image_container m-0 p-0">
                            <img src={homepage?.imageurl === "" ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/HomeMain.png` : `${homepage?.imageurl}`} className='loginImg ' alt="" />
                        </div>
                    </div>
                    <div className="col-md-6 p-0 order-md-2 order-1">
                        <div className="signup_form_container pt-2">
                        <Link to="/" className='removeLinkDefaults text-white ms-4 mt-2 font-20'><AiOutlineHome/></Link>
                            <form onSubmit={signup.handleSubmit}>
                                <h1 className='pt-0'><span className='font-semibold'>Create</span> Account</h1>
                                <div>
                                    <div className='inputGroup'>
                                        <label className='label-ph mb-1' htmlFor="firstname">First Name*</label><br />
                                        <input className='input-light' type="text"
                                            name='firstname'
                                            id='firstname'
                                            onChange={signup.handleChange}
                                            value={signup.values.firstname} />
                                        {signup.touched.firstname && signup.errors.firstname ? (
                                            <span className="error">{signup.errors.firstname}</span>
                                        ) : null}
                                    </div>
                                    <div className='inputGroup'>

                                        <label className='label-ph mb-1' htmlFor="lastname">Last Name*</label><br />
                                        <input className='input-light' type="text"
                                            name='lastname'
                                            id='lastname'
                                            onChange={signup.handleChange}
                                            value={signup.values.lastname} />
                                        {signup.touched.lastname && signup.errors.lastname ? (
                                            <span className="error">{signup.errors.lastname}</span>
                                        ) : null}
                                    </div>
                                    <div className='inputGroup'>
                                        <label className='label-ph mb-1' htmlFor="emailid">Email*</label><br />
                                        <input className='input-light' type="emailid"
                                            name='emailid'
                                            id='emailid'
                                            onChange={signup.handleChange}
                                            value={signup.values.emailid} />
                                        {signup.touched.emailid && signup.errors.emailid ? (
                                            <span className="error">{signup.errors.emailid}</span>
                                        ) : null}
                                    </div>
                                    <div className='inputGroup passwordContainer'>
                                        <label className='label-ph mb-1' htmlFor="password"
                                        >Password*</label><br />
                                        <OverlayTrigger trigger="focus" placement="bottom" overlay={popover}>
                                            <input className='input-password' type={signupShow === true ? "text" : "password"}
                                                name='password'
                                                id='password'
                                                onChange={signup.handleChange}
                                                value={signup.values.password} />
                                        </OverlayTrigger>

                                        <button type="button" className='bg-none border-none eyeIcon mt-1' onClick={handleLoginPassShow}>{signupShow === true ? <AiFillEyeInvisible /> : <AiFillEye />}</button>
                                        {signup.touched.password && signup.errors.password ? (
                                            <span className="error">{signup.errors.password}</span>
                                        ) : null}
                                    </div>
                                    <div className='inputGroup passwordContainer'>
                                        <label className='label-ph mb-1' htmlFor="">Confirm Password*</label><br />
                                        <input className='input-password' type={signupShow2 === true ? "text" : "password"}
                                            name='passwordconfirm'
                                            id='passwordconfirm'
                                            onChange={signup.handleChange}
                                            value={signup.values.passwordconfirm} />
                                        <button type="button" className='bg-none border-none eyeIcon mt-1' onClick={handleLoginPassShow2}>{signupShow2 === true ? <AiFillEyeInvisible /> : <AiFillEye />}</button>
                                        {signup.touched.passwordconfirm && signup.errors.passwordconfirm ? (
                                            <span className="error">{signup.errors.passwordconfirm}</span>
                                        ) : null}
                                    </div>
                                    <div className="tandc d-flex mb-1">
                                        <input type="checkbox" className='checkbox_login' name="checked" id="checked"
                                            onChange={signup.handleChange}
                                            value={signup.values.checked} />
                                        <label className='smallTextLabel' htmlFor=""> I have read and accept the <Link to="/terms-and-conditions" className='white00 me-1'>Terms of Service</Link>
                                            and <Link to="/privacy-policy" className='white00'>Privacy Policy </Link>

                                            <br />
                                            {signup.touched.checked && signup.errors.checked ? (
                                                <span className="error">{signup.errors.checked}</span>
                                            ) : null}
                                        </label>
                                    </div>
                                </div>
                                <div className='group3'>
                                    <button type="primary" className='loginBTN'>
                                        {/* <Link className='loginBTN  removeLinkDefaults' to="/login"> */}
                                        Register
                                        {/* </Link> */}
                                    </button><br />
                                    <label className='orLabel'>or</label><br />
                                    {/* <button type="primary" className='googleBTN whiteHover'>Register with Google</button><br /> */}
                                    <GoogleLogin
                                        className='googleBTN whiteHover py-4'
                                        clientId="580361282331-dqakjgucapkbvb9r7c9u4q54vc63g71k.apps.googleusercontent.com"
                                        buttonText="Register with google"
                                        onSuccess={onSuccess}
                                        onFailure={onFailure}
                                        cookiePolicy={'single_host_origin'}
                                        isSignedIn={false}
                                    ></GoogleLogin>
                                    <p className='loginPera mb-0'>Already have an account? <Link className='loginLink white00' to="/login">Login Here</Link></p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
