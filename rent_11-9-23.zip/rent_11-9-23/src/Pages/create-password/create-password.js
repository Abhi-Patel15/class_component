import React from 'react'
import { Button, Toast } from 'react-bootstrap';
import './createstyle.css'
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import { UPDATE_PASSWORD, APIRequest } from '../../api';
import { useSelector, useDispatch } from 'react-redux'
import * as Yup from "yup"
import { setToken, setUser } from "../../redux/action";
import toast from 'react-simple-toasts';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import { useState } from 'react';
import { useEffect } from 'react';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';

export default function CreatePassword() {
    const [passlength, SetPasslength] = useState(false)
    const [passnum, SetPassnum] = useState(false)
    const [passuppar, SetPassuppar] = useState(false)
    const [passlower, SetPasslower] = useState(false)
    const [passchar, SetPasschar] = useState(false)


    const popover = (
        <Popover id="popover-basic" placement='bottom-end'>
            <Popover.Body>
                <p className={passlength ? "green00" : "colorRed"}>Minimum 8 Characters</p>
                <p className={passuppar ? "green00" : "colorRed"}>At least contain one upper case letter [A-Z]</p>
                <p className={passlower ? "green00" : "colorRed"}>At least contain one lower case letter [a-z]</p>
                <p className={passnum ? "green00" : "colorRed"}>At least contain one number[0-9]</p>
                <p className={passchar ? "green00" : "colorRed"}>At least contain one special symbol [!@#$%^&*()]</p>
            </Popover.Body>
        </Popover>
    );


    const user = useSelector((state) => state.user)

    const dispatch = useDispatch()
    const navigate = useNavigate();

    const login = useFormik({
        enableReinitialize:true,
        initialValues: {
            userid: user?.userid,
            emailid: user?.emailid,
            password: "",
            passwordconfirm: ""
        },
        validationSchema: Yup.object().shape({
            password:Yup.string().required('Enter Password').matches(
                /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
            ),
            passwordconfirm:Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required(" Enter Confirm Password")
  
        }),

        onSubmit: values => {
            delete values.passwordconfirm
               new APIRequest.Builder()
                .post()
                .setReqId(UPDATE_PASSWORD)
                .jsonParams(values)
                .reqURL("user/update_password")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    });

    useEffect(() => {
        if (login?.values.password === "") {
            SetPasschar(false)
            SetPasslength(false)
            SetPasslower(false)
            SetPassuppar(false)
            SetPassnum(false)
        }
        var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        var letterNumber = /[0-9]+/;
        var letterUpper = /[A-Z]+/;
        var letterlower = /[a-z]+/;


        var strings = login?.values.password ?? "";
        var i = 0;
        var character = '';
        while (i <= strings.length) {
            character = strings.charAt(i);
            if (letterNumber.test(character) && !passnum) {
                SetPassnum(true)
            } if (letterUpper.test(character) && !passuppar) {
                SetPassuppar(true)
            }
            if (letterlower.test(character) && !passlower) {
                SetPasslower(true)
            }
            if (format.test(character) && !passchar) {
                SetPasschar(true)
            }
            if (i >= 8 && !passlength) {
                SetPasslength(true)
            }
            i++;
        }

    }, [login?.values?.password])

    const onResponse = (response, reqId) => {
        switch (reqId) {
            case UPDATE_PASSWORD:
                if (response.data.data?.accessToken) {
                    dispatch(setToken(response.data.data.accessToken))
                    dispatch(setUser(response.data.data.userid))
                }                
                if (response.data.massage) {
                    toast(`${response.data.massage}`)                
                                     
                }
                if (response.data.issuccess) {
                    navigate("/login");
                }
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        switch (reqId) {
            case UPDATE_PASSWORD:
                console.log(response);
                break;
            default:
                break;
        }
    }
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-6 p-0 order-md-1 order-2">
                    <div className="login_image_container m-0 p-0">
                        <img src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/welcome_image.jpg`} className='loginImg ' alt="" />
                    </div>
                </div><div className="col-md-6 p-0 order-md-2 order-1">
                    <form onSubmit={login.handleSubmit}>

                        <div className="login_form_container">
                            <h1 className='mb-4'><span className='font-semibold'>Create</span> Password</h1>
                            <div className='inputGroup mb-4'>
                                <label className='label-ph' htmlFor="password">New Password</label><br />
                                <OverlayTrigger trigger="focus" placement="bottom" overlay={popover}>
                                      <input className='input-light' type="password"
                                    id='password'
                                    name='password'
                                    onChange={login.handleChange}
                                    value={login.values.password}
                                    required />
                                    </OverlayTrigger>
                                {login.touched.password && login.errors.password ? (
                                    <span className="error">{login.errors.password}</span>
                                ) : null}
                            </div>
                            <div className='inputGroup mb-4'>
                                <label className='label-ph' htmlFor="password">Confirm Password</label><br />
                                <input className='input-light' type="password"
                                    name='passwordconfirm'
                                    id='passwordconfirm'
                                    onChange={login.handleChange}
                                    value={login.values.passwordconfirm}
                                    required />
                                {login.touched.passwordconfirm && login.errors.passwordconfirm ? (
                                    <span className="error">{login.errors.passwordconfirm}</span>
                                ) : null}
                            </div>
                            <div className='group3 mt-4'>
                                <button type='submit' variant="primary" className='loginBTN'>Submit</button><br />
                            </div>

                        </div>
                    </form>
                </div>

            </div>
        </div>

    )
}
