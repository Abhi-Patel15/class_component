import { React, useState,useEffect } from 'react';
import './MyAccount.css'
import { AiOutlineEyeInvisible, AiOutlineEye } from 'react-icons/ai'
import { useFormik } from 'formik';
import * as Yup from "yup";
import { APIRequest, UPDATE_PASSWORD } from '../../api';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-simple-toasts';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';
import { logout } from '../../redux/action';


export default function ChangePassword() {
    const [passlength, SetPasslength] = useState(false)
    const [passnum, SetPassnum] = useState(false)
    const [passuppar, SetPassuppar] = useState(false)
    const [passlower, SetPasslower] = useState(false)
    const [passchar, SetPasschar] = useState(false)
    const dispatch = useDispatch()


    const popover = (
        <Popover id="popover-basic" placement='bottom-end'>
            <Popover.Body>
                <p className={passlength ? "green00" : "colorRed"}>Minimum 8 Characters</p>
                <p className={passuppar ? "green00" : "colorRed"}>At least contain one upper case letter [A-Z]</p>
                <p className={passlower ? "green00" : "colorRed"}>At least contain one lower case letter [a-z]</p>
                <p className={passnum ? "green00" : "colorRed"}>At least contain one number[0-9]</p>
                <p className={passchar ? "green00" : "colorRed"}>At least contain one special symbol [!@#$%^&*()]</p>
            </Popover.Body>
        </Popover>
    );


    const navigate = useNavigate();
    const user = useSelector((state) => state.user)

    const ChangePassword = useFormik({
        enableReinitialize: true,
        initialValues: {
            userid: user?.userid,
            emailid: user?.emailid,
           // mobileno:"",
            password: "",
            passwordconfirm: ""
        },
        validationSchema: Yup.object().shape({
            password: Yup.string().required('Enter Password').matches(
                /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
            ),
            passwordconfirm: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required(" Enter Confirm Password"),
           // mobileno:Yup.string().required("Required").length(10 ,"10 Digit Contact No. Required")

        }),

        onSubmit: values => {
            delete values.passwordconfirm
            new APIRequest.Builder()
                .post()
                .setReqId(UPDATE_PASSWORD)
                .jsonParams(values)
                .reqURL("user/update_password")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    });

    useEffect(() => {
        if (ChangePassword?.values.password === "") {
            SetPasschar(false)
            SetPasslength(false)
            SetPasslower(false)
            SetPassuppar(false)
            SetPassnum(false)
        }
        var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        var letterNumber = /[0-9]+/;
        var letterUpper = /[A-Z]+/;
        var letterlower = /[a-z]+/;


        var strings = ChangePassword?.values.password ?? "";
        var i = 0;
        var character = '';
        while (i <= strings.length) {
            character = strings.charAt(i);
            if (letterNumber.test(character) && !passnum) {
                SetPassnum(true)
            } if (letterUpper.test(character) && !passuppar) {
                SetPassuppar(true)
            }
            if (letterlower.test(character) && !passlower) {
                SetPasslower(true)
            }
            if (format.test(character) && !passchar) {
                SetPasschar(true)
            }
            if (i >= 8 && !passlength) {
                SetPasslength(true)
            }
            i++;
        }

    }, [ChangePassword?.values?.password])

    const onResponse = (response, reqId) => {
        switch (reqId) {
            case UPDATE_PASSWORD:
                if (response.data.issuccess ==null) {
                    toast(`${response.data.massage}`)
                } else {
                    toast.error("Password is not successfully updated")
                }
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        if(response.data.status==STATE_ERROR){
            localStorage.clear()
            dispatch(logout())
            navigate("/login");
          }
        switch (reqId) {
            case UPDATE_PASSWORD:
                toast("Password is not successfully updated")
                break;
            default: 
                break;
        }
    }

    const [mode, setMode] = useState('password');
    const changeMode = () => {
        if (mode === 'password') {
            setMode('text')
        }
        else {
            setMode('password')
        }
    }


    const [mode2, setMode2] = useState('password');
    const changeMode2 = () => {
        if (mode2 === 'password') {
            setMode2('text')
        }
        else {
            setMode2('password')
        }
    }

  

    return (
        <div className="myProfileContainer pb-5">
            <h4 className='mt-5 ms-3 mb-3'>Reset Password</h4>
            <div className="row ps-3">
                <div className="col-md-6 col-12 mb-3"> 
                    <label className='green00 mb-1' htmlFor="">Current password   </label><br />
                    <input type="text" className='shadow-none fill-white25 removeRadious  form-control border-black25' />
                </div>
                <div className="col-md-6 col-12">  </div>

                <form onSubmit={ChangePassword.handleSubmit} >
                    <div className="col-md-6 col-12 mb-3">

                    </div>
                    <div className="col-md-6 col-12 mb-3"> 
                        <label className='green00 mb-1' htmlFor="">New password* </label><br />
                        <div className="passwordField">
                        <OverlayTrigger trigger="focus" placement="bottom" overlay={popover}>
                            <input type={mode} className='shadow-none fill-white25 removeRadious pe-5 form-control border-black25'
                                id='password'
                                name='password'
                                onChange={ChangePassword.handleChange}
                                value={ChangePassword.values.password} />
                                </OverlayTrigger>
                            {ChangePassword.touched.password && ChangePassword.errors.password ? (
                                <span className="error">{ChangePassword.errors.password}</span>
                            ) : null}
                            <div className="eyeIcon2">
                                {mode === "text" && < AiOutlineEyeInvisible onClick={changeMode} />}
                                {mode === "password" && < AiOutlineEye onClick={changeMode} />}
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6 col-12">  </div>

                    <div className="col-md-6 col-12 mb-3">
                                 
                        <label className='green00 mb-1' htmlFor="">Confirm New Password*</label><br />
                        <div className="passwordField">
                            <input type={mode2} className='shadow-none fill-white25 removeRadious pe-5  form-control border-black25'
                                name='passwordconfirm'
                                id='passwordconfirm'
                                onChange={ChangePassword.handleChange}
                                value={ChangePassword.values.passwordconfirm} />
                            {ChangePassword.touched.passwordconfirm && ChangePassword.errors.passwordconfirm ? (
                                <span className="error">{ChangePassword.errors.passwordconfirm}</span>
                            ) : null}
                            <div className="eyeIcon2">
                                {mode2 === "text" && < AiOutlineEyeInvisible onClick={changeMode2} />}
                                {mode2 === "password" && < AiOutlineEye onClick={changeMode2} />}
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6 col-12">  </div>
                    <div className="col-md-6 col-12 mb-3 text-center">
                        <button type='primary' className='fill-green00 border-none white00 px-3 py-2 '>Reset</button>
                    </div>
                </form>
            </div>

        </div>
    )
}
