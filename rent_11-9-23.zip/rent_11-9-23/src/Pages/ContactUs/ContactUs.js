import React from 'react'
import Navbar from '../../Components/Navbar/Navbar'
import './ContactUs.css'
import '../../Common/common.css'
import { Link, useNavigate } from 'react-router-dom';
import Footer from '../../Components/Footer/Footer';           
import { useFormik } from "formik";
import * as Yup from "yup"
import { useSelector } from 'react-redux';
import { APIRequest, CONTACTUS } from '../../api';
import toast from 'react-simple-toasts';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';

export default function ContactUs() {
    const user = useSelector(state => state.user)
    const navigate = useNavigate();

    const contactform = useFormik({
        enableReinitialize: true,
        initialValues: {           
            userid: user?.userid,
            reason: "",
            emailbody: "",
            clientemailid: "",
            clientname: "",
            clientphone: "",           
            Preferences: "",
        }
        , validationSchema: Yup.object().shape({
            clientemailid: Yup.string().email('Please enter valid email').required(" Enter Email"),
            clientname: Yup.string().required(" Enter Name"),
            clientphone: Yup.string().required("Please Enter Mobile Number")
            .matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
                "Phone number is not valid"
            )
            .length(10,"Maximum Enter 10 Digit Number"),
            // topic:Yup.string().required('Describe Topic'),
            Preferences: Yup.string().required('Select Contact Preferance').min(2 ,'Select Contact Preferance'),
            reason: Yup.string().required('Enter Topic'),
            emailbody: Yup.string().required('Enter Description').min(5, 'Minimum 5 Character Required').max(500, "Maximum 500 Character Allowed")

        }), onSubmit: (values) => {            
            new APIRequest.Builder()
                .post()
                .setReqId(CONTACTUS)
                .jsonParams(values)
                .reqURL("master/save_contactus")
                .response(onResponse)
                .error(onError)
                .build()
                .doRequest();
        }
    });

    const onResponse = (response, reqId) => {
        switch (reqId) {
            case CONTACTUS:
                toast(`${response.data.massage}`)
                navigate('/');
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        switch (reqId) {
            case CONTACTUS:
                toast(`${response.data.massage}`)
                break;
            default:
                break;
        }
    }

    return (
        <>
            {/* <Navbar search="visible" /> */}
            <div className='main'>
                <div className="contactUs_container text-start marginMain">

                    <h2 className='page-heading'>Contact <span className='font-semibold'>Us</span></h2>
                    <p className='black50 faqpera1'>Let's see if we have already answered your question in our <Link to='/faqs' className='underline black00'>FAQs</Link> section.</p>

                    <div className="container-fluid p-md-5 mt-5  fill-white25 ">
                        <form onSubmit={contactform.handleSubmit}>
                            <div className="contactusForm-container">
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col-md-6 col-sm-12  mt-3 ">
                                            <label className='green00 mb-1' htmlFor="">Email *</label><br />
                                            <input type="email" className='shadow-none  fill-white25 removeRadious  form-control border-black25'
                                                name='clientemailid'
                                                id='clientemailid'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.clientemailid} />
                                            {contactform.touched.clientemailid && contactform.errors.clientemailid ? (
                                                <span className="error">{contactform.errors.clientemailid}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12 mt-3">
                                            <label className='green00 mb-1' htmlFor="name">Your Name *</label><br />
                                            <input type="text" className='shadow-none  fill-white25 removeRadious    form-control border-black25'
                                                name='clientname'
                                                id='clientname'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.clientname} />
                                            {contactform.touched.clientname && contactform.errors.clientname ? (
                                                <span className="error">{contactform.errors.clientname}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12  mt-3 ">
                                            <label className='green00 mb-1' htmlFor=" number">Phone Number *</label><br />
                                            <div className='d-flex'>
                                              <input value="+1"  className='shadow-none  removeRadious fill-white25 border-black25 countec' disabled/>
                                            <input type="text" className='shadow-none  fill-white25  removeRadious border-black25 form-control'
                                                name='clientphone'
                                                id='clientphone'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.clientphone} />
                                                </div>
                                            {contactform.touched.clientphone && contactform.errors.clientphone ? (
                                                <span className="error">{contactform.errors.clientphone}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12 mt-3">
                                            <label className='green00 mb-1' htmlFor="">Topic *</label><br />
                                            <input type="text" className='shadow-none fill-white25 removeRadious form-control '
                                                name='reason'
                                                id='reason'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.reason} />
                                            {contactform.touched.reason && contactform.errors.reason ? (
                                                <span className="error">{contactform.errors.reason}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12  mt-3 ">
                                            <label className='green00 mb-1' htmlFor="contact">Contact Preferences *</label><br />
                                            <select type="text" className='shadow-none fill-white25  removeRadious  form-control border-black25 form-select '
                                                name='Preferences'
                                                id='Preferences'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.Preferences}>
                                                <option value="">-Select-</option>
                                                <option value="Phone">Phone</option>
                                                <option value="Email">Email</option>
                                                <option value="Text Message">Text Message</option>
                                            </select>
                                            {contactform.touched.Preferences && contactform.errors.Preferences ? (
                                                <span className="error">{contactform.errors.Preferences}</span>
                                            ) : null}
                                        </div>
                                        <div className="col-md-6 col-sm-12 mt-3">
                                            <label className='green00 mb-1' htmlFor="description">Description*</label><br />
                                            <textarea className='shadow-none fill-white25 removeRadious form-control border-black25'
                                                name='emailbody'
                                                id='emailbody'
                                                onChange={contactform.handleChange}
                                                value={contactform.values.emailbody} />
                                            {contactform.touched.emailbody && contactform.errors.emailbody ? (
                                                <span className="error">{contactform.errors.emailbody}</span>
                                            ) : null}
                                        </div>
                                        <button type="primary" className='SubmintBtn fill-green00 white00 mb-4'>Submit</button>
                                    </div>
                                </div>
                            </div>
                            {/* <div className="Mandotary">
                            <p>* Fields Are Mandatory Reqired</p>
                        </div> */}
                        </form>


                    </div>
                </div>
            </div>

            {/* <Footer /> */}


        </>
    )
}
