import React from 'react'
import './forgot.css'
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import { useSelector, useDispatch } from 'react-redux'
import { APIRequest,RESET_PASSWORD } from '../../api';
import * as Yup from "yup";
import toast from 'react-simple-toasts';
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken';
import { TbLogin } from "react-icons/tb";

export default function Forgot() {

    const token = useSelector((state) => state.token)
    const user = useSelector((state) => state.user)
    const dispatch = useDispatch()
    const navigate = useNavigate();

    const resetpassword = useFormik({
        initialValues: {
            emailid: ""
        }, validationSchema: Yup.object().shape({
            emailid: Yup.string().email('Please enter valid email').required(" Enter Email")
        }),
        onSubmit: values => {            
            new APIRequest.Builder()
            .post()
            .setReqId(RESET_PASSWORD)
            .jsonParams(values)
            .reqURL("user/resetpassword")
            .response(onResponse)
            .error(onError)
            .build()
            .doRequest();
        }
    })

    const onResponse = (response, reqId) => {
        switch (reqId) {
            case RESET_PASSWORD:
                if (response.data.issuccess) {
                    toast("Login Password Send to Your Email");
                    navigate('/login')
                }else{
                    toast(`${response.data.massage}`)
                }
               
                break;
            default:
                break;
        }
    }

    const onError = (response, reqId) => {
        if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
            navigate('/not')
          }
        switch (reqId) {
            case RESET_PASSWORD:
                toast(`${response.data.error}`)
                break;
            default:
                break;
        }
    }
    
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="d-none d-md-block col-md-6 p-0 order-md-1 order-2">
                    <div className="login_image_container m-0 p-0">
                        <img src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/welcome_image.jpg`} className='loginImg ' alt="" />
                    </div>
                </div>
                <div className="col-md-6 p-0 order-md-2 order-1">
                    <form onSubmit={resetpassword.handleSubmit}>

                        <div className="login_form_container">
                        <Link to="/login" className='removeLinkDefaults text-white ms-4 mt-2 font-20'><TbLogin/></Link>
                            <h1 className='mb-4'><span className='font-semibold '>Forgot </span> Password</h1>

                            <div className='inputGroup'>
                                <label className='label-ph mb-2' htmlFor="emailid">Email</label><br />
                                <input className='input-light' type="email"
                                id='emailid'
                                name='emailid'
                                onChange={resetpassword.handleChange}
                                value={resetpassword.values.emailid}
                                required />
                            {resetpassword.touched.emailid && resetpassword.errors.emailid ? (
                                <span className="error">{resetpassword.errors.emailid}</span>
                            ) : null}
                            </div>
                            <div className='group3 mt-4'>
                                <button type='submit' variant="primary" className='loginBTN'>  Submit</button><br />
                                </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>

    )
}
