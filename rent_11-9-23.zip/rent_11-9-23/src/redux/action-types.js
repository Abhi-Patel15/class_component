/**
 * Auh Action Types
 * @type {string}
 */
 export const SET_TOKEN = "SET_TOKEN";
 export const SET_USER = "SET_USER";
 export const LIST_PROPERTY1 ="LIST_PROPERTY1"
 export const LIST_PROPERTY2 ="LIST_PROPERTY2"
 export const LIST_PROPERTY3 ="LIST_PROPERTY3"
 export const COMPARE_PROPERTY ="COMPARE_PROPERTY"
 export const SEARCH_PROPERTY ="SEARCH_PROPERTY"
 export const STATE_CITY ="STATE_CITY"
