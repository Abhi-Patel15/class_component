import React, { useEffect, useRef, useState } from "react";
import Modal from "react-bootstrap/Modal";
import {
  APIRequest,
  PAYMENTFOR_PROPERTY,
  GET_PAYMENTDAYWISE,
  CITYLIST,
  STATELIST,
} from "../../api";
import { useFormik } from "formik";
import * as Yup from "yup";
import toast from "react-simple-toasts";
import Select from "react-select";
import "./payment.css";
import {
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import CheckoutForm from "./checkoutform";
import { MdPowerSettingsNew } from "react-icons/md";
import { ADDRESS_TOKEN, STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from "../../Common/AddressToken";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../redux/action";
import { useNavigate } from "react-router-dom";

export const Payment = ({
  paymentmodal,
  Setpaymentmodal,
  paymentdata,
  renew,
  Setrenew,
  fatchProperty,
}) => {
  const [daywisepayment, Setdaywisepayment] = useState([]);
  const [citylist, Setcitylist] = useState([]);
  const [statelist, Setstatelist] = useState([]);
  const [stateid, Setstateid] = useState();
  const [clientpayment, Setclientpayment] = useState([]);
  const [gateway, Setgatway] = useState(true);
  const [progress, Setprogress] = useState(false);
  const [zeroamount, Setzeroamount] = useState(false);

 const dispatch = useDispatch()
 const navigate = useNavigate()

  const user = useSelector((state) => state.user.userid);

  const paymentform = useFormik({
    enableReinitialize: true,
    initialValues: {
      userid: paymentdata?.userid ?? "",
      isactive: paymentdata?.isactive ?? "",
      propertyid: paymentdata?.propertyid ?? "",
      street_address: paymentdata?.street_address ?? "",
      days: "",
      amount_pay: "",
      payment_gateway_type: "strip",
      usertype: "USER",
    },
    enableReinitialize: true,
    validationSchema: Yup.object().shape({
      days: Yup.string().required("Select Days"),
      amount_pay: Yup.string().required("Select Day For Amount"),
    }),
    onSubmit: (values) => {
      Setprogress(true);
      if (values.amount_pay === 0) {
        let finalvalue = {
          ...values,
          payment_gateway_type: "FREE",
        };
        new APIRequest.Builder()
          .post()
          .setReqId(PAYMENTFOR_PROPERTY)
          .jsonParams(finalvalue)
          .reqURL("property/payment_for_property")
          .response(onResponse)
          .error(onError)
          .build()
          .doRequest();
      } else {
        new APIRequest.Builder()
          .post()
          .setReqId(PAYMENTFOR_PROPERTY)
          .jsonParams(values)
          .reqURL("property/payment_for_property")
          .response(onResponse)
          .error(onError)
          .build()
          .doRequest();
      }
    },
  });
  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(GET_PAYMENTDAYWISE)
      .jsonParams({ isactive: "Y", userid: user })
      .reqURL("master/get_payment_daywise_master_paymentcheck")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(STATELIST)
      .jsonParams({ isactive: "Y" })
      .reqURL("master/get_statemaster")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, []);

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(CITYLIST)
      .jsonParams({ stateid: stateid })
      .reqURL("master/get_citymaster")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [stateid]);

  useEffect(() => {
    if (paymentform.values.days !== "" && paymentform.values.days !== "00") {
      paymentform.setFieldValue(
        "amount_pay",
        daywisepayment.filter(
          (item) => item.days === +paymentform.values.days
        )[0]?.amount
      );
    } else {
      paymentform.setFieldValue("amount_pay", "");
    }
  }, [paymentform.values.days]);

  useEffect(() => {
    if (paymentform.values.amount_pay === 0) {
      Setzeroamount(true);
    } else {
      Setzeroamount(false);
    }
  }, [paymentform.values.amount_pay]);

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case GET_PAYMENTDAYWISE:
        Setdaywisepayment(response?.data?.data);
        break;
      case PAYMENTFOR_PROPERTY:
        Setprogress(false);
        if (response.data.data.payment_detail === null) {
          Setpaymentmodal(false);
          fatchProperty();
        } else {
          Setclientpayment(response.data.data.payment_detail);
        }
        toast(`${response?.data?.massage}`);
        Setgatway(false);
        break;
      case CITYLIST:
        Setcitylist(response.data.data);
        break;
      case STATELIST:
        Setstatelist(response.data.data);
        break;
      default:
        break;
    }
  };

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    if(response.data.status==STATE_ERROR){
      localStorage.clear()
      dispatch(logout())
      navigate("/login");
    }
    switch (reqId) {
      case GET_PAYMENTDAYWISE:
        console.log(response);
        break;
      case PAYMENTFOR_PROPERTY:
        Setprogress(false);
        toast(`${response?.data?.massage}`);
        break;
      case CITYLIST:
        console.log(response.data.data);
        break;
      case STATELIST:
        console.log(response.data.data);
        break;
      default:
        break;
    }
  };

  const appearance = {
    theme: "stripe",

    variables: {
      colorPrimary: "#368274",
      colorBackground: "#F6F7F8",
      colorText: "#368274",
      color: "#000000",
      colorDanger: "#df1b41",
      fontFamily: "Poppins, sans-serif",
      spacingUnit: "4px",
      borderRadius: "0px",
      spacingGridRow: "20px",
      spacingGridColumn: "20px",
      // See all possible variables below
    },
  };

  const stateOptions = statelist?.map((item) => {
    return { label: item.state, value: item.stateid };
  });
  const cityOptions =
    stateid &&
    citylist?.map((item) => {
      return { label: item.city, value: item.cityid };
    });
  const options = {
    clientSecret: clientpayment?.client_secret,
    appearance,
  };
  const stripePromise =
    clientpayment?.strip_publickey &&
    loadStripe(clientpayment?.strip_publickey);
  return (
    <>
      <Modal
        show={paymentmodal}
        onHide={() => {
          Setpaymentmodal(false);
          Setrenew(false);
          // Setclientpayment([])
          // paymentform.resetForm()  
          window.location.reload(false)       
        }}
        className="paymentModal"
        size="xl"
      >
        <Modal.Header closeButton onClick={() => window.location.reload(false)} >
          <Modal.Title>{renew ? "Renew Payment" : "Make Payment"}</Modal.Title>
        </Modal.Header>
        <Modal.Body className="fill-white25 rounded">
          <div className="container-fluid p-2 ">
            <form onSubmit={paymentform.handleSubmit}>
              {/* <div className="d-flex">
                <h5 className="black00 font-semibold  mb-4 ">
                  Billing Address
                </h5>
              </div> */}
              {/* <div className="col-12">
                <label className="green00 font-1 mb-2" htmlFor="">
                  Street Address
                </label>
                <br />
                <textarea
                  className="w-100 fill-white25 border-black25 outline-none"
                  defaultValue={paymentdata?.street_address}
                ></textarea>
              </div> */}
              <div id="messages" role="alert" style={{ display: "none" }}></div>
              <div className="row   fill-white25 ">
                <div className="d-flex">
                  <h5 className="black00 font-semibold mb-3">
                    Payment Information
                  </h5>
                </div>

                <div className="col-12  col-lg-3 col-md-6 col-sm-6 mt-4">
                  <label className="green00 font-1 mb-2" htmlFor="">
                    No. of Days
                  </label>
                  <br />
                  <select
                    className="shadow-none fill-white25 removeRadious   form-select   form-control border-black25"
                    id="days"
                    name="days"
                    value={paymentform.values.days}
                    onChange={paymentform.handleChange}
                  >
                    <option value="00">-Select-</option>
                    {daywisepayment?.map((item, id) => (
                      <option value={item?.days}>{item?.days}</option>
                    ))}
                  </select>
                  {paymentform.touched.days && paymentform.errors.days ? (
                    <span className="error">{paymentform.errors.days}</span>
                  ) : null}
                </div>

                <div className="col-12 col-lg-3  col-md-6 col-sm-6 mt-4">
                  <label className="green00 font-1 mb-2" htmlFor="">
                    Amount
                  </label>
                  <br />
                  <input
                    className="shadow-none fill-white25 removeRadious  form-control border-black25"
                    value={paymentform.values.amount_pay}
                    disabled
                  />
                  {/* <select className='shadow-none fill-white25 removeRadious   form-select   form-control border-black25'
                                        id='amount_pay' name='amount_pay' value={paymentform.values.amount_pay} onChange={paymentform.handleChange}>
                                        <option value="">-Select-</option>
                                        {daywisepayment.filter((item) => item.days === +paymentform.values.days)?.map((item, id) => <option key={id} value={item?.amount}>{item?.amount}</option>)}
                                    </select> */}
                  {paymentform.touched.amount_pay &&
                  paymentform.errors.amount_pay ? (
                    <span className="error">
                      {paymentform.errors.amount_pay}
                    </span>
                  ) : null}
                </div>

                {gateway && (
                  <div className="row text-center mt-4 mb-3">
                    <button
                      type="submit"
                      disabled={progress}
                      className="w-auto m-auto border-none fill-green00 py-2 px-3 white00"
                    >
                      {zeroamount ? (
                        <span id="button-text">Submit</span>
                      ) : (
                        <span id="button-text">
                          {progress ? "Processing ... " : "Process To Payment"}
                        </span>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </form>
            <div className="paymentform mt-4">
              {stripePromise && options && (
                <Elements stripe={stripePromise} options={options}>
                  <CheckoutForm paymentdata={paymentdata} className="p-0" />
                </Elements>
              )}
              <div id="error-message"></div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};
