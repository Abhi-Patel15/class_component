import React from 'react'
import'./comingsoon.css'

const ComingSoon = () => {
  return (
    <div className='comingsoonrent'>
    <div className="containerdata">
    <div className="mainText">
      <h1 className="title">Urbanesting</h1>
      <p className="subtitle">Revolutionizing Your Rental Experience</p>
      <p className="launchText">Search or List Property Upon Launch</p>
      <div className="comingSoon">
        <span className="comingSoonText">Coming</span>
        <span className="comingSoonText">Soon</span>
      </div>
    </div>
  </div>
  </div>
  )
}

export default ComingSoon