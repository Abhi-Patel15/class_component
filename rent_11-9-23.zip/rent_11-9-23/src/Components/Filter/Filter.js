import { React, useEffect, useState } from 'react'
import Select from 'react-select'
import './Filter.css'
import '../../Common/common.css'
import { CgSearch } from 'react-icons/cg'
import { MdOutlineCancel } from 'react-icons/md'
import {
  APIRequest, PROPERTYTYPE, BATHROOM, BEDROOM, PETPOLICY, OVERLOOKING,
  AMENITITES_SMART, AMENITITES_ENERGY, AMENITITES_COMMUTINY, PROPERTY_FILTER, CITYLIST, STATELIST
} from '../../api'
import { useSelector } from 'react-redux'
import { useFormik } from 'formik'
import * as Yup from "yup"
import { STATE_CODE404, STATE_ERROR500 } from '../../Common/AddressToken'
import { useNavigate } from 'react-router-dom'

export default function Filter({ Setf_searchproperty, f_searchproperty, SetListdata  ,setShowFilter}) {

  const state = useSelector(state => state.statecity);

  const [locationSearch, setLocationSearch] = useState("none");
  const [sortype, Setsortype] = useState()
  const [bathroom, Setbathroom] = useState([]);
  const [bedroom, Setbedroom] = useState([]);
  const [petpolicy, Setpetpolicy] = useState([]);
  const [overlooking, Setoverlooking] = useState([]);
  const [propertype, Setpropertype] = useState([]);
  const [Ame_smaert, SetAme_smaert] = useState([])
  const [Ame_energy, SetAme_energy] = useState([])
  const [Ame_community, SetAme_community] = useState([])
  const [enery_check, setenery_check] = useState([]);
  const [smart_check, setsmart_check] = useState([]);
  const [community_check, setcommunity_check] = useState([]);
  const [citylist, Setcitylist] = useState([]);
  const [statelist, Setstatelist] = useState([]);
  const [stateid, Setstateid] = useState();
  const navigate = useNavigate()



  useEffect(() => { 
    new APIRequest.Builder()
      .post()
      .setReqId(BATHROOM)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/getbathrooms")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(BEDROOM)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/getbedrooms")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(PETPOLICY)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/getpetpolicy")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(OVERLOOKING)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/getoverlooking")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(PROPERTYTYPE)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/getpropertytype")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(AMENITITES_SMART)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/get_amenities_smart")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(AMENITITES_ENERGY)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/get_amenities_energy_efficient")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(AMENITITES_COMMUTINY)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/get_amenities_community")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    new APIRequest.Builder()
      .post()
      .setReqId(STATELIST)
      .jsonParams({ "isactive": "Y" })
      .reqURL("master/get_statemaster")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(CITYLIST)
      .jsonParams({ "stateid": stateid })
      .reqURL("master/get_citymaster")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [stateid])

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case BATHROOM:
        Setbathroom(response?.data?.data)
        break;
      case BEDROOM:
        Setbedroom(response?.data?.data)
        break;
      case PETPOLICY:
        Setpetpolicy(response?.data?.data)
        break;
      case OVERLOOKING:
        Setoverlooking(response?.data?.data)
        break;
      case PROPERTYTYPE:
        Setpropertype(response?.data?.data)
        break;
      case AMENITITES_SMART:
        SetAme_smaert(response?.data?.data)
        break;
      case AMENITITES_ENERGY:
        SetAme_energy(response?.data?.data)
        break;
      case AMENITITES_COMMUTINY:
        SetAme_community(response?.data?.data)
        break;
      case PROPERTY_FILTER:
        Setf_searchproperty(response?.data?.data)
        SetListdata(response?.data?.data)
        setShowFilter(false);
        break;
      case CITYLIST:
        Setcitylist(response.data.data)
        break;
      case STATELIST:
        Setstatelist(response.data.data)
        break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    switch (reqId) {
      case BATHROOM:
        console.log(response)
        break;
      case BEDROOM:
        console.log(response)
        break;
      case PETPOLICY:
        console.log(response)
        break;
      case OVERLOOKING:
        console.log(response)
        break;
      case PROPERTYTYPE:
        console.log(response)
        break;
      case AMENITITES_SMART:
        console.log(response)
        break;
      case AMENITITES_ENERGY:
        console.log(response)
        break;
      case AMENITITES_COMMUTINY:
        console.log(response)
        break;
      case PROPERTY_FILTER:
        console.log(response)
        break;
      case CITYLIST:
        console.log(response.data.data)
        break;
      case STATELIST:
        console.log(response.data.data)
        break;
      default:
        break;
    }
  }


  function handleLocationSearch() {

    if (locationSearch == "none") {
      setLocationSearch("block")
    }
    else {
      setLocationSearch("none")
    }
  }

  const filterform = useFormik({
    enableReinitialize:"true",
    initialValues: {
      state: state?.state ?? "",
      city: state?.city ?? "",
      sorting_type: sortype ,
      property_type_name: "",
      street_address: state?.street_address ?? "",
      min_amount: "",
      max_amount: "",
      pet_policy_condition: "",
      bathrooms_range: "",
      bedrooms_range: "",
      amenities_smart: "",
      amenities_energy_efficient: "",
      amenities_community: "",
      bedrooms_range: "",
      bathrooms_range: ""
    }, validationSchema: Yup.object().shape({
      max_amount: Yup.number().integer().nullable().moreThan(Yup.ref("min_amount"), "Max Amount Grater Than Min Amount")
    }), onSubmit: values => {
      new APIRequest.Builder()
        .post()
        .setReqId(PROPERTY_FILTER)
        .jsonParams(values)
        .reqURL("property/get_propertysearch")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    }
  })

  useEffect(() => {
    filterform.setFieldValue('amenities_energy_efficient', enery_check.toString())
    filterform.setFieldValue('amenities_community', community_check.toString())
    filterform.setFieldValue('amenities_smart', smart_check.toString())

  }, [enery_check, community_check, smart_check])

  const ClearFilter =()=>{
    window.location.reload(true) 
    filterform.resetForm();
  }

  const stateOptions = statelist?.map((item) => { return { "label": item.state, "value": item.stateid } })
  const cityOptions = stateid && citylist?.map((item) => { return { "label": item.city, "value": item.cityid } })

  return (
    <>
      <div className="filterContainer black10 p-2">
        <form   onSubmit={filterform.handleSubmit}>
          <button type='submit' className=' fill-green00 white00 border-none applyFiltersBtn '>Apply filters</button>
          <button type="button" className=' bg-none underline text-end  green00 border-none applyFiltersBtn ' onClick={()=>ClearFilter()}>Clear filters</button>

          <div>
            <div className="d-flex justify-content-between mt-4">
              <p className='black00 font-14 font-bold   m-0'>Property type</p>
              <select className='bg-none semibold border-none m-0 font-14 sortbyFilter' onClick={e => Setsortype(e.target.value)}>
                <option value="">Select</option>
                <option value="price_low_to_high">Price : Low to High</option>
                <option value="price_high_to_low">Price : High to Low</option>
                <option value="oldest_to_newest">Oldest To Newest</option>
                <option value="newest_to_oldest"> Newest To Oldest </option>
                <option value="alphabetically_a_z">A-Z</option>
                <option value="alphabetically_z_a">Z-A</option>            
              </select>
            </div>
            <hr className='p-0 mt-1 border-black25' />
            <select name="property_type_name" className='shadow-none selectFilterWidth black50 fill-white00 w-75 removeRadious   form-select   form-control border-black25'
              onChange={filterform.handleChange} >
              <option value="">-Select</option>
              {propertype?.map((item, id) => <option key={id} id={item?.property_type_id} value={item?.property_type_name} >{item?.property_type_name}</option>)}
            </select>
          </div>
          {/* pet policy */}  
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>Pet policy</p>
            <hr className='p-0 mt-1 border-black25' />  
            {petpolicy?.map((item, id) =>
              <>
               <label  className='font-14 m-0 black50  font-semibold rowRadio' >
          <input type="radio" name="pet_policy_condition" className='radioGreen me-1' key={id} id={`pet_policy_${id}`} value={item?.pet_policy_condition}
                onChange={filterform.handleChange}  />
         {item?.pet_policy_condition}</label> <br /></>)}
              </div>
          {/* amenities */}
          
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>Amenities</p>
            <hr className='p-0 mt-1 border-black25' />
            <p className='font-14 green00 font-semibold m-0'>Smart Home Amenities</p>
            <div className="amenitiesFilterCOntainer">
              {Ame_smaert.map((item, id) => <div className='animeitesParent'>
              <label className='font-14 m-0  black50 font-semibold amenitiesLabel rowRadio'>
                <input key={id} type="checkbox" className="me-1" name="amenities_smart" id={`amenities_smart_${id}`}
                onChange={(e) => {
                  // add to list
                  if (e.target.checked) {
                    setsmart_check([...smart_check, item.amenities_smart]);
                  } else {
                    setsmart_check(
                      smart_check.filter((people) => people !== item.amenities_smart),
                    );
                  }
                }}
                value={item?.amenities_smart} />
             {item?.amenities_smart}</label> <br /></div>)}
            </div>

            <p className='font-14 green00 font-semibold m-0'>Energy-Efficient Amenities</p>
            <div className="amenitiesFilterCOntainer">

              {Ame_energy.map((item, id) => <div className='animeitesParent'>
              <label className='font-14 m-0  black50 font-semibold amenitiesLabel rowRadio' >
                <input key={id} type="checkbox" className="me-1" name="amenities_energy_efficient" id={`amenities_energy_efficient_${id}`}
                 value={item?.amenities_energy_efficient} onChange={(e) => {
                  // add to list
                  if (e.target.checked) {
                    setenery_check([...enery_check, item?.amenities_energy_efficient]);
                  } else {
                    setenery_check(enery_check.filter((people) => people !== item?.amenities_energy_efficient),
                    );
                  }
                }} />
               {item?.amenities_energy_efficient}</label> <br /></div>)}
            </div>
            <p className='font-14 green00 font-semibold m-0'>In-unit or Community Amenities</p>
            <div className="amenitiesFilterCOntainer">

              {Ame_community.map((item, id) => <div className='animeitesParent'>
              <label className='font-14 m-0  black50 font-semibold amenitiesLabel rowRadio' >
                <input key={id} type="checkbox" className='me-1' name="amenities_community" id={`amenities_community_${id}`} 
                value={item?.amenities_community} onChange={(e) => {
                  // add to list
                  if (e.target.checked) {
                    setcommunity_check([...community_check, item?.amenities_community]);
                  } else {
                    setcommunity_check(
                      community_check.filter((people) => people !== item?.amenities_community),
                    );
                  }
                }} />
               {item?.amenities_community}</label> <br /></div>)}

            </div>
          </div>
          {/* Price*/}
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>Price</p>
            <hr className='p-0 mt-1 border-black25' />
            <div className="d-flex">
              <input type="number" name='min_amount' className='minMaxInput removeRadious border-black25 font-semibold' placeholder='$ Min' onChange={filterform.handleChange} />
              <input type="number" name='max_amount' className='minMaxInput removeRadious border-black25 font-semibold' placeholder='$ Max' onChange={filterform.handleChange} />
            </div>
            {filterform.touched.max_amount && filterform.errors.max_amount ? (
              <span className="error">{filterform.errors.max_amount}</span>
            ) : null}
          </div>


          {/*Bedrooms */}
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>Bedroom</p>
            <hr className='p-0 mt-1 border-black25' />
            <select className='shadow-none selectFilterWidth font-semibold  black50 fill-white00 w-75 removeRadious   form-select   form-control border-black25'
              value={filterform.values.bedrooms_range} name="bedrooms_range" id='bedrooms_range' onChange={filterform.handleChange}>
              <option value="">-Select-</option>
              {bedroom?.map((item, id) => <option key={id} id={item?.bedrooms_id} value={item?.bedrooms_range}>{item?.bedrooms_range}</option>)}
            </select>
          </div>

          {/*Bathroom */}
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>Bathroom</p>
            <hr className='p-0 mt-1 border-black25' />
            <select className='shadow-none selectFilterWidth font-semibold  black50 fill-white00 w-75 removeRadious   form-select   form-control border-black25'
              value={filterform.values.bathrooms_range} name="bathrooms_range" id='bathrooms_range' onChange={filterform.handleChange} >
              <option id='' value="">-Select-</option>
              {bathroom?.map((item, id) => <option key={id} id={item?.bathrooms_id} value={item?.bathrooms_range}>{item?.bathrooms_range}</option>)}
            </select>
          </div>

          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>State</p>
            <hr className='p-0 mt-1 border-black25' />
            {/* <select className='shadow-none selectFilterWidth font-semibold  black50 fill-white00 w-75 removeRadious   form-select   form-control border-black25'
          value={filterform.values.bathrooms_range} name="bathrooms_range" id='bathrooms_range' onChange={filterform.handleChange} > */}
            <Select className='shadow-none fill-white25 removeRadious  p-0 w-75 selectFilterWidth '
              name='state'
              id='state'
              placeholder="Select state"
              options={stateOptions}
              value={ filterform?.values?.state === ""?"":{"label":filterform?.values?.state}}
              onChange={value => {
                filterform.setFieldValue("state", value.label);
                filterform.setFieldValue("city", "");
                Setstateid(value.value)
              }} >
            </Select>
          </div>
          <div className='mt-4'>
            <p className='black00 font-14 font-bold   m-0'>City</p>
            <hr className='p-0 mt-1 border-black25' />
            <Select className='shadow-none fill-white25 removeRadious  p-0  w-75 selectFilterWidth'
              name='city'
              id='city'
              placeholder="Select city"
              options={cityOptions}
              value={filterform?.values?.city === "" ? "" : { "label": filterform?.values?.city }}
              onChange={value => {
                filterform.setFieldValue("city", value.label);
              }} />
          </div>
          {/* Location */}
          <div className='mt-4'>
            <div className="d-flex justify-content-between ">
              <p className='black00 font-14 font-bold   m-0'>Location</p>

              <div className='p-0' onClick={handleLocationSearch}>
                {
                  locationSearch == "none" ? <CgSearch className='me-1' /> : <MdOutlineCancel className='me-1' />
                }

              </div>

            </div>
            <hr className='p-0 mt-1 border-black25' />
            <div className="amenitiesFilterCOntainer">

              <div style={{ display: locationSearch }}>
                <input type="text" className='locationSearcBar' placeholder='Search location' name='street_address'
                  value={filterform.values.street_address} onChange={filterform.handleChange} /><br />
              </div>

              {/* <input type="checkbox" name="" id="" className='mt-2' /><label className='font-14 m-0 ms-1 black50 font-semibold'>Andheri (e)</label> <br />
              <input type="checkbox" name="" id="" className='mt-2' /><label className='font-14 m-0 ms-1 black50 font-semibold'>Andheri (w)</label> <br />
              <input type="checkbox" name="" id="" className='mt-2' /><label className='font-14 m-0 ms-1 black50 font-semibold'>Colaba</label> <br />
              <input type="checkbox" name="" id="" className='mt-2' /><label className='font-14 m-0 ms-1 black50 font-semibold'>Malad</label> <br /> */}
            </div>
          </div>




        </form> 
      </div>
    </>
  )
}
