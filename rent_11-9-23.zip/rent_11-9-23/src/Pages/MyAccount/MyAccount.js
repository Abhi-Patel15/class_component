import React, { useEffect, useState } from 'react'
import './MyAccount.css'
import '../../Common/common.css';
import { Link, Outlet, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import MyProfile from './MyProfile';
import MyListing from './MyListing';
import ChangePassword from './ChangePassword';
import { useDispatch, useSelector } from 'react-redux';
import { logout, setUser } from '../../redux/action';
import { APIRequest, UPLOAD_FILES ,PROFILE_UPDATE} from '../../api';
import toast from 'react-simple-toasts';
import { STATE_CODE404, STATE_ERROR, STATE_ERROR500 } from '../../Common/AddressToken';


export default function MyAccount() { 
  const location = useLocation(); 
  const user = useSelector(state => state?.user);
  const [profileimage, Setprofileimage] = useState(user?.profileImage);
  const dispatch = useDispatch();
  const navigate = useNavigate();


  const logOut = () => {
    localStorage.clear();
    dispatch(logout())
    navigate("/");
  }

  const profileUpload = (e) => {
    var data = new FormData();
    var file = e.target.files[0];
    data.append("image", file);
    new APIRequest.Builder()
      .post()
      .setReqId(UPLOAD_FILES)
      .jsonParams(data)
      .reqURL(`master/uploadfile`)
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(PROFILE_UPDATE)
      .jsonParams({
        "emailid": user?.emailid ?? "",
        "firstname": user?.firstname ?? "",
        "lastname": user?.lastname ?? "",
        "mobileno": user?.mobileno ?? "",
        "profileImage": profileimage ?? "",
        "mode": "update"
      })
      .reqURL("user/signup")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [profileimage])

  const onResponse = (response, reqId) => {
    switch (reqId) {
      case UPLOAD_FILES:
        Setprofileimage(response?.data?.data)
        break;
      case PROFILE_UPDATE:       
        if (response.data.issuccess) {
          dispatch(setUser(response.data.data))
        } else {
          toast(`${response.data.massage}`)
        }
        break;
      default:
        break;
    }
  }

  const onError = (response, reqId) => {
    if(STATE_CODE404 == response.data.status || STATE_ERROR500 == response.data.status ){
      navigate('/not')
    }
    if(response.data.status==STATE_ERROR){
      localStorage.clear()
      dispatch(logout())
      navigate("/login");
    }
    switch (reqId) {
      case UPLOAD_FILES:
        console.log(response)
        break;
      case PROFILE_UPDATE:
        toast("Profile is not successfully updated");
        break;
      default:
        break;
    }
  }
 
  return (
    <>
      {/* <Navbar search="visible"/> */}
      <div className='main marginMyAccount'>
        <div className="myAccountContainer">
          <div className="container-fluid">

            <div className="row g-3">
              <div className=" col-xxl-2 col-lg-3  col-12 p-0">
                <div className="nav flex-column nav-pills me-md-3 fill-white25 radious-10 h-100" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                  <div className='userInfo mt-4'>
                    <div className="profilePictureContainerMain">
                      <div className='profilePictureContainer'>
                        <img 
                        src={user?.profileImage === null ?`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/defaultUserImage_2.png` :
                        `${user?.profileImage}`} className='img-fluid' alt="" />
                      </div>
                      <label htmlFor='profileInput'><img src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/editImageBtn.png`} alt="" className='editImgBtn' /></label>
                      {/* <label htmlFor='profileInput'>Change <i className="fa-solid fa-pencil"></i></label> */}
                      <input type="file" id='profileInput' onChange={profileUpload} className='profileInput' />
                    </div>
                    <p className='green00 font-semibold m-0 mt-2 mb-4'>{user?.firstname + "  "  + user?.lastname}</p>
                    {/* <div className='text-break'>
                    <p className='font-14 black75  m-0 mb-5'>{user?.emailid ?? ""}</p>
                    </div> */}
                  </div>
                  <button className={ location.pathname === "/my-account/myprofile" ? "ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start active":
                  " ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start "} 
                  id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile"
                   type="button" role="tab" onClick={()=>{navigate('myprofile')}} aria-controls="v-pills-profile" aria-selected="false">My profile</button>

                  <button className= { location.pathname === "/my-account/my-listing" ? "ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start active":
                  " ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start "} id="v-pills-listing-tab" data-bs-toggle="pill" data-bs-target="#v-pills-listing" type="button" role="tab" 
                   onClick={()=>{navigate('my-listing')}}  aria-controls="v-pills-listing" aria-selected="false">My Listing</button>

                  <button className={ location.pathname === "/my-account/changepassword" ? "ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start active":
                  " ps-5 mb-3  font-semibold black75 fill-white25 border-none text-start "} id="v-pills-password-tab" 
                  data-bs-toggle="pill" data-bs-target="#v-pills-password" type="button" role="tab" onClick={()=>{navigate('changepassword')}}
                    aria-controls="v-pills-password" aria-selected="false">Reset Password</button>

                  <button className=" ps-5 mb-3 font-semibold black75 fill-white25 border-none text-start " onClick={logOut} type="button" role="tab"  >Logout</button>
                </div>
              </div>
              <div className=" col-xxl-10 col col-lg-9  col-12 fill-white25 radious-10">
                <div className="tab-content radious-10" id="v-pills-tabContent ">
                  <Outlet/>                 
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  )
}
