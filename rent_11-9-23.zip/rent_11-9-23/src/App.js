import React, { Fragment } from 'react';
import './App.css';
import Login from './Pages/Login/Login';
import Forgot from './Pages/Forgot/forgot'
import CreatePassword from './Pages/create-password/create-password'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Routes, Route, BrowserRouter, Router } from 'react-router-dom';
import Signup from './Pages/Signup/Signup';
import Faq from './Pages/Faq/Faq';
import ContactUs from './Pages/ContactUs/ContactUs';
import './Common/common.css'
import AboutUs from './Pages/AboutUs/AboutUs';
import PropertyDetails from './Pages/PropertyDetails/PropertyDetails'
import ListProperty1 from './Pages/ListProperty/ListProperty1';
import PropertyDisplay from './Pages/PropertyDisplay/PropertyDisplay';
import Favourites from './Pages/Favourites/Favourites';
import Comparision from './Pages/Comparision/Comparision';
import Homepage from './Pages/Homepage/Homepage';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import MyAccount from './Pages/MyAccount/MyAccount';
import MyProfile from './Pages/MyAccount/MyProfile';
import TermsAndConditions from './Pages/TermsAndConditions/TermsAndConditions';
import PrivacyPolicy from './Pages/PrivacyPolicy/PrivacyPolicy';
import Search from './Pages/Search/Search';
import Navbar from './Components/Navbar/Navbar';
import Home from './Pages/Homepage/Home';
import ListProperty2 from './Pages/ListProperty/ListProperty2';
import ListProperty3 from './Pages/ListProperty/ListProperty3';
import ListProperty4 from './Pages/ListProperty/ListProperty4';
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import AppStore from "../src/redux/store";
import NotFound from './Pages/NotFound/NotFound';
import ScrollToTop from './Components/ScroolTop/scrooltop';
import MyListing from './Pages/MyAccount/MyListing';
import ChangePassword from './Pages/MyAccount/ChangePassword';
import Paymenttest from './Pages/paymenttest';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Maintenance } from './Pages/maintenance/Maintenance';
import MoveInChecklist from './Pages/Move-in-Checklist/MoveInChecklist';
import LaseAgreement from './Pages/GenerateLaseAgreement/LaseAgreement';
import ComingSoon from './Pages/ComingSoon/ComingSoon';
import { useState } from 'react';
function App() {
  const [value,setValue] = useState(true)
 
  return (
    <>     
    <ScrollToTop/>   
      <Provider store={AppStore.store}>
        <PersistGate loading={null} persistor={AppStore.persistor}>
            <Routes>
              {value?(
                <>
            <Route exact path='/login' element={<Login />} />
            <Route exact path='/Forgot' element={<Forgot />} />
            <Route exact path='/CreatePassword' element={<CreatePassword />} />
            <Route exact path='/' element={<Homepage />}>
              <Route exact path='' element={<Home />} />
              <Route exact path='favorites' element={<Favourites />} />
              <Route exact path='about-us' element={<AboutUs />} />
              <Route exact path='faqs' element={<Faq />} />
              <Route exact path='contact-us' element={<ContactUs />} />
              <Route exact path='move-in-checklist' element={<MoveInChecklist />} />
              <Route exact path='lease-agreement' element={<LaseAgreement />} />
              <Route exact path='property-details/:id' element={<PropertyDetails />} />
              <Route exact path='list-property' element={<ListProperty1 />} />
              <Route exact path='list-property2' element={<ListProperty2 />} />
              <Route exact path='list-property3' element={<ListProperty3  />} />
              <Route exact path='list-property4' element={<ListProperty4  />} />
              <Route exact path='property-display' element={<PropertyDisplay />} />
              <Route exact path='comparision' element={<Comparision />} />
              <Route exact path='my-account' element={<MyAccount />} >
              <Route exact path='my-listing' element={<MyListing />} />
              <Route exact path='my-listing/:propertyid' element={<MyListing />} />
              <Route exact path='myprofile' element={<MyProfile />} />
              <Route exact path='changepassword' element={<ChangePassword />} /> </Route>              
              <Route exact path='terms-and-conditions' element={<TermsAndConditions />} />
              <Route exact path='privacy-policy' element={<PrivacyPolicy />} />
              <Route exact path='search' element={<Search />} />
            </Route>
            <Route exact path='/signup' element={<Signup />} />
            <Route exact path='/testpayment' element={<Paymenttest />} />
            <Route exact path='*' element={<NotFound />} />
            <Route exact path='/not' element={<Maintenance />} />
            </> ):(<><Route exact path='/' element={<ComingSoon/>}/></>)}
          </Routes>        
        </PersistGate>
      </Provider>
    </>
  );
}

export default App;


