import React, { useState } from 'react'
import './Footer.css'
import '../../Common/common.css'
import {FaFacebookF,FaTwitter} from 'react-icons/fa'
import {RiInstagramFill} from 'react-icons/ri'
import { Link, useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import toast from 'react-simple-toasts';

export default function Footer() {
  const user = useSelector((state) => state.user);
  const navigate = useNavigate();
    const item = {
        facebookURL: 'http://www.facebook.com',
        instagramURL: 'http://www.instagram.com',
        twitterURL: 'http://www.twitter.com',
      }
    //   <a href={item.projurl} target="_blank" rel="noopener noreferrer">{item.projurl}</a>
  return (
     <>
     <div className="footerontainer gradient-bg mt50 ">
        <div className="row ">
            <div className="col-md-3 col-6 mt-2">
                <p><Link to="/search" className="removeLinkDefaults white00 ">Search Property</Link></p> 
                <p><Link  to={user?.userid !== undefined ? "/list-property" : "/login"} className="removeLinkDefaults white00 ">List a property</Link></p>
                {/* <p className="removeLinkDefaults white00 " data-bs-toggle="modal" data-bs-target="#calculatorModal">Monthly Rent Calculator</p> */}
                <p><Link to='/about-us' className='removeLinkDefaults white00'>About us</Link></p>
            </div>
            <div className="col-md-6 col-sm-6 d-md-block d-none">
                <div className="socialLinkContainer ">
                  <Link  className='removeLinkDefaults white00' to="/">
                <img src="/assets/images/logo3.png" className='footerLogoImage' alt="" />
                </Link>
                    <div className="d-flex">
                       <a href={item.facebookURL} target="_blank"><FaFacebookF className='socialIcon'/></a>
                       <a href={item.instagramURL} target="_blank"><RiInstagramFill className='socialIcon'/></a>
                       <a href={item.twitterURL} target="_blank"><FaTwitter className='socialIcon'/> </a>
                    </div>
                  
                </div>  
            </div> 
            <div className="col-md-3 col-6 mt-2 text-end d-lg-none d-block">
                <p><Link 
                 to="/contact-us"  
                 className='removeLinkDefaults white00'>Contact us </Link></p>
                <Link to="/faqs" className='removeLinkDefaults'><p className='white00'>FAQs</p></Link>
                <p className='white00'><Link to='/terms-and-conditions' className='removeLinkDefaults white00'>Terms of use</Link></p>
                <p className='white00'><Link to='/privacy-policy' className='removeLinkDefaults white00'>Privacy policy</Link></p>
            </div> 
            
            <div className="col-md-8 col-sm-6 d-md-none d-block">
                <div className="socialLinkContainer ">
                  <Link  className='removeLinkDefaults white00' to="/">
                <img src="/assets/images/logo3.png" className='footerLogoImage' alt="" />
                </Link>
                    <div className="d-flex">
                       <a href={item.facebookURL} target="_blank"><FaFacebookF className='socialIcon'/></a>
                       <a href={item.instagramURL} target="_blank"><RiInstagramFill className='socialIcon'/></a>
                       <a href={item.twitterURL} target="_blank"><FaTwitter className='socialIcon'/> </a>
                    </div>
                  
                </div>  
            </div> 

            <div className="col-md-3 col-6 mt-2 text-end d-none d-lg-block">
                <p><Link 
                 to="/contact-us"
                 className='removeLinkDefaults white00'>Contact us </Link></p>
                <Link to="/faqs" className='removeLinkDefaults'><p className='white00'>FAQs</p></Link>
                <p className='white00'><Link to='/terms-and-conditions' className='removeLinkDefaults white00'>Terms of use</Link></p>
                <p className='white00'><Link to='/privacy-policy' className='removeLinkDefaults white00'>Privacy policy</Link></p>
            </div> 
        </div>

        <div className="row text-center">
            <p className='white00 copyrightText'>© Copyrights All rights reserved</p>
        </div>
     </div>
     </>
  ) 
}
