import { React, useEffect, useState } from 'react'
import Filter from '../../Components/Filter/Filter';
import ProductCard from '../../Components/ProductCard/ProductCard';
import './PropertyDisplay.css'
import '../../Common/common.css'
import Offcanvas from 'react-bootstrap/Offcanvas';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

export default function PropertyDisplay() {
   const searchproperty = useSelector(state => state.searchproperty);
   const [showFilter, setShowFilter] = useState(false);
   const handleFilterClose = () => setShowFilter(false);
   const handleFilterShow = () => setShowFilter(true);
   const [listdata, SetListdata] = useState(searchproperty);
   const [f_searchproperty, Setf_searchproperty] = useState(searchproperty)   

   return (
      <>
         {/* <Navbar search="visible"/> */}
         <div className='main'>
            <div className="propertyDisplayContainer">
               <div className="container-fluid p-0">
                  <div className="row">
                     <div className="col col-lg-3  d-none  d-lg-block">
                        <Filter Setf_searchproperty={Setf_searchproperty} f_searchproperty={f_searchproperty}  SetListdata={SetListdata} />
                     </div>
                     <div className="col-lg-9 col-12">
                        <a className='filterMenu black75 fill-white25 p-3 py-1 w-auto mt-3 ' onClick={handleFilterShow}>Filter</a>
                        <div className="row">
                        {f_searchproperty?.length === 0 &&  <p className='font-20 font-bold green00 text-center mt-5'>No Property Found !!!</p>}
                           {f_searchproperty?.map((item, id) =>
                              <div className="col-xxl-3 col-md-4 col-sm-6 col-12">
                                 <div className="card-shadow" key={id}>
                                    <ProductCard path={`${item.cover_image_url}`}
                                       listdata={listdata[id]} heart="block" cross="none" unfavourite="none" daysLeft="none" onlyPrice="block" />
                                 </div>
                              </div>
                           )}
                        </div>

                     </div>

                  </div>
               </div>
            </div>
         </div>
         {/* <Footer/> */}
         <Offcanvas placement='start' show={showFilter} onHide={handleFilterClose}>
            <Offcanvas.Header closeButton>
            </Offcanvas.Header>
            <Offcanvas.Body>
             <Filter Setf_searchproperty={Setf_searchproperty} f_searchproperty={f_searchproperty}  SetListdata={SetListdata} setShowFilter={setShowFilter} />
            </Offcanvas.Body>
         </Offcanvas>
      </>
   )
}
