import { React, useEffect, useState } from "react";
import "./Navbar.css";
import { BiSearch } from "react-icons/bi";
import { GiHamburgerMenu } from "react-icons/gi";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { tab } from "@testing-library/user-event/dist/tab";
import { CgSearch } from "react-icons/cg";
import Offcanvas from "react-bootstrap/Offcanvas";
import "../../Common/common.css";
import { useDispatch, useSelector } from "react-redux";
import {
  setproperty2,
  setproperty3,
  setproperty1,
  setcompareproperty,
} from "../../redux/action";
import ArrowDropDownRoundedIcon from "@material-ui/icons/ArrowDropDownRounded";
import ArrowDropUpRoundedIcon from "@material-ui/icons/ArrowDropUpRounded";
import toast from "react-simple-toasts";

export default function Navbar(props) {
  const user = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [calcu, setCalcu] = useState();
  const [income, setIncome] = useState("");
  const [expenses, setExpenses] = useState("");
  const [debts, setDebts] = useState("");
  const [dropDown, setDropdown] = useState(true);
  const handleClau = () => {
    setDropdown(!dropDown);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const monthlyRentAffordability = income * 0.3 - expenses - debts;
    const rentAffordability = Math.max(monthlyRentAffordability, 0);
    setCalcu(rentAffordability);
    setDropdown(!dropDown);
  };
  const location = useLocation();
  const dispatch = useDispatch();
  useEffect(() => {
    if (location.pathname.slice(1, 3) === "li") {
    } else {
      dispatch(setproperty2(null));
      dispatch(setproperty3(null));
      dispatch(setproperty1(null));
    }
  }, [location]);

  const search = {
    visibility: props.search,
  };

  const account = {
    display: props.account,
  };

  const login = {
    display: props.login,
  };
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [showWebOC, setShowWebOC] = useState(false);

  const handleCloseWebOC = () => setShowWebOC(false);
  const handleShowWebOC = () => setShowWebOC(true);

  const [webBurger, setWebBurger] = useState("none");

  function handleWebBurger() {
    if (webBurger === "none") {
      setWebBurger("block");
    } else {
      setWebBurger("none");
    }
  }

  return (
    <>
      {/* web navbar */}
      <div className="fixed-top">
   
        <header className="navbar-container-web">
          <div className="navbar-content d-flex">
            <div className="navbar-brand">

              <Link className="removeLinkDefaults black00" to="/">
                <img
                  src="/assets/images/logo2.png"
                  height="54px"
                  className="bord"
                />
              </Link>
            </div>
            <div className="nav_links me-auto d-flex">
              <div>
                <Link
                  to="/favorites"
                  className={
                    location.pathname.slice(1, 4) === "fa"
                      ? "font-18 nav-hover green00"
                      : "font-18 nav-hover"
                  }
                  onClick={() => {
                    dispatch(setcompareproperty([]));
                  }}
                >
                  Favorites
                </Link>
              </div>
              <div>
                <Link
                  to={user?.userid !== undefined ? "/list-property" : "/login"}
                  type="button"
                  className={
                    location.pathname.slice(1, 4) === "li"
                      ? "font-18 nav-hover green00"
                      : "font-18 nav-hover"
                  }
                  onClick={() => {
                    dispatch(setproperty2(null));
                    dispatch(setproperty3(null));
                    dispatch(setproperty1(null));
                    dispatch(setcompareproperty([]));
                  }}
                >
                  List a property
                </Link>
              </div>
             
              <div className="dropdown ">
                <Link
                  id="calculatorModalLabel"
                  className={
                    location.pathname.slice(1, 4) === "fa"
                      ? "font-18 nav-hover green00 modal-title"
                      : "font-18 nav-hover"
                  }
                >
                  Resources
                </Link>
                <div className="dropdown-content gradient-bg border-black25 d-flex flex-column text-white">
                  <Link
                    // className="dropdown-item"
                    className="dropdown-items mt-2"
                    style={{ fontSize: "16px" }}
                    data-bs-toggle="modal"
                    data-bs-target="#calculatorModal "
                  >
                    Monthly Rent Calculator
                  </Link>
                  <hr className="m-0 mt-1"/>
                  <Link to="/move-in-checklist" className="dropdown-items mt-2">
                    Move-in Checklist
                  </Link>
                  <hr className="m-0 mt-1"/>
                  <Link to="/lease-agreement" className=" mt-2   dropdown-items">
                    Generate Lease Agreement
                  </Link>
                  <hr className="m-0 mt-1"/>
                </div>
              </div>
            </div>

            <div className="userLinks ms-auto">
              <Link to="/login">
                <a href="#" className="font-18 nav-hover me-4" style={login}>
                  Log In
                </a>
              </Link>
              {/* <Link to='/signup'><p className={location.pathname.slice(1,3)==="si"?'font-18 nav-hover green00 mb-0':'font-18 nav-hover mb-0'} style={login} >Sign Up</p></Link>  */}
              <Link to="/my-account/myprofile">
                <p
                  className={
                    location.pathname.slice(1, 3) === "my"
                      ? "font-18 nav-hover green00 mb-0 me-4"
                      : "font-18 nav-hover mb-0 me-4"
                  }
                  style={account}
                >
                  My Account
                </p>
              </Link>
              {/* <img src="process.env.REACT_APP_IMAGE_URL_DEFAULT/burgerbar.png" onClick={handleWebBurger} className='ms-3' alt="" />  */}
              {/* <Link to='/search'><CgSearch className='searchInconNav me-4'/></Link> */}
              <Link to="/search">
                <CgSearch
                  className={
                    location.pathname.slice(1, 3) === "se"
                      ? "searchInconNav font-20 nav-hover green00"
                      : " searchInconNav font-20 nav-hover"
                  }
                />
              </Link>
              {/* <img src={webBurger=='none' ? `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/burgerbar.png` : `${process.env.REACT_APP_IMAGE_URL_DEFAULT}/close.png`} onClick={handleWebBurger} width="20px" className='ms-3' alt="" />  */}

              <div className="dropdown parentMenu" onClick={handleShowWebOC}>
                <button
                  className="dropdown-toggle"
                  type="button"
                  id="dropdownMenuButton"
                >
                  <GiHamburgerMenu className="font-20 menuIcon" />
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* tab navbar */}
        <div className="navbar-container-tab">
          <div className="navbar-content d-flex justify-content-between">
            <div className="navbar-brand">
              <Link className="removeLinkDefaults black00" to="/">
                <img
                  src="/assets/images/logo2.png"
                  height="40px"
                  // className="border"
                />
              </Link>
            </div>
            <div className="userLinks me-3 ">
              <Link to="/search">
                <CgSearch className="searchIconNav me-4" />
              </Link>
              <img
                src={`${process.env.REACT_APP_IMAGE_URL_DEFAULT}/burgerbar.png`}
                className="img-fluid m-0 p-0"
                alt=""
                onClick={handleShow}
              />
            </div>
          </div>
        </div>
      </div>
      <Offcanvas
        placement="end"
        show={show}
        onHide={handleClose}
        className="gradient-bg white00  "
      >
        <Offcanvas.Header closeButton>
          <Link className="removeLinkDefaults" to="/">
            <h4 className="white00"> Menu </h4>
          </Link>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div style={{ display: user ? "block" : "none" }}>
            <Link
              onClick={handleClose}
              to="/my-account"
              style={account}
              className="font-regular font-14 removeLinkDefaults white00 myAccountLinkTab"
            >
              My Account
            </Link>
            <hr />
          </div>
          <Link
            onClick={handleClose}
            to="/favorites"
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p>Favorites</p>
          </Link>
          <hr />
          <Link
            to={user?.userid !== undefined ? "/list-property" : "/login"}
            onClick={() => {
              handleClose();
              dispatch(setproperty2(null));
              dispatch(setproperty3(null));
              dispatch(setproperty1(null));
              dispatch(setcompareproperty([]));
            }}
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p>List Property</p>
          </Link>
          <hr />

          <Link
            onClick={handleClau}
            id="calculatorModalLabel"
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p className="arrowIcone">
              Resources{" "}
              {dropDown ? (
                <ArrowDropDownRoundedIcon className="dropdownIcon" />
              ) : (
                <ArrowDropUpRoundedIcon />
              )}{" "}
            </p>{" "}
          </Link>
          <hr />
          {!dropDown ? (
            <>
              <p
                onClick={handleClose}
                className="font-regular font-14 removeLinkDefaults white00 ps-4"
                data-bs-toggle="modal"
                data-bs-target="#calculatorModal"
              >
                Monthly Rent Calculator{" "}
              </p>
              <hr />
              <Link
            onClick={handleClose}
            to="/lease-agreement"
            className="font-regular font-14 removeLinkDefaults white00"
          > <p className=" ps-4">Generate Lease Agreement</p>
          </Link>
          <hr />
           <Link
            onClick={handleClose}
            to="/move-in-checklist"
           className="removeLinkDefaults font-regular font-14 white00 "
          > <p    className=" ps-4"> Move-in Checklist </p></Link>
             <hr />
            </>
          ) : (
            ""
          )}
          <Link
            onClick={handleClose}
            to="/about-us"
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p>About Us</p>
          </Link>
          <hr />
          <Link
            onClick={handleClose}
            to="/contact-us"
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p>Contact Us</p>
          </Link>
          <hr />
          <Link
            onClick={handleClose}
            to="/faqs"
            className="font-regular font-14 removeLinkDefaults white00"
          >
            <p>FAQs</p>
          </Link>
          <hr />
          <div style={login} className="w-100">
            <Link
              onClick={handleClose}
              to="/login"
              className="font-regular font-14 removeLinkDefaults white00"
            >
              <p> Log in </p>
            </Link>
            <hr />
          </div>
        </Offcanvas.Body>
      </Offcanvas>

      <div
        className="modal fade calcModal"
        id="calculatorModal"
        tabindex="-1"
        aria-labelledby="calculatorModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="calculatorModalLabel">
                Rent Affordability Calculator
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="row">
                <div className="col-12 p-1">
                  <label className="green00 font-semibold mb-1" htmlFor="">
                    Monthly Income*{" "}
                  </label>
                  <br />
                  <input
                    type="text"
                    className="shadow-none fill-white25 removeRadious  form-control border-black25 "
                    onChange={(e) => setIncome(e.target.value)}
                    value={income}
                    name="income"
                    id="firstname"
                  />
                </div>
                <div className="col-12 p-1">
                  <label className="green00 font-semibold mb-1" htmlFor="">
                    Monthly Expense*{" "}
                  </label>
                  <br />
                  <input
                    type="text"
                    className="shadow-none fill-white25 removeRadious  form-control border-black25 "
                    onChange={(e) => setExpenses(e.target.value)}
                    value={expenses}
                    name="expenses"
                    id="firstname"
                  />
                </div>
                <div className="col-12 p-1">
                  <label className="green00 font-semibold mb-1" htmlFor="">
                    Other Debts*{" "}
                  </label>
                  <br />
                  <input
                    type="text"
                    className="shadow-none fill-white25 removeRadious  form-control border-black25 "
                    onChange={(e) => setDebts(e.target.value)}
                    value={debts}
                    name="debts"
                    id="firstname"
                  />
                </div>
              </div>

              <div className="row text-center">
                <div className="">
                  <button
                    className="border-none px-3 py-2 fill-green00 white00 mt-2"
                    onClick={handleSubmit}
                  >
                    Calculate
                  </button>
                </div>
              </div>
            </div>
            <p className=" text-center ">
              Your monthly rent affordability is{" "}
              <span className="green00 font-20">:${calcu}</span>
            </p>
            <div className="m-1">
              <p className="p-2 FoantSizeChange">
                Our calculations are based on the industry standard
                recommendation of allocating around 30% of your monthly income
                towards rent. However, remember to consider your individual
                financial situation before making any decisions. Factors such as
                your income level, other financial obligations, and personal
                preferences may impact the percentage that is truly affordable
                for you. We encourage you to consult a financial advisor for
                personalized advice. Your financial well-being is important, and
                we are here to assist you in finding the most suitable housing
                option within your means.
              </p>
            </div>
          </div>
        </div>
      </div>

      <Offcanvas
        placement="end"
        className="gradient-bg text-white"
        show={showWebOC}
        onHide={handleCloseWebOC}
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title className="fountSize">Menu</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className="sidemenu-item pe-0">
          <Link to="/about-us" className="dropdown-item" href="#">
            About Us
          </Link>
          <Link to="/contact-us" className="dropdown-item" href="#">
            Contact Us
          </Link>
          <Link to="/faqs" className="dropdown-item" href="#">
            FAQs
          </Link>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}
